Ls = 44100;
fs = 4410;
fmax = fs/2;
bins = 1;
bins_hi = 4;

%s = gspi;
%s = wavread('kafziel.wav');
%Ls = length(s);

%% Example 1 (ERBlets):
[g,a,fc]=warpedfilters(@freqtoerb,@erbtofreq,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

figure(1); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
title('ERBlet filter transfer functions');

%% Example 2 (ERBlets - 4 bins/ERB):
[g,a,fc]=warpedfilters(@freqtoerb,@erbtofreq,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(2); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
title('ERBlet filter transfer functions (4 bins/ERB)');

%% Example 3 (Square root warping):
warpfun_sqrt = @(x) sign(x).*((1+abs(x)).^(1/2)-1);
invfun_sqrt = @(x) sign(x).*((1+abs(x)).^2-1);
[g,a,fc]=warpedfilters(warpfun_sqrt,invfun_sqrt,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

figure(3); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
title('Square root warped filter transfer functions');

[g,a,fc]=warpedfilters(warpfun_sqrt,invfun_sqrt,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(4); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
title('Square root warped filter transfer functions');

%% Example 4 (linear warping (uniform filter bank):
warpfun = @(x) x/100;
invfun = @(x) 100*x;
[g,a,fc]=warpedfilters(warpfun,invfun,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

figure(5); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
title('uniform filter transfer functions');

[g,a,fc]=warpedfilters(warpfun,invfun,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(6); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
title('uniform filter transfer functions');

%% Example 4 (logarithmic (constant-Q) warping):
warpfun_log = @(x) 10*log(x);
invfun_log = @(x) exp(x/10);
fmin = 50; % The logarithm's derivative 1/x tends to Inf for x towards 0
[g,a,fc]=warpedfilters(warpfun_log,invfun_log,fs,fmin,fmax,50,Ls,'bwmul',1.5,'real','fractional');

figure(7); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
title('constant-Q filter transfer functions');

%% Example 4 (logarithmic (constant-Q) warping - 4 bins):
warpfun_log = @(x) 10*log(x);
invfun_log = @(x) exp(x/10);
fmin = 50; % The logarithm's derivative 1/x tends to Inf for x towards 0
[g,a,fc]=warpedfilters(warpfun_log,invfun_log,fs,fmin,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(8); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);

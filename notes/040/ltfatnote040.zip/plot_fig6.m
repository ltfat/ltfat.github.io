function plot_fig6
% This script plots Fig. 6
%
% Figures 1-3 correspond to Fig. 6a-c

have_exportfig = ~isempty(which('export_fig'));

dirin = ['texexport',filesep];

figure(1);clear fig;
plotresults([dirin,'gausscomparison_sqam_.mat'],[dirin,'gausscomparison_sqam_wsheapint.mat']);

if have_exportfig
export_fig( [dirin,'gausscomparison_sqam.pdf'], '-transparent', '-painters');
export_fig( [dirin,'gausscomparison_sqam.png'], '-transparent', '-painters');
end

figure(2);clear fig;
plotresults([dirin,'hanncomparison_sqam_.mat'],[dirin,'hanncomparison_sqam_wsheapint.mat']);

if have_exportfig
export_fig( [dirin,'hanncomparison_sqam.pdf'], '-transparent', '-painters');
export_fig( [dirin,'hanncomparison_sqam.png'], '-transparent', '-painters');
end

figure(3);clear fig;
plotresults([dirin,'hammingcomparison_sqam_.mat'],[dirin,'hammingcomparison_sqam_wsheapint.mat']);

if have_exportfig
export_fig( [dirin,'hammingcomparison_sqam.pdf'], '-transparent', '-painters');
export_fig( [dirin,'hammingcomparison_sqam.png'], '-transparent', '-painters');
end


function plot_fig4
%This script plots values used in boxplots in Fig. 4
%
% Please run compute_fig4 first to generate the results.

relrespath = ['texexport'];
basepath = fileparts(which(mfilename));
resdir = [basepath,filesep,relrespath];

windows = {'gauss','truncgauss','hann','hamming'};
template = [resdir,filesep,'comparetospsi_%ssqam.mat'];

for ii=1:numel(windows)

load(sprintf(template,windows{ii}));

Cheapintstat = compstat(sort(CheapintAll,'descend'));
Cspsistat = compstat(sort(CspsiAll,'descend'));

disp('--------------------------------------------------------------------------------------');
fprintf('%s\n',windows{ii});
disp('--------------------------------------------------------------------------------------');
fprintf('PGHI(proposed):   max: %.2f, 3. quart: %.2f, median: %.2f, 1. quart: %.2f, min: %.2f\n',20*log10(Cheapintstat));
fprintf('SPSI:             max: %.2f, 3. quart: %.2f, median: %.2f, 1. quart: %.2f, min: %.2f\n',20*log10(Cspsistat));
disp('--------------------------------------------------------------------------------------');
end

function stat = compstat(arr)
N = numel(arr);

iiceil = ceil(N*[1/4,1/2,3/4]);
iifloor = floor(N*[1/4,1/2,3/4]);

stat = [arr(1),...
        (arr(iiceil(1))+arr(iifloor(1)))/2,...
        (arr(iiceil(2))+arr(iifloor(2)))/2,...
        (arr(iiceil(3))+arr(iifloor(3)))/2,...
        arr(end)];







function compute_fig6(winslice,wsslice)
% This script reproduces Fig. 6 from the manuscript.
%
% Figures 1-3 correspond to Fig. 6a-c
relDatabasepath = 'Databases';


basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];
subdirs = {'SQAM'};

exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end
maxwavno = [];

a = 256;
M = 2048;
maxit = 200;
maxsamples = 10*44100;

%win = {'truncgauss','hann'};
ws = {'nowarmstart','wsheapint','wsspsi'};
%win = {'gauss','truncgauss','hann','hamming'};
win = {'gauss','hann','hamming'};

if nargin>0
    win = win(winslice);
end
if nargin>1
    ws = ws(wsslice);
end

for wsId = 1:numel(ws)
    win2 = win;
    if strcmpi('wsspsi',ws{wsId})
        % Do just the Gaussian with SPSI
        win2 = {'gauss'};
    end
    
    for ii=1:numel(win2)
        w = win2{ii};
        s = ws{wsId};
        fprintf('------------------ %s WINDOW -----------------------\n',upper(w));
        comparetoall(databasePath,subdirs,'exportdir',exportdir,w,...
                     'storewavs','maxwavno',maxwavno,'maxit',maxit,s,...
                     'M',M,'a',a,'expname','sqam',...
                     'maxsamples',maxsamples,'excludelbfgs');   
    end
end

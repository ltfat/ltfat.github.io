function plot_fig1
% This script reproduces Fig. 1 from the manuscript.
%
% The script closes all figures which are currently opened.
%
% Figures 1-4 correspond to Fig. 1a-d from the manuscript.
%
% In addition the script exports the plots as:
%
%   Fig. 1a -- texexport/greasy_1.png
%   Fig. 1b -- texexport/phasediff_1.png
%   Fig. 1c -- texexport/phasediff_2.png
%   Fig. 1d -- texexport/phasediff_3.png
%
% And the errors as:
%   texexport/phasediffC_1.tex
%   texexport/phasediffC_2.tex
%   texexport/phasediffC_3.tex
% and
%   texexport/phasediffR_1.tex
%   texexport/phasediffR_2.tex
%   texexport/phasediffR_3.tex
%

% Author: Zdenek Prusa

close all;

basepath = fileparts(which(mfilename));
exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

fsize = 16;

have_exportfig = ~isempty(which('export_fig'));

[f,fs] = greasy; Ls= numel(f); f = postpad(f,ceil(Ls/256)*256);
Ls= numel(f);

Marr = {Ls, Ls, Ls };
aarr = {1, 16 , 32 };
tolarr = { 1e-10, [1e-1, 1e-10], [1e-1, 1e-10] };
db = 60; 

for ii=1:numel(Marr)
    M = Marr{ii}; a = aarr{ii};
    L = dgtlength(Ls,a,M);

    g = {'gauss',1,'inf'};
    gnum = gabwin(g,a,M,L);

    [c,~,gnum] = dgtreal(f,gnum,a,M);
    s = abs(c);
    oldphase = angle(c);
    tol = 10^(-db/20);

    chatint = pghi(abs(c),L,a,M,'tol',tolarr{ii},'freqinv');
    [fhat,gd] = idgtreal(chatint,{'dual',gnum},a,M,Ls);

    nextprojc = dgtreal(fhat,gnum,a,M);

    C = magnitudeerrdb(s,nextprojc);
    
    R = min(20*log10([norm(f-fhat),norm(f+fhat)]./norm(f)));
    
    fprintf('a=%i, C=%.2f dB, R=%.2f dB\n',a,C,R);

    writetexfile(sprintf([exportdir,filesep,'phasediffC_%i.tex'],ii),C);
    writetexfile(sprintf([exportdir,filesep,'phasediffR_%i.tex'],ii),R);

    writetexfile(sprintf([exportdir,filesep,'phasediffa_%i.tex'],ii),a);

   
    if ii==1
        figure;
        plotdgtreal(c,a,M,'dynrange',db,'fs',fs);
        hh = ylabel('Frequency (kHz)'); set(gca,'YTickLabel',num2cell(0:2:8));



        objs = findall(gcf,'Type','text');
        for jj=1:numel(objs)
            set(objs(jj),'FontSize',fsize);
        end
        set(gca,'FontSize',fsize-2);
        
        
        if have_exportfig
            hh=colormap(ltfat_inferno);
            export_fig(sprintf([exportdir,filesep,'greasy_%i_color.png'],ii),'-transparent','-painters','-m2');
            colormap(flipud(gray));
            export_fig(sprintf([exportdir,filesep,'greasy_%i.png'],ii),'-transparent','-painters','-m2');
        else
            colormap(ltfat_inferno);
            saveas(gcf,sprintf([exportdir,filesep,'greasy_%i_color.png'],ii));
            colormap(flipud(gray));
            saveas(gcf,sprintf([exportdir,filesep,'greasy_%i.png'],ii));
        end
        
    end



    figure;
    plotdgtrealphasediff(angle(chatint),oldphase,s,tol,a,M,'fs',fs);
    ylabel('Frequency (kHz)'); set(gca,'YTickLabel',num2cell(0:2:8));
    

    objs = findall(gcf,'Type','text');
    for jj=1:numel(objs)
        set(objs(jj),'FontSize',fsize);
    end
    set(gca,'FontSize',fsize-2);
      
    if have_exportfig
        colormap(ltfat_inferno);
        cbh = findobj(gcf,'Tag','Colorbar');
        set(cbh,'Ytick',[0,1]);
        set(cbh,'FontSize',fsize,'FontName','symbol','YTickLabel',{'0',char(112)});
        export_fig(sprintf([exportdir,filesep,'phasediff_%i_color.png'],ii),'-transparent','-painters','-m2');
        colormap(flipud(gray));
        cbh = findobj(gcf,'Tag','Colorbar');
        set(cbh,'Ytick',[0,1]);
        set(cbh,'FontSize',fsize,'FontName','symbol','YTickLabel',{'0',char(112)});
        export_fig(sprintf([exportdir,filesep,'phasediff_%i.png'],ii),'-transparent','-painters','-m2');
    else
        colormap(ltfat_inferno);
        cbh = findobj(gcf,'Tag','Colorbar');
        set(cbh,'Ytick',[0,1]);
        set(cbh,'FontSize',fsize,'FontName','symbol','YTickLabel',{'0',char(112)});
        saveas(gcf,sprintf([exportdir,filesep,'phasediff_%i_color.png'],ii));
        colormap(flipud(gray));
        cbh = findobj(gcf,'Tag','Colorbar');
        set(cbh,'Ytick',[0,1]);
        set(cbh,'FontSize',fsize,'FontName','symbol','YTickLabel',{'0',char(112)});
        saveas(gcf,sprintf([exportdir,filesep,'phasediff_%i.png'],ii));
    end
end

function writetexfile(name,val)
    fileID = fopen(name,'w');
    if rem(val,1) ~= 0
        fprintf(fileID,'%.2f\n',val);
    else
        fprintf(fileID,'%i\n',val);   
    end
    fclose(fileID);

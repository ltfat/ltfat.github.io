function repr_table1
% This script reproduces Table I from the manuscript.
% Please see README for information how to get the MOCHA-TIMIT database.
%
% This script takes tens of minutes to finish.
%   
relDatabasepath = 'Databases';

basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];
subdirs = {'fsew0','maps0'};

exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

a = 128;
M = 1024;
fprintf('------------------ GAUSS WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'gauss','expname','mocha','storewavs','M',M,'a',a);
fprintf('------------------ TRUNC. GAUSS WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'truncgauss','expname','mocha','storewavs','M',M,'a',a);
fprintf('------------------ HANN WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'hann','expname','mocha','storewavs','M',M,'a',a);
fprintf('------------------ HAMMING WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'hamming','expname','mocha','storewavs','M',M,'a',a);


% Print the table
fprintf('SPSI:     ');
   fprintf('%.2f ', [readtexfile(['texexport',filesep,'spsigaussmocha.tex']),...
    readtexfile(['texexport',filesep,'spsitruncgaussmocha.tex']),...
    readtexfile(['texexport',filesep,'spsihannmocha.tex']),...
    readtexfile(['texexport',filesep,'spsihammingmocha.tex'])]);
fprintf('\n');

fprintf('Proposed: ');
   fprintf('%.2f ', [readtexfile(['texexport',filesep,'heapintgaussmocha.tex']),...
    readtexfile(['texexport',filesep,'heapinttruncgaussmocha.tex']),...
    readtexfile(['texexport',filesep,'heapinthannmocha.tex']),...
    readtexfile(['texexport',filesep,'heapinthammingmocha.tex'])]);
fprintf('\n');

function val = readtexfile(name)

    fileID = fopen(name,'r');
    val = fscanf(fileID,'%f\n');
    fclose(fileID);

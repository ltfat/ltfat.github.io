function plotresults( input, wsinput )


wsres = {};
wslabels = {};

if ischar(input)
    if nargin>1
        load(wsinput);
        wslabels = labels;
        wsCheapint= Cheapint;
        wsres = res;
    end
    load(input);
else
    [labels, Cpghi, Cres, maxit] = deal(input{1:4});
    if numel(input)>3
        rtisiXaxis = input{4};
    end
    if nargin>1
        [wslabels, wsCpghi, wsCres] = deal(input{1:3});
    end
end

%labels{strcmpi('GLA zero',labels)} = 'GLA';

rtisiIdx = strcmpi('rtisi-la',labels);
rem1Idx = strcmpi('GLA rand',labels);
rem2Idx = strcmpi('leGLA',labels);

normalIdx = ~(strcmpi('rtisi-la',labels) | strcmpi('GLA rand',labels) | ...
       strcmpi('leGLA',labels) | strcmpi('FGLA',labels));


wsnormalIdx = ~(strcmpi('leGLA',wslabels) | strcmpi('FGLA',wslabels) );

res(normalIdx) = cellfun(@(el) postpad(el,200),res(normalIdx),'UniformOutput',0);
wsres = cellfun(@(el) postpad(el,200),wsres(wsnormalIdx),'UniformOutput',0);

cm = gray(7);
cm = cm(1:end-1,:);
set(0,'defaultAxesColorOrder',[0,0,0]);

if any(strcmpi('lBFGS',labels))
set(0,'defaultAxesLineStyleOrder','d-|o-|v-|s-|^-');
else
set(0,'defaultAxesLineStyleOrder','o-|v-|s-|^-|d-');
end


plot(20*log10(cell2mat([res(normalIdx)])));
hold on;

if any(rtisiIdx)
    plot(rtisiXaxis,20*log10(cell2mat(res(rtisiIdx))),'k*-','MarkerSize',10);
end

ahsOrig = findall(gca,'type','line');

if ~isempty(wsres)
    %set(0,'defaultAxesLineStyleOrder','--o|--s|--d|--v|--^');
    plot(20*log10(cell2mat(wsres)));
end
hold off;

h = line([1,maxit],20*log10([Cheapint,Cheapint]));
set(h,'LineStyle','--');
set(h,'Marker','None');
set(h,'Color',[0.2,0.2,0.2]);

wslabels = cellfun(@(wEl) [wEl,' ws'],wslabels(wsnormalIdx),'UniformOutput',0);
legend([labels(normalIdx),labels(rtisiIdx),wslabels]);
ylabel('Spectral convergence [dB]','FontSize',18);
xlabel('Number of iterations','FontSize',18);

set(gca,'FontSize',16);
xlim([0,200]);

ahs = findall(gca,'type','line');
diffahs = setdiff(ahs,ahsOrig);

for ii=1:numel(diffahs)
    set(diffahs(ii), 'LineStyle', '--');
end

for ii=1:numel(ahs)
    if strcmpi(get(ahs(ii),'DisplayName'),'rtisi-la')
        continue;
    end
    set(ahs(ii), 'MarkerSize', 10);
    set(ahs(ii), 'LineWidth', 1.3);
    nummarkers(ahs(ii),10);
    set(ahs(ii), 'LineWidth', 1.3);
end

for ii=1:numel(ahs)
    set(ahs(ii), 'LineWidth', 1.3);
end

axis tight;
%set(gca, 'Color', 'none');
%set(gca, 'Color', [1,1,1]);

l = findobj(gcf,'Type','axes','Tag','legend');
%set(l, 'Color', 'none');
%set(gca, 'Color', [1,1,1]);

%set(gcf,'Color',[1,1,1]);

set(gcf,'Position',[ 247 1078 1000 470])




function nummarkers(h,num)

% NUMMARKERS takes a vector of line handles in h
% and reduces the number of plot markers on the lines
% to num. This is useful for closely sampled data.
%
% example:
% t = 0:0.01:pi;
% p = plot(t,sin(t),'-*',t,cos(t),'r-o');
% nummarkers(p,10);
% legend('sin(t)','cos(t)')
%

% Magnus Sundberg Feb 08, 2001

for n = 1:length(h)
    if strcmp(get(h(n),'type'),'line')
        axes(get(h(n),'parent'));
        x = get(h(n),'xdata');
        y = get(h(n),'ydata');
        t = 1:length(x);
        s = [0 cumsum(sqrt(diff(x).^2+diff(y).^2))];
        si = (0:num-1)*s(end)/(num-1);
        ti = round(interp1(s,t,si));
        xi = x(ti);
        yi = y(ti);
        marker = get(h(n),'marker');
        color = get(h(n),'color');
        style = get(h(n),'linestyle');
        linewidth = get(h(n),'linewidth');
        msize = get(h(n),'markersize');
        % make a line with just the markers
        set(line(xi,yi),'marker',marker,'linestyle','none','color',color,'linewidth',linewidth,'markersize',msize);
        % make a copy of the old line with no markers
        set(line(x,y),'marker','none','linestyle',style,'color',color,'linewidth',linewidth,'markersize',msize);
        % set the x- and ydata of the old line to [], this tricks legend to keep on working
        set(h(n),'xdata',[],'ydata',[]);
    end
end

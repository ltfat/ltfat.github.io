function repr_sec5C
% This script generates examples mentioned in sec.V.C. in the manuscript.
% WARNING!!! This takes more than a whole day to finish.
%
% The generated files are stored in
%   ./texexport/repr_sec5C_gauss_shift6/
%   and
%   ./texexport/repr_sec5C_gauss_shift-6/
%

relDatabasepath = 'Databases';
subdirs = {'SQAM'};
basepath = fileparts(which(mfilename));
exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

currexportdir = [exportdir,filesep,mfilename];

if ~exist(currexportdir,'dir')
    mkdir(currexportdir);
end

databaseDirs = cellfun(@(sEl) fullfile(basepath,relDatabasepath,sEl,filesep),subdirs,'UniformOutput',0);

wavfiles = cellfun(@(cEl) arrayfun(@(ccEl) ccEl.name,cEl,'UniformOutput',0),cellfun(@(dEl) dir([dEl,'*.wav']),databaseDirs,'UniformOutput',0),'UniformOutput',0 );
wavfiles = cellfun(@(dEl,wEl) cellfun(@(wwEl) fullfile(dEl,wwEl),wEl,'UniformOutput',0) ,databaseDirs,wavfiles,'UniformOutput',0);
wavfiles = [wavfiles{:}];


shiftsemitones = [6, -6];

for wavfileId = 1:numel(wavfiles)
    %wavfileId = 49;
    for shift=shiftsemitones
        pitchshiftby(wavfiles{wavfileId},shift);
    end
end


function pitchshiftby(wavfile,semitoneshift)
[path,name,ext] = fileparts(wavfile);
fileexportdir = fullfile([currexportdir,sprintf('_gauss_shift%d',semitoneshift)],sprintf('%s',name),filesep);
if ~exist(fileexportdir,'dir')
    mkdir(fileexportdir);
end


[f,fs] = wavload(wavfile);
f = normalize(f(1:10*fs,1),'wav');
wavsave(f,fs,fullfile(fileexportdir,[name,'.wav']));
Ls = numel(f);
% ... or the time scale ratio directly
timescalerat = 1/(2^(semitoneshift/(12)));
maxit = 200;
rtisimaxit = 25;
% Number of frequency channels
M = 2048;
% Synthesis hop factor
a = 256;

% Window used
g = {'gauss','width',2048,'atheight',0.01,'inf'};
% Analysis hop factor
newa = floor23(a*timescalerat);

% Determine compatible length
Lsmallestnewa = dgtlength(1,newa,M);
Lsmallesta = dgtlength(1,a,M);
Lsmallest = dgtlength(1,Lsmallestnewa,Lsmallesta);
L = dgtlength(Ls,Lsmallest,M);
f = postpad(f,L);

% Analysis
[c,~,gnum] = dgtreal(f,g,newa,M);

% Adjust to compatible size
% N = size(c,2);
% newN = ceil(N*a/Lsmallesta)*Lsmallesta/a;
% c = postpad(c,newN,'dim',2);

% Phase reconstruction
[chatSPSI] = spsi(abs(c),a,M);
fscaleSPSI = idgtreal(chatSPSI,{'dual',g},a,M);
[cproj] = dgtreal(fscaleSPSI,g,a,M);
Cspsi = magnitudeerrdb(c,cproj)
fshiftSPSI = normalize(resample(fscaleSPSI,newa,a),'wav');
wavsave(postpad(fshiftSPSI,10*fs),fs,fullfile(fileexportdir,[name,'_spsi.wav']));
writetex(fullfile(fileexportdir,[name,'_spsi.tex']),Cspsi);

[chatHEAPINT] = constructphasereal(abs(c),g,a,M);
fscaleHEAPINT = idgtreal(chatHEAPINT,{'dual',g},a,M);
[cproj] = dgtreal(fscaleHEAPINT,g,a,M);
Cheapint = magnitudeerrdb(c,cproj)
fshiftHEAPINT = normalize(resample(fscaleHEAPINT,newa,a),'wav');
wavsave(postpad(fshiftHEAPINT,10*fs),fs,fullfile(fileexportdir,[name,'_heapint.wav']));
writetex(fullfile(fileexportdir,[name,'_heapint.tex']),Cheapint);

[chatGLA] = gla(abs(c),g,a,M,'maxit',maxit,'gla','tol',1e-10,'quiet');
fscaleGLA = idgtreal(chatGLA,{'dual',g},a,M);
[cproj] = dgtreal(fscaleGLA,g,a,M);
Cgla = magnitudeerrdb(c,cproj)
fshiftGLA = normalize(resample(fscaleGLA,newa,a),'wav');
wavsave(postpad(fshiftGLA,10*fs),fs,fullfile(fileexportdir,[name,'_gla.wav']));
writetex(fullfile(fileexportdir,[name,'_gla.tex']),Cgla);

[chatFLEGLA] = legla(abs(c),g,a,M,'maxit',maxit,'modtrunc','onthefly','flegla');
fscaleFLEGLA = idgtreal(chatFLEGLA,{'dual',g},a,M);
[cproj] = dgtreal(fscaleFLEGLA,g,a,M);
Cflegla = magnitudeerrdb(c,cproj)
fshiftFLEGLA = normalize(resample(fscaleFLEGLA,newa,a),'wav');
wavsave(postpad(fshiftFLEGLA,10*fs),fs,fullfile(fileexportdir,[name,'_flegla.wav']));
writetex(fullfile(fileexportdir,[name,'_flegla.tex']),Cflegla);

[chatRTISI] = lertisila(abs(c),g,a,M,'maxit',rtisimaxit);
fscaleRTISI = idgtreal(chatRTISI,{'dual',g},a,M);
[cproj] = dgtreal(fscaleRTISI,g,a,M);
Crtisi = magnitudeerrdb(c,cproj)
fshiftRTISI = normalize(resample(fscaleRTISI,newa,a),'wav');
wavsave(postpad(fshiftRTISI,10*fs),fs,fullfile(fileexportdir,[name,'_rtisi.wav']));
writetex(fullfile(fileexportdir,[name,'_rtisila.tex']),Crtisi);

[chatGLAWS] = gla(chatHEAPINT,g,a,M,'maxit',maxit,'gla','tol',1e-10,'quiet');
fscaleGLAWS = idgtreal(chatGLAWS,{'dual',g},a,M);
[cproj] = dgtreal(fscaleGLAWS,g,a,M);
Cglaws = magnitudeerrdb(c,cproj)
fshiftGLAWS = normalize(resample(fscaleGLAWS,newa,a),'wav');
wavsave(postpad(fshiftGLAWS,10*fs),fs,fullfile(fileexportdir,[name,'_glawsheapint.wav']));
writetex(fullfile(fileexportdir,[name,'_glawsheapint.tex']),Cglaws);

[chatFLEGLAWS] = legla(chatHEAPINT,g,a,M,'maxit',maxit,'modtrunc','onthefly','flegla');
fscaleFLEGLAWS = idgtreal(chatFLEGLAWS,{'dual',g},a,M);
[cproj] = dgtreal(fscaleFLEGLAWS,g,a,M);
Cfleglaws = magnitudeerrdb(c,cproj)
fshiftFLEGLAWS = normalize(resample(fscaleFLEGLAWS,newa,a),'wav');
wavsave(postpad(fshiftFLEGLAWS,10*fs),fs,fullfile(fileexportdir,[name,'_fleglawsheapint.wav']));
writetex(fullfile(fileexportdir,[name,'_fleglawsheapint.tex']),Cfleglaws);

end

function writetex(s,val)
fileID = fopen(s,'w');
fprintf(fileID,'%.2f\n',val);
fclose(fileID);
end

end




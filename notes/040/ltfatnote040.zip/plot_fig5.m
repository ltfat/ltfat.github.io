function plot_fig5
% This script plots Fig. 5
%
% Figures 1-3 correspond to Fig. 5a-c

have_exportfig = ~isempty(which('export_fig'));

dirin = ['texexport',filesep];

figure(1);clear fig;
plotresults([dirin,'gausscomparison_mocha_.mat'],[dirin,'gausscomparison_mocha_wsheapint.mat']);

if have_exportfig
export_fig([dirin,'gausscomparison_mocha.pdf'],'-transparent', '-painters');
export_fig([dirin,'gausscomparison_mocha.png'],'-transparent','-painters');
end

figure(2);clear fig;
plotresults([dirin,'hanncomparison_mocha_.mat'],[dirin,'hanncomparison_mocha_wsheapint.mat']);

if have_exportfig
export_fig([dirin,'hanncomparison_mocha.pdf'],'-transparent','-painters');
export_fig([dirin,'hanncomparison_mocha.png'],'-transparent','-painters');
end

figure(3);clear fig;
plotresults([dirin,'hammingcomparison_mocha_.mat'],[dirin,'hammingcomparison_mocha_wsheapint.mat']);

if have_exportfig
export_fig([dirin,'hammingcomparison_mocha.pdf'], '-transparent', '-painters');
export_fig([dirin,'hammingcomparison_mocha.png'], '-transparent', '-painters');
end
plotresults('texexport/gausscomparison_sqam_.mat','texexport/gausscomparison_sqam_wsheapint.mat');
export_fig texexport/gausscomparison_sqam.png -transparent -painters
plotresults('texexport/truncgausscomparison_sqam_.mat','texexport/truncgausscomparison_sqam_wsheapint.mat');
export_fig texexport/truncgausscomparison_sqam.png -transparent -painters
plotresults('texexport/hanncomparison_sqam_.mat','texexport/hanncomparison_sqam_wsheapint.mat');
export_fig texexport/hanncomparison_sqam.png -transparent -painters
plotresults('texexport/hammingcomparison_sqam_.mat','texexport/hammingcomparison_sqam_wsheapint.mat');
export_fig texexport/hammingcomparison_sqam.png -transparent -painters

plotresults('texexport/gausscomparison_mocha_.mat','texexport/gausscomparison_mocha_wsheapint.mat');
export_fig texexport/gausscomparison_mocha.png -transparent -painters
plotresults('texexport/truncgausscomparison_mocha_.mat','texexport/truncgausscomparison_mocha_wsheapint.mat');
export_fig texexport/truncgausscomparison_mocha.png -transparent -painters
plotresults('texexport/hanncomparison_mocha_.mat','texexport/hanncomparison_mocha_wsheapint.mat');
export_fig texexport/hanncomparison_mocha.png -transparent -painters
plotresults('texexport/hammingcomparison_mocha_.mat','texexport/hammingcomparison_mocha_wsheapint.mat');
export_fig texexport/hammingcomparison_mocha.png -transparent -painters
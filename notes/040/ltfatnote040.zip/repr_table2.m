function repr_table2
% This script reproduces Table II from the manuscript.
% Please see README for information how to get the EBU SQAM database.
%
% This script takes minutes to finish.
% 

relDatabasepath = 'Databases';
subdirs = {'SQAM'};


basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];


exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

a = 256;
M = 2048;
maxsamples = 10*44100;
fprintf('------------------ GAUSS WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'gauss','expname','sqam','M',M,'a',a,'storewavs','maxsamples',maxsamples);
fprintf('------------------ TRUNC. GAUSS WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'truncgauss','expname','sqam','M',M,'a',a,'storewavs','maxsamples',maxsamples);
fprintf('------------------ HANN WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'hann','expname','sqam','M',M,'a',a,'storewavs','maxsamples',maxsamples);
fprintf('------------------ HAMMING WINDOW -----------------------\n');
comparetospsi(databasePath,subdirs,'exportdir',exportdir,'hamming','expname','sqam','M',M,'a',a,'storewavs','maxsamples',maxsamples);


% Print the table
fprintf('SPSI:     ');
   fprintf('%.2f ', [readtexfile(['texexport',filesep,'spsigausssqam.tex']),...
    readtexfile(['texexport',filesep,'spsitruncgausssqam.tex']),...
    readtexfile(['texexport',filesep,'spsihannsqam.tex']),...
    readtexfile(['texexport',filesep,'spsihammingsqam.tex'])]);
fprintf('\n');

fprintf('Proposed: ');
   fprintf('%.2f ', [readtexfile(['texexport',filesep,'heapintgausssqam.tex']),...
    readtexfile(['texexport',filesep,'heapinttruncgausssqam.tex']),...
    readtexfile(['texexport',filesep,'heapinthannsqam.tex']),...
    readtexfile(['texexport',filesep,'heapinthammingsqam.tex'])]);
fprintf('\n');

function val = readtexfile(name)

    fileID = fopen(name,'r');
    val = fscanf(fileID,'%f\n');
    fclose(fileID);
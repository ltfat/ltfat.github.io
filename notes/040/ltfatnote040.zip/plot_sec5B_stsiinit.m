function plot_sec5B_stsiinit

wsinput = ['texexport',filesep,'gausscomparison_sqam_wsheapint.mat'];
input = ['texexport',filesep,'gausscomparison_sqam_wsspsi.mat'];

wsres = {};
wslabels = {};

load(wsinput);
wslabels = labels;
wsCheapint= Cheapint;
wsres = res;

load(input);



labels2 = labels;
labels2{strcmpi('FleGLA',labels2)} = 'SPSI then FleGLA';
labels2{strcmpi('GLA',labels2)} = 'SPSI then GLA';
if any(strcmpi('lBFGS',labels))
   labels2{strcmpi('lBFGS',labels2)} = 'lBFGS [15]'; 
end

% 
wslabels2 = wslabels;
wslabels2{strcmpi('FleGLA',wslabels2)} = 'PGHI then FleGLA';
wslabels2{strcmpi('GLA',wslabels2)} = 'PGHI then GLA';

if any(strcmpi('lBFGS',wslabels))
   wslabels2{strcmpi('lBFGS',wslabels2)} = 'PGHI then lBFGS'; 
end

legends = {};
handles = [];


%labels{strcmpi('GLA zero',labels)} = 'GLA';

rtisiIdx = strcmpi('rtisi-la',labels);
rem1Idx = strcmpi('GLA rand',labels);
rem2Idx = strcmpi('leGLA',labels);

normalIdx = ~(strcmpi('rtisi-la',labels) | strcmpi('GLA rand',labels) | ...
       strcmpi('leGLA',labels) | strcmpi('FGLA',labels));


wsnormalIdx = ~(strcmpi('leGLA',wslabels) | strcmpi('FGLA',wslabels) );

res(normalIdx) = cellfun(@(el) postpad(el,200),res(normalIdx),'UniformOutput',0);
wsres = cellfun(@(el) postpad(el,200),wsres(wsnormalIdx),'UniformOutput',0);

cm = gray(7);
cm = cm(1:end-1,:);
set(0,'defaultAxesColorOrder',[0,0,0]);

if any(strcmpi('lBFGS',labels))
set(0,'defaultAxesLineStyleOrder','d-|o-|v-|s-|^-');
else
set(0,'defaultAxesLineStyleOrder','o-|v-|s-|^-|d-');
end


h1 = plot(20*log10(cell2mat([res(normalIdx)])));
handles(end+1:end+numel(h1)) = h1;

hold on;

if any(rtisiIdx)
    h2 = plot(rtisiXaxis,20*log10(cell2mat(res(rtisiIdx))),'k*-','MarkerSize',10);
    handles(end+1) = h2;
end
legends(end+1:end+numel(h1)) = labels2;

ahsOrig = findall(gca,'type','line');


h4 = line([1,maxit],20*log10([Cheapint,Cheapint]));
%handles(2:end+1) = handles;
handles(end+1) = h4;
%legends(2:end+1) = legends;
legends(end + 1) = {'PGHI'};

set(h4,'LineStyle','--');
set(h4,'Marker','None');
set(h4,'Color',[0.2,0.2,0.2]);


if ~isempty(wsres)
    %set(0,'defaultAxesLineStyleOrder','--o|--s|--d|--v|--^');
    h3 = plot(20*log10(cell2mat(wsres)));
    handles(end+1:end+numel(h3)) = h3;
    legends(end+1:end+numel(h3)) = wslabels2;
end
hold off;

%wslabels = cellfun(@(wEl) [wEl,' ws'],wslabels(wsnormalIdx),'UniformOutput',0);
%legend([labels(normalIdx),labels(rtisiIdx),wslabels]);

set(gca,'FontSize',16);
xlim([0,200]);

ahs = findall(gca,'type','line');
diffahs = setdiff(ahs,ahsOrig);

for ii=1:numel(diffahs)
    set(diffahs(ii), 'LineStyle', '--');
end

for ii=1:numel(ahs)
    if strcmpi(get(ahs(ii),'DisplayName'),'rtisi-la')
        continue;
    end
    set(ahs(ii), 'MarkerSize', 10);
    set(ahs(ii), 'LineWidth', 1.3);
    nummarkers(ahs(ii),10);
    set(ahs(ii), 'LineWidth', 1.3);
end

for ii=1:numel(ahs)
    set(ahs(ii), 'LineWidth', 1.3);
end

axis tight;
xlim([0,200]);
set(gca, 'Color', 'none');
%set(gca, 'Color', [1,1,1]);


%set(gca, 'Color', [1,1,1]);

%set(gcf,'Color',[1,1,1]);

%set(gcf,'Position',[ 247 1078 1000 470])
set(gcf,'Position',[ 247 1078 1000 400])

h =legend(handles,legends,'FontSize',14);
ylabel('Spectral convergence [dB]','FontSize',18);
xlabel('Number of iterations','FontSize',18);

l = findobj(gcf,'Type','axes','Tag','legend');
set(l, 'Color', 'none');

export_fig texexport/gausscomparison_sqam_PGHIvsSPSI.png -transparent -painters

function nummarkers(h,num)

% NUMMARKERS takes a vector of line handles in h
% and reduces the number of plot markers on the lines
% to num. This is useful for closely sampled data.
%
% example:
% t = 0:0.01:pi;
% p = plot(t,sin(t),'-*',t,cos(t),'r-o');
% nummarkers(p,10);
% legend('sin(t)','cos(t)')
%

% Magnus Sundberg Feb 08, 2001

for n = 1:length(h)
    if strcmp(get(h(n),'type'),'line')
        axes(get(h(n),'parent'));
        x = get(h(n),'xdata');
        y = get(h(n),'ydata');
        t = 1:length(x);
        s = [0 cumsum(sqrt(diff(x).^2+diff(y).^2))];
        si = (0:num-1)*s(end)/(num-1);
        ti = round(interp1(s,t,si));
        xi = x(ti);
        yi = y(ti);
        marker = get(h(n),'marker');
        color = get(h(n),'color');
        style = get(h(n),'linestyle');
        linewidth = get(h(n),'linewidth');
        msize = get(h(n),'markersize');
        % make a line with just the markers
        set(line(xi,yi),'marker',marker,'linestyle','none','color',color,'linewidth',linewidth,'markersize',msize);
        % make a copy of the old line with no markers
        set(line(x,y),'marker','none','linestyle',style,'color',color,'linewidth',linewidth,'markersize',msize);
        % set the x- and ydata of the old line to [], this tricks legend to keep on working
        set(h(n),'xdata',[],'ydata',[]);
    end
end

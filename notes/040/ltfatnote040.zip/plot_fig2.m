function plot_fig2
% This script reproduces Fig. 2 from the manuscript.
%
% The script closes all figures which are currently opened.
%
% Figures 1-4 correspond to Fig. 2a-d from the manuscript.
%
% In addition the script exports the plots as:
%
%   Fig. 2a -- texexport/gspi_8192.png
%   Fig. 2b -- texexport/gspi_phasediffspsi.png
%   Fig. 2c -- texexport/gspi_phasediffunwrap.png
%   Fig. 2d -- texexport/gspi_phasediffheapint.png
%
%

% Author: Zdenek Prusa
close all;

basepath = fileparts(which(mfilename));
exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

fsize = 16;

have_exportfig = ~isempty(which('export_fig'));

[f,fs] = gspi;
f = f(1:4*2048);

a = 16;
M = 2048;
db = 50;

g = 'gauss'; 

gamma = 0.9;
graycm = flipud(gray.^gamma);

thr = 10^(-db/20);

c = dgtreal(f,g,a,M,'timeinv');
s = abs(c);


[chat] = spsi(abs(c),a,M,'timeinv');
fhatSpsi = idgtreal(chat,{'dual',g},a,M,numel(f),'timeinv');
Espsi = magnitudeerrdb(s,dgtreal(fhatSpsi,g,a,M,'timeinv'));

figure(2);
plotdgtrealphasediff(angle(c),angle(chat),abs(c),thr,a,M,'fs',fs);
colormap(graycm);
set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
ylim([0,10e3]);
ylabel('Frequency (kHz)'); set(gca,'YTickLabel',num2cell(0:2:10));
shg
    objs = findall(gcf,'Type','text');
    for jj=1:numel(objs)
        set(objs(jj),'FontSize',fsize);
    end
    set(gca,'FontSize',fsize-2);


exportfigure([exportdir,filesep,'gspi_phasediffspsi.png'],have_exportfig,[0,1]);



chat = phaserecunwrapreal(c,g,a,M,'timeinv');
fhatMagron = idgtreal(chat,{'dual',g},a,M,numel(f),'timeinv');
Emagron = magnitudeerrdb(s,dgtreal(fhatMagron,g,a,M,'timeinv'));

figure(3);clf;
plotdgtrealphasediff(angle(c),angle(chat),abs(c),thr,a,M,'fs',fs);
colormap(graycm);
set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
ylim([0,10e3]);
ylabel('Frequency (kHz)'); set(gca,'YTickLabel',num2cell(0:2:10));
shg
    objs = findall(gcf,'Type','text');
    for jj=1:numel(objs)
        set(objs(jj),'FontSize',fsize);
    end
    set(gca,'FontSize',fsize-2);

exportfigure([exportdir,filesep,'gspi_phasediffunwrap.png'],have_exportfig,[0,1]);


chat = pghi(abs(c),a*M,a,M,'tol',thr,'timeinv');
fhatHeapint = idgtreal(chat,{'dual',g},a,M,numel(f),'timeinv');
Eheapint = magnitudeerrdb(s,dgtreal(fhatHeapint,g,a,M,'timeinv'));

figure(4);clf;
plotdgtrealphasediff(angle(c),angle(chat),s,thr,a,M,'fs',fs);
colormap(graycm);
set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
ylim([0,10e3]);
ylabel('Frequency (kHz)'); set(gca,'YTickLabel',num2cell(0:2:10));
shg
    objs = findall(gcf,'Type','text');
    for jj=1:numel(objs)
        set(objs(jj),'FontSize',fsize);
    end
    set(gca,'FontSize',fsize-2);
    

exportfigure([exportdir,filesep,'gspi_phasediffheapint.png'],have_exportfig,[0,1]);


figure(1);clf;
plotdgtreal(s,a,M,fs,'dynrange',-20*log10(thr));
colormap(graycm);
ylim([0,10e3]);
ylabel('Frequency (kHz)'); set(gca,'YTickLabel',num2cell(0:2:10));

    objs = findall(gcf,'Type','text');
    for jj=1:numel(objs)
        set(objs(jj),'FontSize',fsize);
    end
    set(gca,'FontSize',fsize-2);
    
exportfigure(sprintf([exportdir,filesep,'gspi_%i.png'],numel(f)),have_exportfig);


function exportfigure(name,have_exportfig,cmaplims)
fsize = 16;

if nargin<3
    cmaplims = [];
end
[pathstr,file,ext]=fileparts(name);
cname = fullfile(pathstr,[file,'_color',ext]);

if have_exportfig
    colormap(ltfat_inferno);
    
    if ~isempty(cmaplims)
    cbh = findobj(gcf,'Tag','Colorbar');
    set(cbh,'Ytick',[0,1]);
    set(cbh,'FontSize',fsize,'FontName','symbol','YTickLabel',{'0',char(112)});
    end
    
    export_fig(cname,'-transparent','-painters','-m2');        
    colormap(flipud(gray));
    
    if ~isempty(cmaplims)
    cbh = findobj(gcf,'Tag','Colorbar');
    set(cbh,'Ytick',[0,1]);
    set(cbh,'FontSize',fsize,'FontName','symbol','YTickLabel',{'0',char(112)});
    end

    export_fig(name,'-transparent','-painters','-m2');
else
    colormap(ltfat_inferno);
    if ~isempty(cmaplims)
        cbh = findobj(gcf,'Tag','Colorbar');
        set(cbh,'Ytick',[0,1]);
        set(cbh,'FontSize',fsize,'FontName','symbol','YTickLabel',{'0',char(112)});
        %set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
    end
    saveas(gcf,cname);
            
    colormap(flipud(gray));
    if ~isempty(cmaplims)
        set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
    end
    saveas(gcf,name);
end


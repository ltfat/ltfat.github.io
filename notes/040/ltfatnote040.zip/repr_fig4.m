function repr_fig4(winslice,wsslice)
% This script reproduces Fig. 4 from the manuscript.
%
% Figures 1-3 correspond to Fig. 4a-c
relDatabasepath = 'Databases';


basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];
subdirs = {'SQAM'};

exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end
maxwavno = [];

a = 256;
M = 2048;
maxit = 200;
maxsamples = 10*44100;

%win = {'truncgauss','hann'};
ws = {'nowarmstart','wsheapint'};
%win = {'gauss','truncgauss','hann','hamming'};
win = {'gauss','hann','hamming'};

if nargin>0
    win = win(winslice);
end
if nargin>1
    ws = ws(wsslice);
end

for wsId = 1:numel(ws)
    for ii=1:numel(win)
        w = win{ii};
        s = ws{wsId};
        fprintf('------------------ %s WINDOW -----------------------\n',upper(w));
        comparetoall(databasePath,subdirs,'exportdir',exportdir,w,...
                     'storewavs','maxwavno',maxwavno,'maxit',maxit,s,...
                     'M',M,'a',a,'expname','sqam',...
                     'maxsamples',maxsamples,'excludelbfgs');   
    end
end

figure(1);
plotresults([exportdir,filesep,'gausscomparison_sqam_.mat'],[exportdir,filesep,'gausscomparison_sqam_wsheapint.mat']);
figure(2);
plotresults([exportdir,filesep,'hanncomparison_sqam_.mat'],[exportdir,filesep,'hanncomparison_sqam_wsheapint.mat']);
figure(3);
plotresults([exportdir,filesep,'hammingcomparison_sqam_.mat'],[exportdir,filesep,'hammingcomparison_sqam_wsheapint.mat']);




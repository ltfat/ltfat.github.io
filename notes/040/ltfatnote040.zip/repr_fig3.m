function repr_fig3(winslice,wsslice)
% This script reproduces Fig. 3 from the manuscript.
% WARNING!!! This might take several days finish.
%
% Figures 1-3 correspond to Fig. 3a-c
%
relDatabasepath = 'Databases';

basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];
subdirs = {'fsew0','maps0'};

exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end
maxwavno = [];

%win = {'gauss','truncgauss','hann','hamming'};
win = {'gauss','hann','hamming'};
ws = {'nowarmstart','wsheapint'};

if nargin>0
    win = win(winslice);
end
if nargin>1
    ws = ws(wsslice);
end

a = 128;
M = 1024;
maxit = 200;

for wsId = 1:numel(ws)
    for ii=1:numel(win)
        w = win{ii};
        s = ws{wsId};
        fprintf('------------------ %s WINDOW -----------------------\n',upper(w));
        comparetoall(databasePath,subdirs,'exportdir',exportdir,w,...
                     'storewavs','maxwavno',maxwavno,'maxit',maxit,s,...
                     'expname','mocha','M',M,'a',a);   
    end
end

figure(1);
plotresults([exportdir,filesep,'gausscomparison_mocha_.mat'],[exportdir,filesep,'gausscomparison_mocha_wsheapint.mat']);
figure(2);
plotresults([exportdir,filesep,'hanncomparison_mocha_.mat'],[exportdir,filesep,'hanncomparison_mocha_wsheapint.mat']);
figure(3);
plotresults([exportdir,filesep,'hammingcomparison_mocha_.mat'],[exportdir,filesep,'hammingcomparison_mocha_wsheapint.mat']);





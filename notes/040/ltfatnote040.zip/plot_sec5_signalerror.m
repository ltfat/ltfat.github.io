function plot_sec5_signalerror
% This script demonstrates few examples

have_exportfig = ~isempty(which('export_fig'));

if ~have_exportfig
    warning('export_fig not found! Figures will not be saved.')
end

set(0,'defaultAxesLineStyleOrder',{'-','-','--'});
set(0,'defaultAxesColorOrder',[0,0,0;0.9,0,0;0.8,0.8,0.8]);
basepath = fileparts(which(mfilename));
exportdir = [basepath,filesep,'texexport',filesep];
resdir = [exportdir,'comparetoall_sqam_gauss',filesep];


template_orig = [resdir,'%02i',filesep,'%02i.wav'];
template_rec = [resdir,'%02i',filesep,'%02i_heapint.wav'];
template_C = [resdir,'%02i',filesep,'%02i_heapint.tex'];

wavfiles = [9,42,43,49];

for ii=1:numel(wavfiles)
    [f_orig,fs] = wavload(sprintf(template_orig,wavfiles(ii),wavfiles(ii)));
    [f_rec,fs] = wavload(sprintf(template_rec,wavfiles(ii),wavfiles(ii)));
    res1=f_orig-postpad(f_rec,size(f_orig,1));
    res2=f_orig+postpad(f_rec,size(f_orig,1));

    if norm(res2) < norm(res1)
       f_rec = -f_rec;
    end
    res=f_orig-postpad(f_rec,size(f_orig,1));
    
        
    range = 2*44100:2*44100+1000;
    rangetime = range/fs;
    
    figure(1); clf; h = plot(rangetime,[f_orig(range),f_rec(range),res(range)]);
    set(h,'LineWidth',2);
    axis tight;
    legend({'Original','Reconstructed','Error'},'Fontsize',14);
    xlabel('Time (s)','Fontsize',16);
    ylabel('Amplitude','Fontsize',16);
    
    C = readtexfile(sprintf(template_C,wavfiles(ii),wavfiles(ii)));
    R = 20*log10(min([norm(res),norm(res2)])./norm(f_orig));
    h = title(sprintf('C=%.2f dB, R=%.2f dB\n',C,R)); 

    set(h,'Fontsize',16)
    set(gca,'Fontsize',14)
    
   % soundsc(res,fs);
set(gcf,'Position',[ 247 1078 1000 400])

if have_exportfig
    export_fig(sprintf([exportdir,filesep,'err_sqam_%02i.png'],wavfiles(ii)),'-transparent','-painters');
end    
end


function val = readtexfile(name)

    fileID = fopen(name,'r');
    val = fscanf(fileID,'%f\n');
    fclose(fileID);

function writetex(s,val)
fileID = fopen(s,'w');
fprintf(fileID,'%.2f\n',val);
fclose(fileID);






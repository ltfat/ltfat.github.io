function repr_fig1
% This script reproduces Fig. 1 from the manuscript.
%
% The script closes all figures which are currently opened.
%
% Figures 1-4 correspond to Fig. 1a-d from the manuscript.
%
% In addition the script exports the plots as:
%
%   Fig. 1a -- texexport/greasy_1.png
%   Fig. 1b -- texexport/phasediff_1.png
%   Fig. 1c -- texexport/phasediff_2.png
%   Fig. 1d -- texexport/phasediff_3.png
%
% And the errors as:
%   texexport/phasediffC_1.tex
%   texexport/phasediffC_2.tex
%   texexport/phasediffC_3.tex
%

% Author: Zdenek Prusa

close all;

basepath = fileparts(which(mfilename));
exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

have_exportfig = ~isempty(which('export_fig'));

[f,fs] = greasy; Ls= numel(f); f = postpad(f,ceil(Ls/256)*256);
Ls= numel(f);

Marr = {Ls, Ls, Ls };
aarr = {1, 16 , 32 };
tolarr = { 1e-10, [1e-1, 1e-10], [1e-1, 1e-10] };
db = 60; 

for ii=1:numel(Marr)
    M = Marr{ii}; a = aarr{ii};
    L = dgtlength(Ls,a,M);

    g = {'gauss',1,'inf'};
    gnum = gabwin(g,a,M,L);

    [c,~,gnum] = dgtreal(f,gnum,a,M);
    s = abs(c);
    oldphase = angle(c);
    tol = 10^(-db/20);

    chatint = pghi(abs(c),L,a,M,tolarr{ii});
    [fhat,gd] = idgtreal(chatint,{'dual',gnum},a,M,Ls);

    nextprojc = dgtreal(fhat,gnum,a,M);

    C = magnitudeerrdb(s,nextprojc)

    writetexfile(sprintf([exportdir,filesep,'phasediffC_%i.tex'],ii),C);

    writetexfile(sprintf([exportdir,filesep,'phasediffa_%i.tex'],ii),a);

   
    if ii==1
        figure;
        plotdgtreal(c,a,M,'dynrange',db,'fs',fs);


        objs = findall(gcf,'Type','text');
        for jj=1:numel(objs)
            set(objs(jj),'FontSize',14);
        end
        set(gca,'FontSize',11);
        
        
        if have_exportfig
            colormap(inferno);
            export_fig(sprintf([exportdir,filesep,'greasy_%i_color.png'],ii),'-transparent','-painters','-m2');
            colormap(flipud(gray));
            export_fig(sprintf([exportdir,filesep,'greasy_%i.png'],ii),'-transparent','-painters','-m2');
        else
            colormap(inferno);
            saveas(gcf,sprintf([exportdir,filesep,'greasy_%i_color.png'],ii));
            colormap(flipud(gray));
            saveas(gcf,sprintf([exportdir,filesep,'greasy_%i.png'],ii));
        end
        
    end



    figure;
    plotdgtrealphasediff(angle(chatint),oldphase,s,tol,a,M,'fs',fs);
    

    objs = findall(gcf,'Type','text');
    for jj=1:numel(objs)
        set(objs(jj),'FontSize',14);
    end
    set(gca,'FontSize',11);

    
    if have_exportfig
        colormap(inferno);
            set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
        export_fig(sprintf([exportdir,filesep,'phasediff_%i_color.png'],ii),'-transparent','-painters','-m2');
        colormap(flipud(gray));
            set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
        export_fig(sprintf([exportdir,filesep,'phasediff_%i.png'],ii),'-transparent','-painters','-m2');
    else
        colormap(inferno);
            set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
        saveas(gcf,sprintf([exportdir,filesep,'phasediff_%i_color.png'],ii));
        colormap(flipud(gray));
            set(findobj(gcf,'Tag','Colorbar'),'Ytick',[0,1]);
        saveas(gcf,sprintf([exportdir,filesep,'phasediff_%i.png'],ii));
    end
end

function writetexfile(name,val)
    fileID = fopen(name,'w');
    fprintf(fileID,'%d\n',val);
    fclose(fileID);

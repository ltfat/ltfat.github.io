function compute_fig5(winslice,wsslice)
% This script reproduces Fig. 5 from the manuscript.
% WARNING!!! This might take several days to finish.
%

relDatabasepath = 'Databases';

basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];
subdirs = {'fsew0','maps0'};

exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

%win = {'gauss','truncgauss','hann','hamming'};
win = {'gauss','hann','hamming'};
ws = {'nowarmstart','wsheapint'};

if nargin>0
    win = win(winslice);
end
if nargin>1
    ws = ws(wsslice);
end

a = 128;
M = 1024;
maxit = 200;

for wsId = 1:numel(ws)
   
    for ii=1:numel(win)
        w = win{ii};
        s = ws{wsId};
        fprintf('------------------ %s WINDOW -----------------------\n',upper(w));
        comparetoall(databasePath,subdirs,'exportdir',exportdir,w,...
                     'storewavs','maxit',maxit,s,...
                     'expname','mocha','M',M,'a',a);   
    end
end


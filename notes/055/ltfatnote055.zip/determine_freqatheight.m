function freq = determine_freqatheight(fun,peakpos,height,direction)
% For a function `fun` monotonously decreasing around a unique peak `peakpos` or 
% plateau, this function determines the position at which `fun` decreases below 
% the specified height `height`. The search is performed in the direction indicated
% by `direction`: *0* specifies a search in the direction of increasing indices, 
% starting from `peakpos`. *1* specifies a search towards decreasing indices.
 
freq = peakpos;
height_current = fun(peakpos);
if height_current <= height
    return;
end

if direction 
    freq_right = freq;
    freq_current = freq_right;
    while height_current > height
        freq_right = freq_right + 1/4;
        height_current = fun(freq_right);
    end
    kk = 3;
    while abs(height_current - height) > 1e-3 && kk < 100
        freq_current = freq_right - 2^(-kk);
        height_current = fun(freq_current);
        if height_current < height
            freq_right = freq_current;
        end
        kk = kk+1;
    end
else
    freq_left = freq;
    freq_current = freq_left;
    while height_current > height
        freq_left = freq_left - 1/4;
        height_current = fun(freq_left);
    end
    kk = 3;
    while abs(height_current - height) > 1e-3 && kk < 100
        freq_current = freq_left + 2^(-kk);
        height_current = fun(freq_current);
        if height_current < height
            freq_left = freq_current;
        end
        kk = kk+1;
    end
end

freq = freq_current;

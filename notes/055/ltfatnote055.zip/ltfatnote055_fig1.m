load('results_exp1.mat');
SConvPGHIexp1=SConvPGHI;


SConvPGHIexp1min = min(SConvPGHIexp1,[],1);
SConvPGHIexp1minsort = zeros(18,3);
for ii = 1:3
  for jj = 1:6
    SConvPGHIexp1minsort((ii-1)*6+jj,:)= SConvPGHIexp1min(1,ii,jj,:);
  end
end

SConvPGHIexp1minsort = SConvPGHIexp1minsort([1:4,7:18],:);



SConvPGHIexp1med = median(SConvPGHIexp1,1);
SConvPGHIexp1medsort = zeros(18,3);
for ii = 1:3
  for jj = 1:6
    SConvPGHIexp1medsort((ii-1)*6+jj,:)= SConvPGHIexp1med(1,ii,jj,:);
  end
end

SConvPGHIexp1medsort = SConvPGHIexp1medsort([1:4,7:18],:);



SConvPGHIexp1max = max(SConvPGHIexp1,[],1);
SConvPGHIexp1maxsort = zeros(18,3);
for ii = 1:3
  for jj = 1:6
    SConvPGHIexp1maxsort((ii-1)*6+jj,:)= SConvPGHIexp1max(1,ii,jj,:);
  end
end

SConvPGHIexp1maxsort = SConvPGHIexp1maxsort([1:4,7:18],:);



figure(1);
hold on;
mainlinex = zeros(2,1);
mainliney = zeros(2,1);
ticklinex = zeros(2,1);
tickliney = zeros(2,1);
for ii = 1:16
    locy = ii-0.2; %y-axis location
    locxmin = SConvPGHIexp1minsort(ii,1);
    locxmed = SConvPGHIexp1medsort(ii,1);
    locxmax = SConvPGHIexp1maxsort(ii,1);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p1=plot(mainlinex,mainliney,'--r');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    
    locy = ii; %y-axis location
    locxmin = SConvPGHIexp1minsort(ii,2);
    locxmed = SConvPGHIexp1medsort(ii,2);
    locxmax = SConvPGHIexp1maxsort(ii,2);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p2=plot(mainlinex,mainliney,'-k');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    
    
    locy = ii+0.2; %y-axis location
    locxmin = SConvPGHIexp1minsort(ii,3);
    locxmed = SConvPGHIexp1medsort(ii,3);
    locxmax = SConvPGHIexp1maxsort(ii,3);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p3=plot(mainlinex,mainliney, '-.b');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    
end

yticks(1:16)
yticklabels({...
          'C \alpha 30', ...
          'M \alpha 30', ...
          'M2 \alpha 30',...
          'M3 \alpha 30',...
          'C \alpha 300', ...
          'M \alpha 300', ...
          'M2 \alpha 300',...
          'M3 \alpha 300',...
          'FB3 \alpha 300',...
          'FB5 \alpha 300',...
          'C \alpha 3000', ...
          'M \alpha 3000', ...
          'M2 \alpha 3000',...
          'M3 \alpha 3000',...
          'FB3 \alpha 3000',...
          'FB5 \alpha 3000'...
        })

legend([p1, p2, p3],{'WPGHI','0-FGLIM','W-FGLIM'});
hold off;







function definput=arg_freqwavelet(definput)
  
  definput.flags.wavelettype={ 'cauchy', 'morse', 'genmorse', 'morlet', 'fbsp', 'analyticsp', 'cplxsp'};
  


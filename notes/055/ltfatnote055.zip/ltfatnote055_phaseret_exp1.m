% This script reproduces the experimental setup in 
% Experiment 1 of the manuscript
%
% N.Holighaus, G. Koliander, Z. Prusa and L. D. Abreu,
% NON-ITERATIVE PHASELESS RECONSTRUCTION FROM WAVELET 
% TRANSFORM MAGNITUDE
%   
% http://ltfat.github.io/notes/055/
%
% when supplied with the appropriate signals from the 
% EBU SQAM dataset
%
% https://tech.ebu.ch/publications/sqamcd
%
% Please place the input wav files in the folder 
% 
% ./input/
%
% Results will be saved in the folder
% 
% ./output/
%
% !Attention! 
% Computing all parameter sets on more than a few signals
% may take several hours of computation time.
%
% For a smaller test set, only place the desired files
% in the input folder. You can also use your own signals 
% and wavelet parameters by modifying the file below.
%
% Requires the Large Time-Frequency Analysis Toolbox (LTFAT)
% version 2.4.0 or higher, with compiled C backend.
%
% Version: April 30, 2019
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2019)

%% Preparation

clear all;

disp('--- Used subroutines ---');

which comp_filterbankheapint
which comp_filterbankmaskedheapint
which comp_ufilterbankheapint
which comp_ufilterbankmaskedheapint
which comp_filterbankphasegradfrommag

%% Prepare to load test signal

path = './input/'; % Place your test signal wav files here
listing = dir([path,'*.wav']);
allwavsCell = arrayfun(@(wav) fullfile(path,wav.name),listing,'UniformOutput',0);
writepath = './output/'; % The experiment output will be saved here, make sure the folder exists



%% Cauchy wavelet parameters
filtNos = [100, 240, 400];		% Number of scales
a_array = [ 10, 24, 40];			% Decimation factor
wavelet_vec = {{'cauchy'},{'morlet'},{'morse',2},{'morse',3},{'fbsp',3},{'fbsp',5}};

alphas  = [30,300,3000];		% Cauchy wavelet order
morletsigmas = [3.79,12.25,38.78];
morse2alpha = [28.93, 298.93, 2998.93];
morse3alpha = [28.45, 298.55, 2998.45];
fbsp3bw = [ 0 , 4.32, 13.70];
fbsp5bw = [ 0 , 3.25, 10.3];

param_mat = [ alphas; morletsigmas; morse2alpha; morse3alpha; fbsp3bw; fbsp5bw ];

L = 220560;				% Desired signal length
start = 0;				% From sample

%% Prepare arrays for error and timing results

SConvPGHI = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec), 3);
Timing = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec), 3);

%% Main section
for jj=1:numel(filtNos)  % Loop over parameter sets
    fprintf('WAVELETFILTERS alpha=%.2f, filters=%d, a=%.2f \n', alphas(jj), filtNos(jj), a_array(jj));
    
    for ll = 1:numel(wavelet_vec)
        if param_mat(ll,jj) ~= 0
            fprintf(['WAVELETTYPE ', wavelet_vec{ll}{1}]);
            % Initialize wavelet filters and dual filters
            if strcmp(wavelet_vec{ll}(1),'morse')
                wletCell = [wavelet_vec{ll}(1),param_mat(ll,jj),wavelet_vec{ll}(2:end)]
            else
                wletCell = [wavelet_vec{ll},param_mat(ll,jj)]
            end
            alpha = wpghi_findalpha(wletCell,0.2);
            [gs,info] = ltfatnote055_waveletfilters(L,2.^linspace(6,-3.3,filtNos(jj)),wletCell);
            as=a_array(jj);
            gd = filterbankrealdual(gs,as, L);
            F = frame('ufilterbankreal',gs,as,numel(gs));
            Fd = frame('ufilterbankreal',gd,as,numel(gs));

            wName = wletCell{1};
            for ii = 2:numel(wletCell)
                wName = [wName,'_',num2str(wletCell{ii})];
            end
            tfr = info.tfr(L);
            
            for ii=1:numel(allwavsCell) % Loop over files
                
                % Select file and load
                wavfile = allwavsCell{ii};
                [~,filename,ext] = fileparts(wavfile);
                [f,fs] = wavload(wavfile);
                
                % Truncate signal and normalize conservatively
                f = f(start+1:start+L,1);
                f = 0.3*normalize(f,'inf');
                
                % Write audio file of input signal
                filenameW = [writepath,filename,'_ORG.flac'];
                audiowrite(filenameW,real(f),fs);
                
                fprintf('\n--------------------------------%s--------------------------------------\n',wavfile);
                
                % Compute coefficients
                c_orig = ufilterbank(f,gs,as);
                abss = abs(c_orig);
                [N,M] = size(abss);
                
                %%  ----------  Wavelet PGHI reconstruction  ----------
                
                % Compute wavelet PGHI phase estimate
                tic;
                ctemp=filterbankconstphase(abss(:,2:end-1),as,info.fc(2:end-1),tfr(2:end-1),'wavelet','tol',1e-10);
                ctemp = [abss(:,1),ctemp,abss(:,end)];
                timeWPGHI = toc;
                
                % Reconstruction using wavelet PGHI phase estimate
                tic;
                fhat = ifilterbank(ctemp,gd,as,'real');
                timeifiltW = toc;
                
                % Compute spectral convergence error, save error and timing
                cproj = ufilterbank(fhat,gs,as);
                Cdb = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
                SConvPGHI(ii,jj,ll,1) = Cdb;
                Timing(ii,jj,ll,1) = timeWPGHI + timeifiltW;
                
                % Write output file
                clear cproj;                
                filenameW = [writepath,filename,'_alpha_',num2str(alpha),'_WPGHI_',wName,'.flac'];
                audiowrite(filenameW,real(fhat),fs);
                clear fhat;
                
                % Print error values
                fprintf('Wavelet formula C=%.2f dB\n',Cdb);
                
                %%  ----------  fast Griffin-Lim reconstruction  ----------
                
                % Iterative phaseless reconstruction using fast Griffin-Lim
                % with zeros initial phase
                tic;
                fhat = frsynabs(F,framenative2coef(F,abss),L,'fgriflim','Fd',Fd,'maxit',40);
                timeRFGLIM = toc;
                
                % Compute spectral convergence error, save error and timing
                cproj = ufilterbank(fhat,gs,as);
                Cdb = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
                SConvPGHI(ii,jj,ll,2) = Cdb;
                Timing(ii,jj,ll,2) = timeRFGLIM;
                
                % Write output file
                clear cproj;
                filenameW = [writepath,filename,'_alpha_',num2str(alpha),'_FGLIM_WAVELET_',wName,'.flac'];
                audiowrite(filenameW,real(fhat),fs);
                clear fhat;
                
                %%  ----------  WPGHI fast Griffin-Lim reconstruction  ----------
                
                % Iterative phaseless reconstruction using fast Griffin-Lim
                % with wavelet PGHI estimate as initial phase
                tic;
                fhat = frsynabs(F,framenative2coef(F,ctemp),L,'fgriflim','Fd',Fd,'input','maxit',40);
                timeWFGLIM = toc;
                
                % Compute spectral convergence error, save error and timing
                cproj = ufilterbank(fhat,gs,as);
                Cdb2 = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
                SConvPGHI(ii,jj,ll,3) = Cdb2;
                Timing(ii,jj,ll,3) = timeWPGHI+timeWFGLIM;
                
                % Write output file
                clear cproj ctemp;
                filenameW = [writepath,filename,'_alpha_',num2str(alpha),'_FGLIM_WPGHI_WAVELET_',wName,'.flac'];
                audiowrite(filenameW,real(fhat),fs);
                clear fhat;
                
                % Print error values
                fprintf('FGLIM zero init C=%.2f dB, FGLIM WPGHI init C=%.2f dB\n',Cdb,Cdb2);
                
                clear timeWPGHI timeRFGLIM timeWFGLIM timeifiltFB timeifiltW;
            end
        end
    end
end

% % Uncomment to save results
% save([writepath,'results_exp1.mat'],'SConvPGHI');
% save([writepath,'timing_exp1.mat'],'Timing');

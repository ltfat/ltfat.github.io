load('results_exp2.mat');
SConvPGHIexp2=SConvPGHI;


SConvPGHIexp2min = min(SConvPGHIexp2,[],1);
SConvPGHIexp2minsort = zeros(18,3);
for ii = 1:3
  for jj = 1:6
    SConvPGHIexp2minsort((ii-1)*6+jj,:)= SConvPGHIexp2min(1,ii,jj,:);
  end
end




SConvPGHIexp2med = median(SConvPGHIexp2,1);
SConvPGHIexp2medsort = zeros(18,3);
for ii = 1:3
  for jj = 1:6
    SConvPGHIexp2medsort((ii-1)*6+jj,:)= SConvPGHIexp2med(1,ii,jj,:);
  end
end




SConvPGHIexp2max = max(SConvPGHIexp2,[],1);
SConvPGHIexp2maxsort = zeros(18,3);
for ii = 1:3
  for jj = 1:6
    SConvPGHIexp2maxsort((ii-1)*6+jj,:)= SConvPGHIexp2max(1,ii,jj,:);
  end
end


figure(2);
hold on;
mainlinex = zeros(2,1);
mainliney = zeros(2,1);
ticklinex = zeros(2,1);
tickliney = zeros(2,1);
for ii = 1:18
    locy = ii-0.2; %y-axis location
    locxmin = SConvPGHIexp2minsort(ii,1);
    locxmed = SConvPGHIexp2medsort(ii,1);
    locxmax = SConvPGHIexp2maxsort(ii,1);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p1=plot(mainlinex,mainliney,'--r');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    
    locy = ii+0.2; %y-axis location
    locxmin = SConvPGHIexp2minsort(ii,2);
    locxmed = SConvPGHIexp2medsort(ii,2);
    locxmax = SConvPGHIexp2maxsort(ii,2);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p2=plot(mainlinex,mainliney,'-b');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    
    
end

yticks(1:18)
yticklabels({...
          'C R10', ...
          'M R10', ...
          'M2 R10',...
          'M3 R10',...
          'FB3 R10',...
          'FB5 R10',...
          'C R5', ...
          'M R5', ...
          'M2 R5',...
          'M3 R5',...
          'FB3 R5',...
          'FB5 R5',...
          'C R3', ...
          'M R3', ...
          'M2 R3',...
          'M3 R3',...
          'FB3 R3',...
          'FB5 R3'...
        })

legend([p1, p2],{'WPGHI','W-FGLIM'});

hold off;







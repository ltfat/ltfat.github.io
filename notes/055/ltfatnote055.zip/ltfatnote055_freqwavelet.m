function [H,info] = ltfatnote055_freqwavelet(name,L,varargin)
%FREQWAVELET  Wavelet in the freq. domain
%   Usage: H=freqwavelet(name,L)
%          H=freqwavelet(name,L,scale)
%          [H,info]=freqwavelet(...)
%
%   Input parameters:
%         name  : Name of the wavelet
%         L     : System length
%         scale : Wavelet scale
%   Output parameters:
%         H     : Frequency domain wavelet
%         info  : Struct with additional outputs
%
%   `freqwavelet(name,L)` returns peak-normalized "mother" frequency-domain
%   wavelet `name` for system length *L*. The basic scale is selected such
%   that the peak is positioned at the frequency 0.1 relative to the Nyquist
%   rate (fs/2).
%
%   The supported wavelets that can be used in place of `name` (the actual
%   equations can be found at the end of this help):
%
%     'cauchy'    Cauchy wavelet with alpha=100. Custom order=(alpha-1)/2
%                 (with alpha>1) can be set by `{'cauchy',alpha}`. The
%                 higher the order, the narrower and more symmetric the
%                 wavelet. A numericaly stable formula is used in order
%                 to allow support even for very high `alpha` e.g.
%                 10^6.
%
%     'morse'     Morse wavelet with alpha=100 and gamma=3. Both parameters
%                 can be set directly by `{'morse',alpha,gamma}`. `alpha`
%                 has the same role as for 'cauchy', `gamma` is the
%                 'skewness' parameter. 'morse' becomes 'cauchy' for
%                 gamma=1.
%
%     'morlet'    Morlet wavelet with sigma=4. The parameter `sigma` 
%                 is the center frequency to standard deviation ratio of
%                 the main generating Gaussian distribution. Note that the 
%                 true peak and standard deviation of the Morlet wavelet 
%                 differ, in particular for low values of `sigma` (<5). 
%                 This is a consequence of the correction factor. The 
%                 parameter can be set directly by `{'morlet',sigma}`.
% 
%    'fbsp'       Frequency B-spline wavelet of order m=3, center frequency
%                 to bandwidth ratio fb = 2. The parameters can be set
%                 by `{'fbsp',m,fb}`. Note that `m` must be integer and
%                 greater than or equal to 1, and `fb` must be greater than 
%                 or equal to 2. 
%
%    'analyticsp' Positive frequency part of cosine-modulated B-spline 
%                 wavelet of  order order=3, with center frequency to main 
%                 lobe width ratio fb = 1. The parameters can be set by 
%                 `{'analyticsp',order,fb}`. Note that `order` and `fb` 
%                 must be integer and greater than or equal to 1.
%
%    'cplxsp'     Complex-modulated B-spline of order order=3, with center
%                 frequency to main lobe width ratio fb = 1. The parameters 
%                 can be set by `{'cplxsp',order,fb}`. Note that `order` 
%                 and `fb` must be integer and greater than or equal to 1.
%
%   `freqwavelet(name,L,scale)` returns a "dilated" version of the wavelet.
%   The positive scalar `scale` controls both the bandwidth and the center
%   frequency. Values greater than 1 make the wavelet wider (and narrower 
%   in the frequency domain), values lower than 1 make the wavelet narrower.
%   The center frequency is moved to`0.1/scale`. The center frequency is 
%   limitted to the range of "positive" frequencies ]0,1] (up to Nyquist rate).
%   If `scale` is a vector, the output is a `L x numel(scale)` matrix with 
%   the individual wavelets as columns.
%
%   The following additional flags and key-value parameters are available:
%
%     'basefc',fc      Normalized center frequency of the mother wavelet
%                      (scale=1). The default is 0.1.
%
%     'bwthr',bwthr    The height at which the bandwidth is computed.
%                      The default value is 10^(-3/10) (~0.5).
%
%     'efsuppthr',thr  The threshold determinig the effective support of
%                      the wavelet. The default value is 10^(-5).
%
%   The format of the output is controlled by the following flags:
%   'full' (default),'econ','asfreqfilter':
%
%     'full'           The output is a `L x numel(scale)` matrix.
%
%     'econ'           The output is a `numel(scale)` cell array with
%                      individual freq. domain wavelets truncated to the
%                      length of the effective support given by parameter 'efsuppthr'.
%
%     'asfreqfilter'   As 'econ', but the elements of the cell-array are
%                      filter structs with fields .H and .foff as in 
%                      |blfilter| to be used in |filterbank| and related. 
%
%   `[H,info]=freqwavelet(...)` additionally returns a struct with the
%   following fields:
%
%     .fc             Normalized center frequency.
%
%     .foff           Index of the first sample above the effective
%                     support threshold (minus one). 
%                     It can be directly used to convert the 'econ'
%                     output to 'full' by `circshift(postpad(H,L),foff)`.
%
%     .fsupplen       Length of the effective support (with values above efsuppthr.).
%
%     .scale          The scale used.
%
%     .dilation       The actual dilation used in the formula.
%
%     .bw             Relative bandwidth at -3 dB (half of the height).
%
%     .tfr            Time-frequency ratio of a Gaussian with the same
%                     bandwidth as the wavelet.
%
%     .a_natural      Fractional natural subsampling factors in the
%                     format acceptable by |filterbank| and related.
%
%   Additionally, the function accepts flags to normalize the output.
%   Please see the help of |normalize|. By default, no normaliazation is
%   applied.
%
%   Wavelet definitions
%   -------------------
%
%   `C` is a normalization constant.
%
%   Cauchy wavelet
%
%       H = C \xi^{\frac{\alpha-1}{2}} exp( -2\pi\xi )
%
%       .. math:: H = C \xi^{\frac{\alpha-1}{2}} exp( -2\pi\xi )
%
%   Morse wavelet
%
%       H = C \xi^{\frac{\alpha-1}{2\gamma}} exp( -2\pi\xi^{\gamma} )
%
%       .. math:: H = C \xi^{\frac{\alpha-1}{2\gamma}} exp( -2\pi\xi^{\gamma} )
%
%   See also: normalize, filterbank, blfilter

% AUTHORS: Zdenek Prusa, Nicki Holighaus, Guenther Koliander

complainif_notenoughargs(nargin,2,upper(mfilename));

if ~isscalar(L)
    error('%s: L must be a scalar',upper(mfilename));
end

if ~iscell(name), name = {name}; end

freqwavelettypes = getfield(arg_freqwavelet(),'flags','wavelettype');

if ~ischar(name{1}) || ~any(strcmpi(name{1},freqwavelettypes))
  error('%s: First input argument must the name of a supported window.',...
        upper(mfilename));
end

winArgs = name(2:end);
winName = lower(name{1});

definput.import={'normalize'};
definput.importdefaults={'null'};
definput.keyvals.scale = 1;
definput.keyvals.basefc = 0.1;
definput.keyvals.bwthr = 10^(-3/10);
definput.keyvals.efsuppthr = 10^(-5);
definput.flags.outformat = {'full','econ','asfreqfilter'};
definput.keyvals.scal = 1;
[flags,kv,scale]=ltfatarghelper({'scale'},definput,varargin,'freqwavelet');

if ~isnumeric(L), error('%s: scale must be numeric',upper(mfilename)); end
if any(scale <= 0), error('%s: scale must be positive.', upper(mfilename)); end
if kv.efsuppthr < 0, error('%s: efsuppthr must be nonegative',upper(mfilename)); end
if kv.bwthr < 0, error('%s: bwthr must be nonegative',upper(mfilename)); end
if kv.bwthr < kv.efsuppthr, error('%s: bwthr must be lower than efsuppthr.',upper(mfilename)); end

switch winName
    case 'cauchy'
       definputcauchy.keyvals.alpha=100;
       definputcauchy.keyvals.beta=0;
       [~,~,alpha,beta]=ltfatarghelper({'alpha','beta'},definputcauchy,winArgs);
       winName = 'genmorse';
       winArgs = {'alpha',alpha,'beta',beta,'gamma',1};
   case 'morse'
       definputmorse.keyvals.alpha=100;
       definputmorse.keyvals.gamma=3;
       [~,~,alpha,gamma]=ltfatarghelper({'alpha','gamma'},definputmorse,winArgs);
       winName = 'genmorse';
       winArgs = {'alpha',alpha,'beta',0,'gamma',gamma};
end

fs = 2;
step = fs/L;
M = numel(scale);
info.fc    = zeros(1,M);
info.foff  = zeros(1,M);
info.fsupp = L*ones(1,M);
info.scale = zeros(1,M);
info.bw    = zeros(1,M);
info.tfr   = zeros(1,M);
%info.   = zeros(1,M);
info.a_natural = L*ones(M,2);

if flags.do_full
    H = zeros(L,M);
else
    H = cell(1,M);
end

for m = 1:M
    switch winName
       case 'genmorse' % Generalized Morse wavelets
            definputgenmorse.keyvals.alpha=100;
            definputgenmorse.keyvals.beta=0;
            definputgenmorse.keyvals.gamma=3;
            [~,~,alpha,beta,gamma]=ltfatarghelper({'alpha','beta','gamma'},definputgenmorse,winArgs);

            if alpha <= 1
                error('%s: Alpha must be larger than 1 (passed alpha=%.2f).',...
                      upper(mfilename),alpha);
            end

            if gamma <= 0
                error('%s: Gamma must be larger than 0 (passed gamma=%.2f).',...
                      upper(mfilename),gamma);
            end

            order = (alpha-1)/(2*gamma);
            peakpos = ( order/(2*pi*gamma) )^(1/(gamma));
            basedil = peakpos/(kv.basefc);

            info.fc(m) = peakpos/(basedil*scale(m));
            info.scale(m) = scale(m);
            info.dilation(m) = basedil*scale(m);

            if info.fc(m) <= 0 || info.fc(m) > 1
                error(['%s: fc out of range [0,1[. Decrease alpha ',...
                       '(passed %.2f) and/or scale (passed %.2f)'],...
                       upper(mfilename),alpha,scale(m));
            end

            freqatheightasc = @(thr) real( (-order/(2*pi*gamma)...
                                     *octave_lambertw( 0, ...
                                     -thr^(gamma/order)/exp(1)))^(1/(gamma)) )...
                                      /basedil/scale(m);
            freqatheightdesc= @(thr) real( (-order/(2*pi*gamma)...
                                     *octave_lambertw(-1, ...
                                     -thr^(gamma/order)/exp(1)))^(1/gamma) )...
                                     /basedil/scale(m);
            fsupp = [0 0 info.fc(m) fs fs];

            if kv.efsuppthr > 0
                fsupp(1) = max( 0,freqatheightasc(kv.efsuppthr));
                fsupp(5) = min(fs,freqatheightdesc(kv.efsuppthr));
            end
            fsupp(2) = max( 0,freqatheightasc(kv.bwthr));
            fsupp(4) = min(fs,freqatheightdesc(kv.bwthr));

            fsuppL = fsuppL_inner(fsupp,fs,L,1:5);

            morsefun = @(y) (y > 0).*exp(-2*pi*y.^gamma + (order - 1i*beta)*log(y) ...
                             + ( order/gamma - order/gamma*log(order/(2*pi*gamma)) ));

            info.foff(m) = fsuppL(1);
            info.fsupp(m) = fsuppL(end) - fsuppL(1) + 1;
            if info.fsupp(m) <= 0, info.fsupp(m) = 0; end

            info.bw(m)  = (fsupp(4) - fsupp(2));
            bwinsamples = info.bw(m)/step;
            info.a_natural(m,2) = ceil(bwinsamples);
            if strcmp(winName,'cauchy')
                CauchyAlpha = alpha;
            else                
                CauchyAlpha = wpghi_findalpha({'genmorse',alpha,beta,gamma},0.2);
            end
            info.tfr(m) = (CauchyAlpha - 1)/(pi*info.fc(m)^2*L);
                         
            if flags.do_full
                y = ((0:L-1)').*basedil*step*scale(m);
                H(:,m) = kv.scal*normalize(morsefun(y), flags.norm);
            elseif flags.do_econ
                y = ((fsuppL(1):fsuppL(end)-1)').*basedil*step*scale(m);
                H{m} = kv.scal*normalize(morsefun(y), flags.norm);
            elseif flags.do_asfreqfilter
                y = @(L) ((fsuppL_inner(fsupp,fs,L,1):fsuppL_inner(fsupp,fs,L,5)-1)').*basedil*scale(m)*fs/L;
                H{m} = struct('H',@(L) kv.scal*normalize(morsefun(y(L)),flags.norm),'foff',@(L)fsuppL_inner(fsupp,fs,L,1),'realonly',0);
            end
         case 'morlet' % Morlet wavelets
                  
           definputmorlet.keyvals.sigma=4;
           [~,~,sigma]=ltfatarghelper({'sigma'},definputmorlet,winArgs);

            if sigma <= 1
                error('%s: Sigma must be larger than 1 (passed sigma=%.2f).',...
                      upper(mfilename),sigma);
            end

            % Fixed point iteration to find the maximum of the Morlet
            % wavelet
            peakpos = sigma;
            peakpos_tmp = 0;
            while abs(peakpos-peakpos_tmp) > 1e-6
                peakpos_tmp = peakpos;
                peakpos = sigma./(1-exp(-sigma*peakpos));
            end
            basedil = peakpos/(kv.basefc);

            info.fc(m) = peakpos/(basedil*scale(m));
            info.scale(m) = scale(m);
            info.dilation(m) = basedil*scale(m);

            if info.fc(m) <= 0 || info.fc(m) > 1
                error(['%s: fc out of range [0,1[. Decrease alpha ',...
                       '(passed %.2f) and/or scale (passed %.2f)'],...
                       upper(mfilename),alpha,scale(m));
            end
            
            morletfun = @(y) ( exp(-0.5*(sigma-y).^2) - exp(-0.5*( sigma.^2+y.^2 )) )...
                               ./ ( exp(-0.5*(sigma-peakpos).^2) - exp(-0.5*( sigma.^2+peakpos.^2 )) );            
     
            freqatheightdesc = @(thr) determine_freqatheight(morletfun,peakpos,thr,1)/basedil/scale(m);
            freqatheightasc= @(thr) determine_freqatheight(morletfun,peakpos,thr,0)/basedil/scale(m);
            fsupp = [0 0 info.fc(m) fs fs];

            if kv.efsuppthr > 0
                fsupp(1) = max( 0,freqatheightasc(kv.efsuppthr));
                fsupp(5) = min(fs,freqatheightdesc(kv.efsuppthr));
            end
            fsupp(2) = max( 0,freqatheightasc(kv.bwthr));
            fsupp(4) = min(fs,freqatheightdesc(kv.bwthr));

            fsuppL = fsuppL_inner(fsupp,fs,L,1:5); 
            
            info.foff(m) = fsuppL(1);
            info.fsupp(m) = fsuppL(end) - fsuppL(1) + 1;
            if info.fsupp(m) <= 0, info.fsupp(m) = 0; end

            info.bw(m)  = (fsupp(4) - fsupp(2));
            bwinsamples = info.bw(m)/step;
            info.a_natural(m,2) = ceil(bwinsamples);
            
            CauchyAlpha = wpghi_findalpha({'morlet',sigma},0.2);
            info.tfr(m) = (CauchyAlpha - 1)/(pi*info.fc(m)^2*L);
                         
            if flags.do_full
                y = ((0:L-1)').*basedil*step*scale(m);
                H(:,m) = kv.scal*normalize(morletfun(y), flags.norm);
            elseif flags.do_econ
                y = ((fsuppL(1):fsuppL(end)-1)').*basedil*step*scale(m);
                H{m} = kv.scal*normalize(morletfun(y), flags.norm);
            elseif flags.do_asfreqfilter
                y = @(L) ((fsuppL_inner(fsupp,fs,L,1):fsuppL_inner(fsupp,fs,L,5)-1)').*basedil*scale(m)*fs/L;
                H{m} = struct('H',@(L) kv.scal*normalize(morletfun(y(L)),flags.norm),'foff',@(L)fsuppL_inner(fsupp,fs,L,1),'realonly',0);
            end
         case 'fbsp' % Frequency B-Spline wavelets 
                  
           definputfbsp.keyvals.order=3;
           definputfbsp.keyvals.fb=1;
           [~,~,order,fb]=ltfatarghelper({'order','fb'},definputfbsp,winArgs);

            if order < 1 || order > 5 || round(order) ~= order
                error('%s: order must be integer and between 1 and 5 (passed order=%.2f).',...
                      upper(mfilename),order);
            end
            
            if fb < 2
                error('%s: fb must be at least 2 (passed fb=%.2f).',...
                      upper(mfilename),fb);
            end
            
            peakpos = 1;
            basedil = peakpos/(kv.basefc);

            info.fc(m) = peakpos/(basedil*scale(m));
            info.scale(m) = scale(m);
            info.dilation(m) = basedil*scale(m);

            if info.fc(m) <= 0 || info.fc(m) > 1
                error(['%s: fc out of range [0,1[. Decrease alpha ',...
                       '(passed %.2f) and/or scale (passed %.2f)'],...
                       upper(mfilename),alpha,scale(m));
            end
            
            switch order
                case 1
                  prefun = @(x) ( x >= 0 ).*( x < 1 ) .* 1;  
                case 2
                  prefun = @(x) ( x >= 0 ).*( x < 1 ) .* ...
                                   (x) ...
                                + ( x >= 1 ).*( x < 2 ) .* ...
                                   (2-x);  
                case 3
                  prefun = @(x)  ( x >= 0 ).*( x < 1 ) .* ...
                                   (.5*x.^2) ...
                                + ( x >= 1 ).*( x < 2 ) .* ...
                                   (-x.^2 + 3.*x -1.5) ...
                                + ( x >= 2 ).*( x < 3 ) .* ...
                                   (.5*x.^2 - 3.*x + 4.5);
                case 4
                  prefun = @(x)  ( x >= 0 ).*( x < 1 ) .* ...
                                   (x.^3./6) ...
                                + ( x >= 1 ).*( x < 2 ) .* ...
                                   (-x.^3./2 + 2.*x.^2 - 2.*x + 2/3) ...
                                + ( x >= 2 ).*( x < 3 ) .* ...
                                   (x.^3./2 - 4.*x.^2 + 10.*x - 22/3) ...
                                + ( x >= 3 ).*( x < 4 ) .* ...
                                   (-x.^3./6 + 2.*x.^2 - 8.*x + 32/3); 
                case 5
                  prefun = @(x) ( x >= 0 ).*( x < 1 ) .* ...
                                   (x.^4./24) ...
                                + ( x >= 1 ).*( x < 2 ) .* ...
                                   (-x.^4./6 + 5.*x.^3./6 - 5.*x.^2./4 + 5.*x./6 - 5/24) ...
                                + ( x >= 2 ).*( x < 3 ) .* ...
                                   (x.^4./4 - 5.*x.^3./2 + 35.*x.^2./4 - 25.*x./2 + 155/24) ... 
                                + ( x >= 3 ).*( x < 4 ) .* ...
                                   (-x.^4./6 + 5.*x.^3./2 - 55.*x.^2./4 + 65.*x./2 - 655/24) ... 
                                + ( x >= 4 ).*( x < 5 ) .* ...
                                   (x.^4./24 -5.*x.^3./6 + 25.*x.^2./4 - 125.*x./6 + 625/24);
            end
            fbspfun = @(y) prefun((y-1).*fb.*order./2+order/2)./prefun(order/2);
           
            freqatheightdesc = @(thr) determine_freqatheight(fbspfun,peakpos,thr,1)/basedil/scale(m);
            freqatheightasc= @(thr) determine_freqatheight(fbspfun,peakpos,thr,0)/basedil/scale(m);
            fsupp = [0 0 info.fc(m) fs fs];

            if kv.efsuppthr > 0
                fsupp(1) = max( 0,freqatheightasc(kv.efsuppthr));
                fsupp(5) = min(fs,freqatheightdesc(kv.efsuppthr));
            end
            fsupp(2) = max( 0,freqatheightasc(kv.bwthr));
            fsupp(4) = min(fs,freqatheightdesc(kv.bwthr));

            fsuppL = fsuppL_inner(fsupp,fs,L,1:5); 
            
            info.foff(m) = fsuppL(1);
            info.fsupp(m) = fsuppL(end) - fsuppL(1) + 1;
            if info.fsupp(m) <= 0, info.fsupp(m) = 0; end

            info.bw(m)  = (fsupp(4) - fsupp(2));
            bwinsamples = info.bw(m)/step;
            info.a_natural(m,2) = ceil(bwinsamples);

            CauchyAlpha = wpghi_findalpha({'fbsp',order,fb},0.2);
            info.tfr(m) = (CauchyAlpha - 1)/(pi*info.fc(m)^2*L);
                         
            if flags.do_full
                y = ((0:L-1)').*basedil*step*scale(m);
                H(:,m) = kv.scal*normalize(fbspfun(y), flags.norm);
            elseif flags.do_econ
                y = ((fsuppL(1):fsuppL(end)-1)').*basedil*step*scale(m);
                H{m} = kv.scal*normalize(fbspfun(y), flags.norm);
            elseif flags.do_asfreqfilter
                y = @(L) ((fsuppL_inner(fsupp,fs,L,1):fsuppL_inner(fsupp,fs,L,5)-1)').*basedil*scale(m)*fs/L;
                H{m} = struct('H',@(L) kv.scal*normalize(fbspfun(y(L)),flags.norm),'foff',@(L)fsuppL_inner(fsupp,fs,L,1),'realonly',0);
            end
           
         case 'analyticsp' % Positive frequency part of cosine-modulated B-spline
                  
           definputanalyticsp.keyvals.order=3;
           definputanalyticsp.keyvals.fb=1;
           [~,~,order,fb]=ltfatarghelper({'order','fb'},definputanalyticsp,winArgs);

            if order < 1 || round(order) ~= order
                error('%s: order must be integer and at least 1 (passed order=%.2f).',...
                      upper(mfilename),order);
            end
            
            if fb < 1 || round(fb) ~= fb
                error('%s: fb must be integer and at least 1 (passed fb=%.2f).',...
                      upper(mfilename),fb);
            end
            
            peakpos = 1;
            basedil = peakpos/(kv.basefc);

            info.fc(m) = peakpos/(basedil*scale(m));
            info.scale(m) = scale(m);
            info.dilation(m) = basedil*scale(m);

            if info.fc(m) <= 0 || info.fc(m) > 1
                error(['%s: fc out of range [0,1[. Decrease alpha ',...
                       '(passed %.2f) and/or scale (passed %.2f)'],...
                       upper(mfilename),alpha,scale(m));
            end
            
            anaspfun = @(y) (y>0).* (sinc( fb.*(y - 1) ).^order + sinc( fb.*( y + 1) ).^order);
           
            heightfun = @(y) min(1,(y>0).* ( 1./abs(fb.*(pi.*y - pi)).^order + 1./abs(fb.*( pi.*y + pi )).^order ));
            freqatheightdesc = @(thr) determine_freqatheight(heightfun,peakpos,thr,1)/basedil/scale(m);
            freqatheightasc= @(thr) determine_freqatheight(heightfun,peakpos,thr,0)/basedil/scale(m);
            fsupp = [0 0 info.fc(m) fs fs];

            if kv.efsuppthr > 0
                fsupp(1) = max( 0,freqatheightasc(kv.efsuppthr));
                fsupp(5) = min(fs,freqatheightdesc(kv.efsuppthr));
            end
            fsupp(2) = max( 0,freqatheightasc(kv.bwthr));
            fsupp(4) = min(fs,freqatheightdesc(kv.bwthr));

            fsuppL = fsuppL_inner(fsupp,fs,L,1:5); 
            
            info.foff(m) = fsuppL(1);
            info.fsupp(m) = fsuppL(end) - fsuppL(1) + 1;
            if info.fsupp(m) <= 0, info.fsupp(m) = 0; end

            info.bw(m)  = (fsupp(4) - fsupp(2));
            bwinsamples = info.bw(m)/step;
            info.a_natural(m,2) = ceil(bwinsamples);

            CauchyAlpha = wpghi_findalpha({'analyticsp',order,fb},0.2);
            info.tfr(m) = (CauchyAlpha - 1)/(pi*info.fc(m)^2*L);
            
            if flags.do_full
                y = ((0:L-1)').*basedil*step*scale(m);
                H(:,m) = kv.scal*normalize(anaspfun(y), flags.norm);
            elseif flags.do_econ
                y = ((fsuppL(1):fsuppL(end)-1)').*basedil*step*scale(m);
                H{m} = kv.scal*normalize(anaspfun(y), flags.norm);
            elseif flags.do_asfreqfilter
                y = @(L) ((fsuppL_inner(fsupp,fs,L,1):fsuppL_inner(fsupp,fs,L,5)-1)').*basedil*scale(m)*fs/L;
                H{m} = struct('H',@(L) kv.scal*normalize(anaspfun(y(L)),flags.norm),'foff',@(L)fsuppL_inner(fsupp,fs,L,1),'realonly',0);
            end
            
         case 'cplxsp' % Complex-modulated B-Spline
                  
           definputcplxsp.keyvals.order=3;
           definputcplxsp.keyvals.fb=1;
           [~,~,order,fb]=ltfatarghelper({'order','fb'},definputcplxsp,winArgs);

            if order < 1 || round(order) ~= order
                error('%s: order must be integer and at least 1 (passed order=%.2f).',...
                      upper(mfilename),order);
            end
            
            if fb < 1 || round(fb) ~= fb
                error('%s: fb must be integer and at least 1 (passed fb=%.2f).',...
                      upper(mfilename),fb);
            end
            
            peakpos = 1;
            basedil = peakpos/(kv.basefc);

            info.fc(m) = peakpos/(basedil*scale(m));
            info.scale(m) = scale(m);
            info.dilation(m) = basedil*scale(m);

            if info.fc(m) <= 0 || info.fc(m) > 1
                error(['%s: fc out of range [0,1[. Decrease alpha ',...
                       '(passed %.2f) and/or scale (passed %.2f)'],...
                       upper(mfilename),alpha,scale(m));
            end
            
            cplxspfun = @(y) sinc( fb.*(y - 1) ).^order;
           
            heightfun = @(y) min(1,1./abs(fb.*(pi*y - pi)).^order);
            freqatheightdesc = @(thr) determine_freqatheight(heightfun,peakpos,thr,1)/basedil/scale(m);
            freqatheightasc= @(thr) determine_freqatheight(heightfun,peakpos,thr,0)/basedil/scale(m);
            fsupp = [0 0 info.fc(m) fs fs];

            if kv.efsuppthr > 0
                fsupp(1) = max( 0,freqatheightasc(kv.efsuppthr));
                fsupp(5) = min(fs,freqatheightdesc(kv.efsuppthr));
            end
            fsupp(2) = max( 0,freqatheightasc(kv.bwthr));
            fsupp(4) = min(fs,freqatheightdesc(kv.bwthr));

            fsuppL = fsuppL_inner(fsupp,fs,L,1:5); 
            
            info.foff(m) = fsuppL(1);
            info.fsupp(m) = fsuppL(end) - fsuppL(1) + 1;
            if info.fsupp(m) <= 0, info.fsupp(m) = 0; end

            info.bw(m)  = (fsupp(4) - fsupp(2));
            bwinsamples = info.bw(m)/step;
            info.a_natural(m,2) = ceil(bwinsamples);
 
            CauchyAlpha = wpghi_findalpha({'cplxsp',order,fb},0.2);
            info.tfr(m) = (CauchyAlpha - 1)/(pi*info.fc(m)^2*L);
                         
            if flags.do_full
                y = ((0:L-1)').*basedil*step*scale(m);
                H(:,m) = kv.scal*normalize(cplxspfun(y), flags.norm);
            elseif flags.do_econ
                y = ((fsuppL(1):fsuppL(end)-1)').*basedil*step*scale(m);
                H{m} = kv.scal*normalize(cplxspfun(y), flags.norm);
            elseif flags.do_asfreqfilter
                y = @(L) ((fsuppL_inner(fsupp,fs,L,1):fsuppL_inner(fsupp,fs,L,5)-1)').*basedil*scale(m)*fs/L;
                H{m} = struct('H',@(L) kv.scal*normalize(cplxspfun(y(L)),flags.norm),'foff',@(L)fsuppL_inner(fsupp,fs,L,1),'realonly',0);
            end
         otherwise
            error('%s: SENTINEL. Unknown window.',upper(mfilename));
    end
end

if M==1 && iscell(H)
    H = H{1};
end

function fsuppL = fsuppL_inner(fsupp,fs,L,idx)
fsuppL_all = [ ceil(fsupp(1:2)/fs*L), round(fsupp(3)/fs*L), floor(fsupp(4:5)/fs*L) ];
fsuppL = fsuppL_all(idx);

function w = octave_lambertw(b,z)
% Copyright (C) 1998 by Nicol N. Schraudolph <schraudo@inf.ethz.ch>
%
% @deftypefn {Function File} {@var{x} = } lambertw (@var{z})
% @deftypefnx {Function File} {@var{x} = } lambertw (@var{n}, @var{z})
% Compute the Lambert W function of @var{z}.
%
% This function satisfies W(z).*exp(W(z)) = z, and can thus be used to express
% solutions of transcendental equations involving exponentials or logarithms.
%
% @var{n} must be integer, and specifies the branch of W to be computed;
% W(z) is a shorthand for W(0,z), the principal branch.  Branches
% 0 and -1 are the only ones that can take on non-complex values.
%
% If either @var{n} or @var{z} are non-scalar, the function is mapped to each
% element; both may be non-scalar provided their dimensions agree.
%
% This implementation should return values within 2.5*eps of its
% counterpart in Maple V, release 3 or later.  Please report any
% discrepancies to the author, Nici Schraudolph <schraudo@@inf.ethz.ch>.

if (nargin == 1)
    z = b;
    b = 0;
else
    %% some error checking
    if (nargin ~= 2)
        print_usage;
    else
        if (any(round(real(b)) ~= b))
            usage('branch number for lambertw must be integer')
        end
    end
end

%% series expansion about -1/e
%
% p = (1 - 2*abs(b)).*sqrt(2*e*z + 2);
% w = (11/72)*p;
% w = (w - 1/3).*p;
% w = (w + 1).*p - 1
%
% first-order version suffices:
%
w = (1 - 2*abs(b)).*sqrt(2*exp(1)*z + 2) - 1;

%% asymptotic expansion at 0 and Inf
%
v = log(z + double(~(z | b))) + 2*pi*1i*b;
v = v - log(v + double(v==0));

%% choose strategy for initial guess
%
c = abs(z + 1/exp(1));
c = (c > 1.45 - 1.1*abs(b));
c = c | (b.*imag(z) > 0) | (~imag(z) & (b == 1));
w = (1 - c).*w + c.*v;

%% Halley iteration
%
for n = 1:10
    p = exp(w);
    t = w.*p - z;
    f = (w ~= -1);
    t = f.*t./(p.*(w + f) - 0.5*(w + 2.0).*t./(w + f));
    w = w - t;
    if (abs(real(t)) < (2.48*eps)*(1.0 + abs(real(w))) ...
        && abs(imag(t)) < (2.48*eps)*(1.0 + abs(imag(w))))
        return
    end
end

%error('PRECISION:iteration limit reached, result of lambertw may be inaccurate');

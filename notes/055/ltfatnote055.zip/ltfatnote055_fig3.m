load('results_exp3.mat');
SConvPGHIexp3=SConvPGHI;


SConvPGHIexp3min = min(SConvPGHIexp3,[],1);
SConvPGHIexp3minsort = zeros(6,3);
for ii = 1:3
  for jj = 1:2
    SConvPGHIexp3minsort((ii-1)*2+jj,:)= SConvPGHIexp3min(1,ii,jj,:);
  end
end




SConvPGHIexp3med = median(SConvPGHIexp3,1);
SConvPGHIexp3medsort = zeros(6,3);
for ii = 1:3
  for jj = 1:2
    SConvPGHIexp3medsort((ii-1)*2+jj,:)= SConvPGHIexp3med(1,ii,jj,:);
  end
end




SConvPGHIexp3max = max(SConvPGHIexp3,[],1);
SConvPGHIexp3maxsort = zeros(6,3);
for ii = 1:3
  for jj = 1:2
    SConvPGHIexp3maxsort((ii-1)*2+jj,:)= SConvPGHIexp3max(1,ii,jj,:);
  end
end

figure(3);
hold on;
mainlinex = zeros(2,1);
mainliney = zeros(2,1);
ticklinex = zeros(2,1);
tickliney = zeros(2,1);
for ii = 1:6
    locy = ii-0.2; %y-axis location
    locxmin = SConvPGHIexp3minsort(ii,1);
    locxmed = SConvPGHIexp3medsort(ii,1);
    locxmax = SConvPGHIexp3maxsort(ii,1);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p1=plot(mainlinex,mainliney,'--r');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    
    locy = ii; %y-axis location
    locxmin = SConvPGHIexp3minsort(ii,2);
    locxmed = SConvPGHIexp3medsort(ii,2);
    locxmax = SConvPGHIexp3maxsort(ii,2);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p2=plot(mainlinex,mainliney,'-k');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    
    
    locy = ii+0.2; %y-axis location
    locxmin = SConvPGHIexp3minsort(ii,3);
    locxmed = SConvPGHIexp3medsort(ii,3);
    locxmax = SConvPGHIexp3maxsort(ii,3);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p3=plot(mainlinex,mainliney, '-.b');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    
end

yticks(1:6)
yticklabels({...
          'C \xi 1', ...
          'MB4 \xi 1', ...
          'C \xi 3', ...
          'MB4 \xi 3', ...
          'C \xi 10', ...
          'MB4 \xi 10'...
        })

legend([p1, p2, p3],{'WPGHI','0-FGLIM','W-FGLIM'});
hold off;







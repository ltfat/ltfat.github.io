\page dgttheory Discrete Gabor transform (also called STFT)



For more details please see
\cite ltfatnote003
\cite ltfatnote006
\cite ltfatnote011


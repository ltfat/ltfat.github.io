\defgroup spsi Single Pass Spectrogram Inversion
\addtogroup spsi

Algorithm Description
---------------------

The implementation follows papers \cite be15 .



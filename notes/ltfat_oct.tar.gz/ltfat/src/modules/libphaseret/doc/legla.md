\defgroup legla Le Roux's Modifications of the Griffin-Lim Algorithm
\addtogroup legla

Algorithm Description
---------------------

The implementation follows papers \cite leroux08 \cite leroux10.

Algorithm Acceleration
----------------------

\cite pebaso13

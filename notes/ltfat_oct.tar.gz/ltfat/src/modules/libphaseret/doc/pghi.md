\defgroup pghi Phase Gradient Heap Integration
\addtogroup pghi

Algorithm Description
---------------------

The implementation follows paper \cite ltfatnote040.

Please note that the gollowing relation holds between
\f$\lambda\f$ used in the paper and \f$\gamma\f$ used in this
implementation
\f[
\gamma = \lambda L,
\f]
where \f$L\f$ is the transform length.








\mainpage Phase Retrieval Toolbox Library


Algorithms
----------

#### Offline #
- \ref gla
- \ref legla
- \ref pghi

#### Real-time #
- \ref rtisila
- \ref rtpghi
- \ref spsi

Conventions
-----------

The library follows the same conventions as the
[libltfat](http://ltfat.github.io/libltfat).






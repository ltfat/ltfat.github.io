\defgroup rtisila Real-Time Spectrogram Inversion with Look Ahead
\addtogroup rtisila

Algorithm Description
---------------------

The implementation follows paper \cite zhbewy07. 



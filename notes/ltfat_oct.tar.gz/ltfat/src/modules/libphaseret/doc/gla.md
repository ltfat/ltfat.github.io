\defgroup gla Griffin-Lim Algorithm
\addtogroup gla

Algorithm Description
---------------------

The implementation follows papers \cite griflim84 \cite pebaso13


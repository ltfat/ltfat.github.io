% This script reproduces Figure 3 of the manuscript 
%
% 'Insert title here' 
% 
% when supplied with signal 54 (male german speech) 
% from the EDU SQAM dataset
%
% https://tech.ebu.ch/publications/sqamcd
%
% You can use your own signals and wavelet parameters
% by modifying the file below.
%
% Version: November 27, 2018
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2018)

%% Preparation

clear all;

disp('--- Used subroutines ---');

which comp_filterbankheapint
which comp_filterbankmaskedheapint
which comp_ufilterbankheapint
which comp_ufilterbankmaskedheapint
which comp_filterbankphasegradfrommag

%% Prepare to load test signal

path = '~/testsignal/';	% Place your test signal wav file here
listing = dir([path,'*.wav']);
allwavsCell = arrayfun(@(wav) fullfile(path,wav.name),listing,'UniformOutput',0);

% Select file, load and normalize
fileNo = 1;
wavfile = allwavsCell{fileNo};
[~,filename,ext] = fileparts(wavfile);
[f,fs] = wavload(wavfile);
f = normalize(f,'wav');

%% Cauchy wavelet parameters
filtNos = [300, 180, 125, 90];		% Number of scales
alphas  = [1000,1000,1000,1000];	% Cauchy wavelet order
a_array = [ 10, 18, 25, 30];		% Decimation factor

L = 5*44100;				% Desired signal length
start = 0;				% From sample

% Truncate signal 
f = f(start+1:start+5*fs,1);   

%% Compute coefficients, plot scalogram and phase differences

for jj=1:numel(filtNos)

fprintf('WAVELETFILTERS alpha=%.2f, filters=%d, a=%.2f \n', alphas(jj), filtNos(jj), a_array(jj));

% Initialize wavelet filters
[gs,info] = ltfatnote053_waveletfilters(L,2.^linspace(6,-3.3,filtNos(jj)),{'cauchy',alphas(jj)});
as=a_array(jj);
  
fprintf('\n--------------------------------%s--------------------------------------\n',wavfile);

% Compute coefficients
c_orig = ufilterbank(f,gs,as);
abss = abs(c_orig);
[N,M] = size(abss);

if jj == 1 % Plot scalogram (only for first parameter set)
    F = figure(1);
    plotfilterbank(c_orig,as,'dynrange',90,'fc',info.fc*fs/2,'fs',fs,'audtick');
    title('Male Speech Excerpt');
    saveas(F,'Spectrogram.png')

%   % Uncomment for gray level plots
%     colormap(flipud(gray));
%     saveas(F,'Spectrogram_Gray.png')
end

% Compute phase estimate
tfr = info.tfr(L);
ctemp=filterbankconstphase(abss(:,2:end-1),as,info.fc(2:end-1),tfr(2:end-1),'wavelet','tol',1e-10);
ctemp = [abss(:,1),ctemp,abss(:,end)];

F=figure(1+jj);	% Plot phase differences
plotfilterbankphasediff(c_orig,ctemp,1e-4,as,'fc',info.fc*fs/2,'fs',fs,'audtick');drawnow;
title(['Phase difference (Redundancy ',num2str(filtNos(jj)/a_array(jj)),')']);
colorbar off;
saveas(F,['PhaseDiffRed',num2str(filtNos(jj)/a_array(jj)),'.png'])

%   % Uncomment for gray level plots
%     colormap(flipud(gray));
%     saveas(F,['PhaseDiffRed',num2str(filtNos(jj)/a_array(jj)),'_Gray.png'])
end
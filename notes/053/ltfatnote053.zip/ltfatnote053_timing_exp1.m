% This script provides timing results for Experiment 1
% in the manuscript 
%
% N.Holighaus, G. Koliander, Z. Prusa and L. D. Abreu,
% Characterization of Analytic Wavelet Transforms and 
% a New Phaseless Reconstruction Algorithm
%   
% http://ltfat.github.io/notes/053/
% 
% Version: November 27, 2018
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2018)  

load('./data/ltfatnote053_timing_exp1.mat')
 
 means = zeros(4,3);
 stds = zeros(4,3);
 
 for kk = 1:3
     means(:,kk) = mean(squeeze(Timing(:,kk,:)));
     stds(:,kk) = std(squeeze(Timing(:,kk,:)));
 end
 
 all = zeros(4,6);
 all(:,1:2:end) = means;
 all(:,2:2:end) = stds;
 
 mat2tex(all','table')

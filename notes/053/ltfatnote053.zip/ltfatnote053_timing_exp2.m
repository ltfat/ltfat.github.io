 load('./data/ltfatnote053_timing_exp2.mat')
 
 means = zeros(2,4);
 stds = zeros(2,4);
 
 for kk = 1:4
     means(:,kk) = mean(squeeze(Timing(:,kk,:)));
     stds(:,kk) = std(squeeze(Timing(:,kk,:)));
 end
 
 all = zeros(2,8);
 all(:,1:2:end) = means;
 all(:,2:2:end) = stds;
 
 mat2tex(all','table')

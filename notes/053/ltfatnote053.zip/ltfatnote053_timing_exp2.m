% This script provides timing results for Experiment 2
% in the manuscript 
%
% N.Holighaus, G. Koliander, Z. Prusa and L. D. Abreu,
% Characterization of Analytic Wavelet Transforms and 
% a New Phaseless Reconstruction Algorithm
%   
% http://ltfat.github.io/notes/053/
% 
% Version: November 27, 2018
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2018)  


 load('./data/ltfatnote053_timing_exp2.mat')
 
 means = zeros(2,4);
 stds = zeros(2,4);
 
 for kk = 1:4
     means(:,kk) = mean(squeeze(Timing(:,kk,:)));
     stds(:,kk) = std(squeeze(Timing(:,kk,:)));
 end
 
 all = zeros(2,8);
 all(:,1:2:end) = means;
 all(:,2:2:end) = stds;
 
 mat2tex(all','table')

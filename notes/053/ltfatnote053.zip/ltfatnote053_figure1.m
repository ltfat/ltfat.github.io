% This script reproduces Figure 2 of the manuscript 
%
% 'Insert title here' 
% 
% Version: November 27, 2018
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2018)

load('./data/ltfatnote053_results_exp1.mat');

param_set = 1;

F = figure(1);

[~,I] = sort(SConvPGHI(:,param_set,3));

clf
plot(squeeze(SConvPGHI(I,param_set,:)))
xlabel('Signals sorted by performance of RAND-initialized FGLIM')
ylabel('Spectral Convergence')
legend('WPGHI','FBPGHI','FGLIM-RAND','FGLIM-WPGHI')

fprintf('\n Signal number / Position in Figure 1 \n');
[(1:70);I']

%---------------------
%---------------------

param_set = 2;

F = figure(2);

[~,I] = sort(SConvPGHI(:,param_set,3));

clf
plot(squeeze(SConvPGHI(I,param_set,:)))
xlabel('Signals sorted by performance of RAND-initialized FGLIM')
ylabel('Spectral Convergence')
legend('WPGHI','FBPGHI','FGLIM-RAND','FGLIM-WPGHI')

fprintf('\n Signal number / Position in Figure 2 \n');
[(1:70);I']

%---------------------
%---------------------

param_set = 3;

F = figure(3);

[~,I] = sort(SConvPGHI(:,param_set,3));

clf
plot(squeeze(SConvPGHI(I,param_set,:)))
xlabel('Signals sorted by performance of RAND-initialized FGLIM')
ylabel('Spectral Convergence')
legend('WPGHI','FBPGHI','FGLIM-RAND','FGLIM-WPGHI')

fprintf('\n Signal number / Position in Figure 3 \n');
[(1:70);I']


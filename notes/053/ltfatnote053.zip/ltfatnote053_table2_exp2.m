% This script reproduces Table 2 of the manuscript 
%
% N.Holighaus, G. Koliander, Z. Prusa and L. D. Abreu,
% Characterization of Analytic Wavelet Transforms and 
% a New Phaseless Reconstruction Algorithm
%   
% http://ltfat.github.io/notes/053/
% 
% Version: November 27, 2018
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2018) 

 load(''./data/ltfatnote053_results_exp2.mat')
 
 means = zeros(2,4);
 stds = zeros(2,4);
 
 for kk = 1:4
     means(:,kk) = mean(squeeze(SConvPGHI(:,kk,:)));
     stds(:,kk) = std(squeeze(SConvPGHI(:,kk,:)));
 end
 
 all = zeros(2,8);
 all(:,1:2:end) = means;
 all(:,2:2:end) = stds;
 
 mat2tex(all','table')

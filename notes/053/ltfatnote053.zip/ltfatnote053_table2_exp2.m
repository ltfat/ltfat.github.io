 load(''./data/ltfatnote053_results_exp2.mat')
 
 means = zeros(2,4);
 stds = zeros(2,4);
 
 for kk = 1:4
     means(:,kk) = mean(squeeze(SConvPGHI(:,kk,:)));
     stds(:,kk) = std(squeeze(SConvPGHI(:,kk,:)));
 end
 
 all = zeros(2,8);
 all(:,1:2:end) = means;
 all(:,2:2:end) = stds;
 
 mat2tex(all','table')

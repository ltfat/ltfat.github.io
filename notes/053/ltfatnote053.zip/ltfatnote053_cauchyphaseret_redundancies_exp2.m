% This script reproduces the experimental setup in 
% Experiment 2 of the manuscript
%
% N.Holighaus, G. Koliander, Z. Prusa and L. D. Abreu,
% Characterization of Analytic Wavelet Transforms and 
% a New Phaseless Reconstruction Algorithm
%   
% http://ltfat.github.io/notes/053/
% 
% when supplied with the signals from the EBU SQAM 
% dataset
%
% https://tech.ebu.ch/publications/sqamcd
%
% Please place the input wav files in the folder 
% 
% ./input/
%
% Results will be saved in the folder
% 
% ./output/
%
% !Attention! 
% Computing all parameter sets on the full EBU SQAM
% dataset may take several hours of computation time.
%
% For a smaller test set, only place the desired files
% in the input folder. You can also use your own signals 
% and wavelet parameters by modifying the file below.
%
% Requires the Large Time-Frequency Analysis Toolbox (LTFAT)
% version 2.4.0 or higher, with compiled C backend.
%
% Version: November 27, 2018
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2018)

%% Preparation

clear all;

disp('--- Used subroutines ---');

which comp_filterbankheapint
which comp_filterbankmaskedheapint
which comp_ufilterbankheapint
which comp_ufilterbankmaskedheapint
which comp_filterbankphasegradfrommag

%% Prepare to load test signal

path = './input/'; % Place your test signal wav files here
listing = dir([path,'*.wav']);
allwavsCell = arrayfun(@(wav) fullfile(path,wav.name),listing,'UniformOutput',0);
writepath = './output/'; % The experiment output will be saved here, make sure the folder exists

%% Cauchy wavelet parameters

filtNos = [300, 180, 125, 90];		% Number of scales
alphas  = [1000,1000,1000,1000];	% Cauchy wavelet order
a_array = [ 10, 18, 25, 30];		% Decimation factor

L = 5*44100;				% Desired signal length
start = 0;				% From sample

%% Prepare arrays for error and timing results

SConvPGHI = zeros(numel(allwavsCell),numel(alphas),4);
Timing = zeros(numel(allwavsCell),numel(alphas),4);

%% Main section
for jj=1:numel(filtNos) % Loop over parameter sets
fprintf('WAVELETFILTERS alpha=%.2f, filters=%d, a=%.2f \n', alphas(jj), filtNos(jj), a_array(jj));

% Initialize wavelet filters and dual filters
[gs,info] = ltfatnote053_waveletfilters(L,2.^linspace(6,-3.3,filtNos(jj)),{'cauchy',alphas(jj)});
as=a_array(jj);
gd = filterbankrealdual(gs,as, L);
F = frame('ufilterbankreal',gs,as,numel(gs));
Fd = frame('ufilterbankreal',gd,as,numel(gs));

tfr = info.tfr(L);

for ii=1:numel(allwavsCell) % Loop over files

% Select file and load
wavfile = allwavsCell{ii};
[~,filename,ext] = fileparts(wavfile);
[f,fs] = wavload(wavfile);

% Truncate signal and normalize conservatively
f = f(start+1:start+5*fs,1);   
f = 0.3*normalize(f,'inf');

% Write audio file of input signal
filenameW = [writepath,filename,'_ORG.flac'];
audiowrite(filenameW,real(f),fs);
    
fprintf('\n--------------------------------%s--------------------------------------\n',wavfile);

% Compute coefficients
c_orig = ufilterbank(f,gs,as);
abss = abs(c_orig);
[N,M] = size(abss);

%%  ----------  Wavelet PGHI reconstruction  ----------  

% Compute wavelet PGHI phase estimate
tic;
ctemp=filterbankconstphase(abss(:,2:end-1),as,info.fc(2:end-1),tfr(2:end-1),'wavelet','tol',1e-10);
ctemp = [abss(:,1),ctemp,abss(:,end)];
timeWPGHI = toc;

% Reconstruction using wavelet PGHI phase estimate
tic;
fhat1 = ifilterbank(ctemp,gd,as,'real');
timeifiltW = toc;

% Compute spectral convergence error, save error and timing
cproj = ufilterbank(fhat1,gs,as);
Cdb1 = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
SConvPGHI(ii,jj,1) = Cdb1;
Timing(ii,jj,1) = timeWPGHI + timeifiltW;

% Write output file
clear cproj;
filenameW = [writepath,filename,'_red_',num2str(filtNos(jj)/a_array(jj)),'_WPGHI.flac'];
audiowrite(filenameW,real(fhat1),fs);
clear fhat1;

%%  ----------  WPGHI fast Griffin-Lim reconstruction  ----------  

% Iterative phaseless reconstruction using fast Griffin-Lim 
% with wavelet PGHI estimate as initial phase
tic;
fhat4 = frsynabs(F,framenative2coef(F,ctemp),L,'fgriflim','Fd',Fd,'input');
timeWFGLIM = toc;

% Compute spectral convergence error, save error and timing
cproj = ufilterbank(fhat4,gs,as);
Cdb4 = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
SConvPGHI(ii,jj,2) = Cdb4;
Timing(ii,jj,2) = timeWPGHI+timeWFGLIM;

% Write output file
clear cproj ctemp;
filenameW = [writepath,filename,'_red_',num2str(filtNos(jj)/a_array(jj)),'_FGLIM_WPGHI.flac'];
audiowrite(filenameW,real(fhat4),fs);
clear fhat4;

% Print error values
fprintf('Wavelet formula C=%.2f dB, FGLIM WPGHI init C=%.2f dB\n',Cdb1,Cdb4);

clear timeWPGHI timeWFGLIM timeifiltW;

end
end

% % Uncomment to save results
% save([writepath,'results_exp2.mat'],'SConvPGHI');
% save([writepath,'timing_exp2.mat'],'Timing');

% This script reproduces Figure 2 of the manuscript 
%
% 'Insert title here' 
% 
% Version: November 27, 2018
% Copyright: Nicki Holighaus, Guenther Koliander, Zdenek Prusa, Luis Daniel Abreu (2018)

load('./data/ltfatnote053_results_exp2.mat');

param_set = 1;

F = figure(1);

[~,I] = sort(SConvPGHI(:,2,param_set));

clf
plot(squeeze(SConvPGHI(I,:,param_set)))
xlabel('Signals sorted by performance of MedHigh redundant system')
ylabel('Spectral Convergence')
legend('High','MedHigh','Med','Low')

fprintf('\n Signal number / Position in Figure 1 \n');
[(1:70);I']

%---------------------
%---------------------

param_set = 2;

[~,I] = sort(SConvPGHI(:,2,param_set));

F = figure(2);

clf
plot(squeeze(SConvPGHI(I,:,param_set)))
xlabel('Signals sorted by performance of MedHigh redundant system')
ylabel('Spectral Convergence')
legend('High','MedHigh','Med','Low')

fprintf('\n Signal number / Position in Figure 2 \n');
[(1:70);I']


 load('./data/ltfatnote053_results_exp1.mat')
 
 means = zeros(4,3);
 stds = zeros(4,3);
 
 for kk = 1:3
     means(:,kk) = mean(squeeze(SConvPGHI(:,kk,:)));
     stds(:,kk) = std(squeeze(SConvPGHI(:,kk,:)));
 end
 
 all = zeros(4,6);
 all(:,1:2:end) = means;
 all(:,2:2:end) = stds;
 
 mat2tex(all','table')

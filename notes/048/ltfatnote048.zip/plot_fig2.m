function plot_fig2(varargin)

relrespath = ['texexport', filesep, 'comparebest_sqam_a256_M2048_gl2048_truncgauss'];
basepath = fileparts(which(mfilename));
resdir = [basepath,filesep,relrespath];

lookahead = 2;

res_pattern = sprintf('all_truncgausssqam_a256_M2048_gl2048_la%d_it24.mat',lookahead);


load([resdir,filesep,res_pattern]);

CgsrtisilaAll  = 20*log10(sort(CgsrtisilaAll,'descend'));
CrtisilaAll   = 20*log10(sort(CrtisilaAll,'descend'));   
CgsrtisilawsAll = 20*log10(sort(CgsrtisilawsAll,'descend'));
CrtpghiAll  = 20*log10(sort(CrtpghiAll,'descend'));

Crtpghistat = compstat(CrtpghiAll);
Crtisilastat = compstat(CrtisilaAll);
Cgsrtisilastat = compstat(CgsrtisilaAll);
Cgsrtisilawsstat = compstat(CgsrtisilawsAll);

fprintf('RTPGHI(1):     max: %.2f, 3. quart: %.2f, median: %.2f, 1. quart: %.2f, min: %.2f\n',Crtpghistat);
fprintf('RTISI-LA(%d):   max: %.2f, 3. quart: %.2f, median: %.2f, 1. quart: %.2f, min: %.2f\n',lookahead,Crtisilastat);
fprintf('GSRTISI-LA(%d): max: %.2f, 3. quart: %.2f, median: %.2f, 1. quart: %.2f, min: %.2f\n',lookahead,Cgsrtisilastat);
fprintf('Proposed(%d):   max: %.2f, 3. quart: %.2f, median: %.2f, 1. quart: %.2f, min: %.2f\n',lookahead,Cgsrtisilawsstat);

fid = fopen([basepath,filesep,'texexport',filesep,'fig1.csv'],'w');
fprintf(fid,'alg , max, third, median, first, min\n');
fprintf(fid,'RTPGHI(1),%.2f,%.2f,%.2f,%.2f,%.2f\n',Crtpghistat);
fprintf(fid,'RTISI-LA(%d),%.2f,%.2f,%.2f,%.2f,%.2f\n',lookahead,Crtisilastat);
fprintf(fid,'GSRTISI-LA(%d),%.2f,%.2f,%.2f,%.2f,%.2f\n',lookahead,Cgsrtisilastat);
fprintf(fid,'Proposed(%d),%.2f,%.2f,%.2f,%.2f,%.2f\n',lookahead,Cgsrtisilawsstat);
fclose(fid);


function stat = compstat(arr)
N = numel(arr);

iiceil = ceil(N*[1/4,1/2,3/4]);
iifloor = floor(N*[1/4,1/2,3/4]);



stat = [arr(1),...
        (arr(iiceil(1))+arr(iifloor(1)))/2,...
        (arr(iiceil(2))+arr(iifloor(2)))/2,...
        (arr(iiceil(3))+arr(iifloor(3)))/2,...
        arr(end)];





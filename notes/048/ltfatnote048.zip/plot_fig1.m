function plot_fig1()


figure(1);ylim0 = plot_subfig1(0);
figure(2);ylim1 =plot_subfig1(1);
figure(3);ylim2 =plot_subfig1(2);
figure(4);ylim3 =plot_subfig1(3);
figure(5);ylim7 =plot_subfig1(7);

ylimm = ylim0;
ylimm(1) = min([ylim0(1);ylim1(1);ylim2(1);ylim3(1);ylim7(1)]);
ylimm(2) = max([ylim0(2);ylim1(2);ylim2(2);ylim3(2);ylim7(2)]);


figure(1);plot_subfig1(0,ylimm);
figure(2);plot_subfig1(1,ylimm);
figure(3);plot_subfig1(2,ylimm);
figure(4);plot_subfig1(3,ylimm);
figure(5);plot_subfig1(7,ylimm);

%figure(1); l = legend; set(l,'Location','southeast');

function ylimm = plot_subfig1(lookahead,ylimm)
clf;

amgltriplet = sprintf('a%i_M%i_gl%i',256,2048,2048);

relrespath = ['texexport', filesep, sprintf('comparebest_sqam_%s_truncgauss',amgltriplet)];
basepath = fileparts(which(mfilename));
resdir = [basepath,filesep,relrespath];


res_pattern = ['all_truncgausssqam_',amgltriplet,'_la%s_it%s.mat'];


perframebase = [3, 8, 16, 24, 32, 40, 96, 200];

% if numel(perframeit) ~= numel(dir([resdir,filesep,sprintf(res_pattern,'*')]))
%     error('Please run repr_fig2 first!');
% end

set(0,'defaultAxesLineStyleOrder','d-|o-|v-|s-|^-');

hold on;

linestyles = {'-','-','--','-','--'};

minplot = 0;
maxplot = -100;
handles = [];
legends = {};

for jj = 1:numel(lookahead)

    rtisilaplot = [];
    gsrtisilaplot = [];
    gsrtisilawsplot = [];
    
    basetmp = perframebase(perframebase >= (lookahead(jj) + 1));
    
    perframeit = ceil(basetmp/(lookahead(jj)+1))*(lookahead(jj)+1);
    if lookahead(jj)>0
        perframeit2 = floor(basetmp/lookahead(jj))*lookahead(jj);
    else
        perframeit2 = perframeit;
    end
    for ii = 1:numel(basetmp)
   
           load([resdir,filesep,sprintf(res_pattern,num2str(lookahead(jj)),num2str(basetmp(ii)))]);

           rtpghiplot = (20*log10(mean(CrtpghiAll)));
           rtisilaplot(end+1) = (20*log10(mean(CrtisilaAll)));
           gsrtisilaplot(end+1) = (20*log10(mean(CgsrtisilaAll)));
           gsrtisilawsplot(end+1) = (20*log10(mean(CgsrtisilawsAll)));
    end


h1 = plot(perframeit,[rtisilaplot],['k*',linestyles{jj}],'MarkerSize',11);
h2 = plot(perframeit,[gsrtisilaplot],['ko',linestyles{jj}] ,'MarkerSize',11);
h3 = plot(perframeit2,gsrtisilawsplot,['kd', linestyles{jj}],'MarkerSize',11);

rtpghilookahead = 1;
rtpghilookahead2 = 1;
gsrtisilalookahead = lookahead(jj)-1;
if lookahead(jj) == 0
   rtpghilookahead2 = 0; 
end

if lookahead(jj) <= 1
    rtpghilookahead = 0;
    gsrtisilalookahead = lookahead(jj);
end
handles(end+1:end+3) = [h1,h2,h3];
legends(end+1:end+3) = {sprintf('RTISI-LA(%i)',lookahead(jj)),...
                        sprintf('GSRTISI-LA(%i)',lookahead(jj)),...
                        sprintf('RTPGHI(%i) + GSRTISI-LA(%i)',rtpghilookahead,gsrtisilalookahead),...
                };

minplot = min(minplot, ceil(min(min([rtisilaplot;gsrtisilaplot;gsrtisilawsplot]))));
maxplot = max(maxplot,floor(max(max([rtisilaplot;gsrtisilaplot;gsrtisilawsplot]))));
end

if nargin < 2
    ylimm = [minplot,maxplot];
end

 h = line([0,perframeit(end)],[rtpghiplot,rtpghiplot],'DisplayName','RTPGHI(1)');
 handles(2:end+1) = handles;
 handles(1) = h;
 legends(2:end+1) = legends;
 legends(1) = {sprintf('RTPGHI(%i)',rtpghilookahead2)}; 
 set(h,'LineStyle','--');
 set(h,'Marker','None');
 set(h,'Color',[0.2,0.2,0.2]);
hold off;

axis tight;
xlim([0,perframeit(end)+1]);

ylabel('Spectral convergence [dB]','FontSize',18);
xlabel('Number of iterations','FontSize',18);

set(gca,'FontSize',16);
ahs = findall(gca,'type','line');

for ii=1:numel(ahs)
    set(ahs(ii), 'LineWidth', 1.5);
end

set(gcf,'Position',[ 247 1078 1000 350]);

%h =legend({'RTISI-LA(7)','GSRTISI-LA(7)','RTPGHI(1) + GSRTISI-LA(6)'});
h =legend(handles,legends);
legend boxoff;
set(h,'FontSize',16);
set(h,'Location','northoutside');
set(h,'Orientation','horizontal');
h2 = findobj(h,'type', 'axes');
%set(h2(1),'visible','off');
% p = get(h,'Position');
% set(h,'Position',[p(1),p(2),p(3)*1,p(4)]);

ylim([ylimm(1)-1,ylimm(2)+1]);
set(gca,'YTick',[ylimm(1):3:ylimm(2)]');
set(gca,'YTickLabel',[ylimm(1):3:ylimm(2)]');


basepath = fileparts(which(mfilename));
exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

have_exportfig = ~isempty(which('export_fig'));

lookaheadstr = sprintf('%d_',lookahead);
lookaheadstr(end) = [];
if have_exportfig
  export_fig(sprintf([exportdir,filesep,'convergence_LA%s.pdf'],lookaheadstr),'-transparent','-painters','-p10');  
else
  saveas(gcf,sprintf([exportdir,filesep,'convergence.pdf'],ii));  
end




function generate_results
% The EBU SQAM database is available freely from 
% https://tech.ebu.ch/publications/sqamcd
% Just download and unpack the archive in the following directory 
relDatabasepath = 'Databases';
% such that all the files reside in the following subdirectory
subdirs = {'SQAM'};
% The resulting files are flac files.
% The following Bash command converts all flac files in the
% current directory to wav files provided "flac - Command-line FLAC
% encoder/decoder" is installed
% ls *.flac | xargs flac -df

basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];

exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

maxsamples = 10*44100;

a = 256;
M = 2048;
gl = 2048;

callcompare2 = @(gname,a,M,gl,varargin) comparebest(databasePath,...
     subdirs,'exportdir',exportdir,gname,'expname',sprintf('sqam_a%i_M%i_gl%i',a,M,gl),...
     'M',M,'a',a,'gl',gl,'donotstorewavs','maxsamples',maxsamples,...
     varargin{:});


perframebase = [3, 8, 16, 24, 32, 40, 96, 200];
lookaheadArr = [0, 1, 2, 3, 7];


for lookahead = lookaheadArr
    for perframeit = perframebase
        if perframeit < (lookahead + 1), continue; end;
        
        if lookahead == 2 && perframeit == 24
            callcompare2('truncgauss',a,M,gl,'perframeit',perframeit,'lookahead',lookahead,'storewavs');
            continue;
        end
        
        if lookahead <= 1
            callcompare2('truncgauss',a,M,gl,'perframeit',perframeit,'lookahead',lookahead,'rtpghicausal');
        else
            callcompare2('truncgauss',a,M,gl,'perframeit',perframeit,'lookahead',lookahead);
        end
    end
end


function comparebest(databasePath,subdirs,varargin)

definput.keyvals.a=256;
definput.keyvals.M=2048;
definput.keyvals.maxsamples=[];
definput.keyvals.gl=[];
definput.keyvals.thr=1e-6;
definput.keyvals.perframeit=8;
definput.keyvals.lookahead= 3;
definput.keyvals.exportdir = [];
definput.keyvals.expname = 'experiment';
definput.flags.rtpghiversion = {'rtpghinormal','rtpghicausal'};
definput.flags.winmod = {'truncgauss','hann','hamming','blackman'};
definput.flags.writewavs = {'donotstorewavs','storewavs'};
[flags,kv,a,M]=ltfatarghelper({'a','M'},definput,varargin);
thr = kv.thr;

if isempty(kv.gl), kv.gl = kv.M; end

fprintf(['---- %s WINDOW, a=%i, M=%i, gl=%i, lookahead=%i, maxit=%i',...
'-----------------------\n'],flags.winmod,kv.a,kv.M,kv.gl,kv.lookahead,kv.perframeit);
outputdir = [kv.exportdir,filesep,mfilename,'_',kv.expname,'_',flags.winmod];
prefix = [databasePath,filesep];

CgsrtisilawsAll = [];
CgsrtisilaAll = [];
CrtpghiAll = [];
CrtisilaAll = [];

for jj= 1:numel(subdirs)
    subdir = subdirs{jj};
    
    dirname = [prefix,subdir,filesep];
    allwavs = dir([dirname,'*.wav']);
    
    for ii=1:numel(allwavs)
        wavfile = allwavs(ii).name;
        name = wavfile(1:strfind(wavfile,'.')-1);
        nameoutdir = [outputdir,filesep,name,filesep];
        origwav = [nameoutdir,name,'.wav'];
        
        if ~exist(outputdir, 'dir')
            mkdir(outputdir);
        end
        
        if ~exist(nameoutdir, 'dir')
            mkdir(nameoutdir);
        end
        
        [f,fs] = wavload([dirname,wavfile]);
        f = normalize(f(:,1),'wav');
        if ~isempty(kv.maxsamples)
            f = f(1:min([kv.maxsamples,numel(f)]));
        end
        Ls = numel(f);
        L = dgtlength(Ls,a,M);
        f = postpad(f,L);
        
        if flags.do_storewavs
            wavsave(f,fs,origwav);
        end

        switch flags.winmod
            case 'truncgauss'
                h = 0.01;
                gnum = gabwin({'gauss','width',kv.gl,'atheight',h},a,M,10*M);
                gnum = normalize(long2fir(gnum,kv.gl),'inf');
                gamma = -pi/4*(kv.gl)^2/log(h);
            case 'hann'
                g = {'hann',kv.gl};
                gnum = gabwin(g,a,M);
                gamma = 0.25645*(kv.gl)^2;
            case 'hamming'
                g = {'hamming',kv.gl};
                gnum = gabwin(g,a,M);
                gamma = 0.29794*(kv.gl)^2;
            case 'blackman'
                g = {'blackman',kv.gl};
                gnum = gabwin(g,a,M);
                gamma = 0.17954*(kv.gl)^2;               
        end
        gdnum = gabdual(gnum,a,M,L);
        
        
        c = dgtreal(f,gnum,a,M,'timeinv');
        
        s = abs(c);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        chatrtisila = rtisila(s,gnum,a,M,'maxit',ceil(kv.perframeit/(kv.lookahead+1)),'lookahead',kv.lookahead,'timeinv');
        fhatrtisila = comp_isepdgtreal(chatrtisila,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatrtisila,gnum,a,M,'timeinv');
        Crtisila = magnitudeerr(c,nextprojc);
        Crtisiladb = 20*log10(Crtisila);
        CrtisilaAll(end+1) = Crtisila;
        
        if flags.do_storewavs
            writetex(sprintf([nameoutdir,name,'_rtisila%d.tex'],kv.lookahead),Crtisiladb);
            testwavfile = [nameoutdir,name,sprintf('_rtisila%d.wav',kv.lookahead)];
            wavsave(normalize(fhatrtisila,'wav'),fs,testwavfile);
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if kv.lookahead==0 || flags.do_rtpghicausal
            chatgsrtisilaws = gsrtisila(s,gnum,a,M,'maxit',ceil(kv.perframeit/(kv.lookahead+1)),'lookahead',kv.lookahead,'timeinv','rtpghi',{gamma,thr,'causal'});
        else
            chatgsrtisilaws = gsrtisila(s,gnum,a,M,'maxit',floor(kv.perframeit/kv.lookahead),'lookahead',kv.lookahead-1,'timeinv','rtpghi',{gamma,thr});
        end
        fhatgsrtisilaws = comp_isepdgtreal(chatgsrtisilaws,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatgsrtisilaws,gnum,a,M,'timeinv');
        Cgsrtisilaws = magnitudeerr(c,nextprojc);
        Cgsrtisilawsdb = 20*log10(Cgsrtisilaws);
        CgsrtisilawsAll(end+1) = Cgsrtisilaws;
        
        if flags.do_storewavs
            suffix = '_rtpghi%d_gsrtisila%d';
            if kv.lookahead==0 || flags.do_rtpghicausal
                suffix = sprintf(suffix,0,kv.lookahead);
            else
                suffix = sprintf(suffix,1,kv.lookahead-1);
            end
            writetex([nameoutdir,name,suffix,'.tex'],Cgsrtisilawsdb);
            testwavfile = [nameoutdir,name,suffix,'.wav'];
            wavsave(normalize(fhatgsrtisilaws,'wav'),fs,testwavfile);
        end
 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        chatgsrtisila = gsrtisila(s,gnum,a,M,'maxit',ceil(kv.perframeit/(kv.lookahead+1)),'lookahead',kv.lookahead,'timeinv');
        fhatgsrtisila = comp_isepdgtreal(chatgsrtisila,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatgsrtisila,gnum,a,M,'timeinv');
        Cgsrtisila = magnitudeerr(c,nextprojc);
        Cgsrtisiladb = 20*log10(Cgsrtisila);
        CgsrtisilaAll(end+1) = Cgsrtisila;
        
        if flags.do_storewavs
            writetex(sprintf([nameoutdir,name,'_gsrtisila%d.tex'],kv.lookahead),Cgsrtisiladb);
            testwavfile = [nameoutdir,name,sprintf('_gsrtisila%d.wav',kv.lookahead)];
            wavsave(normalize(fhatgsrtisila,'wav'),fs,testwavfile);
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if kv.lookahead==0
            chatrtint = rtpghi(s,gamma,a,M,thr,'timeinv','causal');
        else
            chatrtint = rtpghi(s,gamma,a,M,thr,'timeinv');
        end
        fhatrtint = comp_isepdgtreal(chatrtint,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatrtint,gnum,a,M,'timeinv');
        Crtpghi = magnitudeerr(c,nextprojc);
        Crtpghidb = 20*log10(Crtpghi);
        CrtpghiAll(end+1) = Crtpghi; 
        
        if flags.do_storewavs
            suffix = '_rtpghi%d';
            if kv.lookahead==0 
                suffix = sprintf(suffix,0);
            else
                suffix = sprintf(suffix,1);
            end
            
            writetex([nameoutdir,name,suffix,'.tex'],Crtpghidb);
            testwavfile = [nameoutdir,name,suffix,'.wav'];
            wavsave(normalize(fhatrtint,'wav'),fs,testwavfile);
        end
        
       
        fprintf(['RTPGHI: %.2f, RTISILA %.2f, GSRTISILA %.2f, ',...
                 'RTPGHI+GSRTISILA: %.2f, ',...
                 ' %s, window: %s \n'],...
                 Crtpghidb,Crtisiladb,Cgsrtisiladb,...
                 Cgsrtisilawsdb,...
                 wavfile,flags.winmod);
 
    end
    
end


CrtpghiAllMeanDB = 20*log10(mean(CrtpghiAll));
CrtisilaAllMeanDB = 20*log10(mean(CrtisilaAll));
CgsrtisilawsAllMeanDB = 20*log10(mean(CgsrtisilawsAll));
CgsrtisilaAllMeanDB = 20*log10(mean(CgsrtisilaAll));

CrtpghiAllDBmean = mean(20*log10(CrtpghiAll));
CrtisilaAllDBmean = mean(20*log10(CrtisilaAll));
CgsrtisilawsAllDBmean = mean(20*log10(CgsrtisilawsAll));
CgsrtisilaAllDBmean = mean(20*log10(CgsrtisilaAll));

disp('--------------------------ARITHMETIC MEAN------------------------------------------');
        fprintf(['RTPGHI: %.2f dB, RTISILA %.2f dB, GSRTISILA %.2f dB, ',...
                 'RTPGHI+GSRTISILA: %.2f dB',...
                 ' window: %s \n'],...
                 CrtpghiAllMeanDB,CrtisilaAllMeanDB,CgsrtisilaAllMeanDB,...
                 CgsrtisilawsAllMeanDB,...
                 flags.winmod);
disp('--------------------------GEOMETRIC MEAN------------------------------------------');
        fprintf(['RTPGHI: %.2f dB, RTISILA %.2f dB, GSRTISILA %.2f dB, ',...
                 'RTPGHI+GSRTISILA: %.2f dB, ',...
                 ' window: %s \n'],...
                 CrtpghiAllDBmean,CrtisilaAllDBmean,CgsrtisilaAllDBmean,...
                 CgsrtisilawsAllDBmean,...
                 flags.winmod);
disp('------------------------------------------------------------------------');

if flags.do_storewavs
    writetex(sprintf([outputdir,filesep,'avg_rtpghi%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CrtpghiAllMeanDB);
    writetex(sprintf([outputdir,filesep,'avg_rtisila%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CrtisilaAllMeanDB);
    writetex(sprintf([outputdir,filesep,'avg_gsrtisila%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CgsrtisilaAllMeanDB);
    writetex(sprintf([outputdir,filesep,'avg_gsrtisilaws%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CgsrtisilawsAllMeanDB);
    
    writetex(sprintf([outputdir,filesep,'gmean_rtpghi%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CrtpghiAllDBmean);
    writetex(sprintf([outputdir,filesep,'gmean_rtisila%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CrtisilaAllDBmean);
    writetex(sprintf([outputdir,filesep,'gmean_gsrtisila%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CgsrtisilaAllDBmean);
    writetex(sprintf([outputdir,filesep,'gmean_gsrtisilaws%s%s_la%d.tex'],flags.winmod,kv.expname,kv.lookahead),CgsrtisilawsAllDBmean);
end

save(sprintf([outputdir,filesep,'all_%s%s_la%d_it%d.mat'],flags.winmod,kv.expname,kv.lookahead,kv.perframeit),'CrtpghiAll','CrtisilaAll','CgsrtisilaAll','CgsrtisilawsAll');


function writetex(s,val)
fileID = fopen(s,'w');
fprintf(fileID,'%.2f\n',val);
fclose(fileID);










function [coef2,mask2,f_rec,f_rem] = fbreassmask(filename,coef,g,a,repos,L,fs)

mask = imread(filename);

mask = (mask > 0);

M = size(coef,1);
Nres = size(mask,2);

if size(a,2) > 1 
    N = a(:,2);
    %a = a(:,1)./N;
else
    N = cellfun(@length,coef);    
end;

mask2 = cell(M/2+1,1);
for ii=1:M/2+1
  row=  cast(mask(ii,:),'double');
  mask2{ii}=interp1(linspace(0,1,Nres),row,...
                     linspace(0,1,N(ii)),'nearest').';
end;

chan_pos = [0;cumsum(N)];
coef = cell2mat(coef(:));
mask2 = cell2mat(mask2(:));
coef2 = zeros(size(coef));

for ii=1:length(mask2)
    if mask2(ii)
        coef2(repos{ii}) = coef(repos{ii});
    end;
end;

coef3 = coef-coef2;
coef2 = vect2cell(coef2,diff(chan_pos));
coef3 = vect2cell(coef3,diff(chan_pos));
for kk = 1:numel(coef2)/2-1
    coef2{end-kk+1} = conj(coef2{1+kk});
    coef3{end-kk+1} = conj(coef3{1+kk});
end

gd=filterbankdual(g,a,L);
f_rec = ifilterbank(coef2,gd,a);
wavwrite(f_rec,fs,16,[filename(1:end-4),'_result.wav']);

f_rem = ifilterbank(coef3,gd,a);
wavwrite(f_rem,fs,16,[filename(1:end-4),'_rem.wav']);

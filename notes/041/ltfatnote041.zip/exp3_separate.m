% This script file reproduces the results of experiment 3 in 
% N. Holighaus, Z. Prusa and P.Soendergaard, "Reassignment and 
% synchrosqueezing for general time-frequency filter banks, subsampling 
% and processing"
%
% Execution of this script requires LTFAT 2.1.1 or higher, available at 
% ltfat.sourceforge.net. It is recommended to compile the LTFAT C backend.
%
% Feel free to exchange the test signals 'f' with your own test
% signals and experiment with the filter bank parameters.
clear all;

% Load test signal
[f,fs] = wavread('glock_exc.wav');

% Create constant-Q dictionary 
[g,a,fc,L]=cqtfilters(fs,50,floor(fs/2),48,length(f),'fractional','Qvar',6,'redmul',3,'complex');
M = numel(g);

% Perform the reassignment steps
% 1 - Compute phase gradients
[tgrad,fgrad,cs0,c]=filterbankphasegrad(f,g,a,L);

% 2 - Determine filter center frequencies
fc = cent_freqs(fs,fc);

% 3 - The actual reassignment
[sr0,repos,Lc]=filterbankreassign(cs0,tgrad,fgrad,a,fc);

% Load and apply manually created masks
[c2,mask2,f_iso,f_rem] = fbreassmask('glo_coeffs_mask.bmp',c,g,a,repos,L,fs);


% Write wav files for phase-adjusted and not phase-adjusted
wavwrite(real(f_rem),fs,16,['glo_rem.wav']);
wavwrite(real(f_iso),fs,16,['glo_iso.wav']);

% Plot everything
figure(1); 
c0 = filterbank(f,g,a);
plotfilterbank(c0(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));
title('Glockenspiel excerpt');
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 

figure(2);
c = filterbank(f_iso,g,a);
c{1}(1) = max(abs(cell2mat(c0(:))));
plotfilterbank(c(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));
title('Glockenspiel isolated 2nd note');
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 

figure(3);
c = filterbank(f_rem,g,a);
plotfilterbank(c(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));
title('Glockenspiel remainder');
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 

figure(4);
plotfilterbank(vect2cell(mask2,Lc(1:M/2+1)),a(1:M/2+1,:),'fs',44100,'linabs','fc',fs/2*fc(1:M/2+1));
title('Isolation mask (reassigned domain)');
% Uncomment the next line for gray colormap
colormap(flipud(gray)); 

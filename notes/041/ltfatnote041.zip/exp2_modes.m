% This script file reproduces the results of experiment 2 in 
% N. Holighaus, Z. Prusa and P.Soendergaard, "Reassignment and 
% synchrosqueezing for general time-frequency filter banks, subsampling 
% and processing"
%
% Execution of this script requires LTFAT 2.1.1 or higher, available at 
% ltfat.sourceforge.net. It is recommended to compile the LTFAT C backend.
%
% Feel free to exchange the test signals 'f' with your own test
% signals and experiment with the filter bank parameters

clear all
%close all

% Load test signal and add random noise
T = linspace(0,44099/44100,44100);
f1 = cos(4800*pi*T+350*cos(10*pi*T))';
f2 = cos(20000*pi*T-5400*cos(2*pi*(T-1)))';
f3 = cos(750*pi*T+80*cos(4*pi*(T-.03)))';

fs = 44100;
L = fs;

f = f1+f2+f3;

%% Create downsampled constant-Q dictionary for reassignment
[g,a,fc]=erbfilters(fs,L,'spacing',1/6,'bwmul',3/6,'fractional');
%[g,a,fc,L]=cqtfilters(44100,300,22050,48,length(T),'Qvar',4,'redmul',1,'fractional');

% Compute the phase gradients
tic; [tgrad,fgrad,c_s,c]=filterbankphasegrad(f,g,a,L); 
PG_RM_time = toc;
disp(['Phase gradient computation (downsampled): ',num2str(PG_RM_time)]);

% Determine center frequencies and number of channels
cfreq = cent_freqs(fs,fc); 
M = numel(fc);

% Plot positive frequency part of the constant-Q analysis (noisy)
figure(1); 
plotfilterbank(c,a,'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('ERBlet FB coefficients of the test signal');

% Perform and time reassignment
tic; [sr,repos,Lc]=filterbankreassign(c_s,tgrad,fgrad,a,cfreq);
RM_time = toc;
disp(['Reassignment time: ',num2str(RM_time)]);

clear fgrad;

sr0 = cell2mat(sr(:));
sr0 = vect2cell(sqrt(sr0),Lc);

% Plot positive frequency part of the reassigned analysis (noisy)
figure(2); 
plotfilterbank(sr0,a,'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('Reassigned ERBlet FB coefficients of the test signal');

clear sr0;

CUT = sum(Lc(1:168));

% Decompose using the inverse reassignment map
mask_f1 =  cell2mat(sr(:));
mask_f1(CUT+1:end) = 0;
mask_f1 = (mask_f1 > 0);
mask_f2 =  cell2mat(sr(:));
mask_f2(1:CUT) = 0;
mask_f2 = (mask_f2 > 0);

mask = imread('modes_mask1.bmp');
mask = cast(mask > 0,'double');
Nres = size(mask,2);
mask_f3 = zeros(size(mask_f1));
pos = 0;
for ii=1:numel(c);
  row=mask(ii,:);
  mask_f3(pos+1:pos+Lc(ii))=interp1(linspace(0,1,Nres),row,...
                     linspace(0,1,Lc(ii)),'nearest').';
  pos = pos + Lc(ii);
end;
mask_f1 = max(mask_f1-mask_f3,0);

% Prepare coefficient arrays for the separate modes
c_f1 = cell2mat(c(:));
c_f2 = c_f1;
c_f3 = c_f1;

% Isolate the separate modes
for ii=1:length(repos)
    if ~mask_f1(ii)
        c_f1(repos{ii}) = 0;
    end;
    if ~mask_f2(ii)
        c_f2(repos{ii}) = 0;
    end;
    if ~mask_f3(ii)
        c_f3(repos{ii}) = 0;
    end;
end;
c_f1 = vect2cell(c_f1,Lc);
c_f2 = vect2cell(c_f2,Lc);
c_f3 = vect2cell(c_f3,Lc);

% Synthesize the modes
gd = filterbankrealdual(g,a,L);
f1r_RM = 2*real(ifilterbank(c_f1,gd,a,numel(f)));
f2r_RM = 2*real(ifilterbank(c_f2,gd,a,numel(f)));
f3r_RM = 2*real(ifilterbank(c_f3,gd,a,numel(f)));

% Compute and display the SNR rates
SNR_f1_RM = 20*log10(norm(f1)/norm(f1r_RM-f1));
SNR_f2_RM = 20*log10(norm(f2)/norm(f2r_RM-f2));
SNR_f3_RM = 20*log10(norm(f3)/norm(f3r_RM-f3));

disp(['dB-SNR of the first component: ',num2str(SNR_f1_RM)]);
disp(['dB-SNR of the second component: ',num2str(SNR_f2_RM)]);
disp(['dB-SNR of the third component: ',num2str(SNR_f3_RM)]);

%% Create undecimated constant-Q dictionary for synchrosqueezing 
[gu,au]=erbfilters(fs,L,'spacing',1/6,'bwmul',3/6,'uniform');
%[gu,au]=cqtfilters(44100,300,22050,48,length(f),'Qvar',4,'redmul',1,'uniform');
au = ones(size(au));

% Compute the phase gradients
tic; [tgradu,~,~,cu]=filterbankphasegrad(f,gu,au,L); 
PG_SS_time = toc;
disp(['Phase gradient computation (undecimated): ',num2str(PG_SS_time)]);

% Perform and time synchrosqueezing
tic; [cs]=filterbanksynchrosqueeze(cu,tgradu,cfreq);
SS_time = toc;
disp(['Synchrosqueezing time: ',num2str(SS_time)]);

% Compute 'synchrosqueezed spectrogram' for later use
cs0 = cell(size(cs));
for kk = 1:size(cs,1)
    cs0{kk} = abs(cs{kk}./norm(gu{kk}.H(L)).*norm(g{kk}.H(L)));
end

% Plot positive frequency part of the synchrosqueezed analysis (noisy)
figure(3); 
plotfilterbank(cs0,au,'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('Synchroqueezed ERBlet FB coefficients of the test signal');

CUT = 168*44100;

% Isolate the separate modes
cs_f1 =  cell2mat(cs(:));
cs_f1(CUT+1:end) = 0;
cs_f2 =  cell2mat(cs(:));
cs_f2(1:CUT) = 0;

mask_f3S = zeros(size(cs_f1));
pos = 0;
for ii=1:numel(c);
  row=mask(ii,:);
  mask_f3S(pos+1:pos+L)=interp1(linspace(0,1,Nres),row,...
                     linspace(0,1,L),'nearest').';
  pos = pos + L;
end;
cs_f3 = mask_f3S.*cs_f1;
cs_f1 = (1-mask_f3S).*cs_f1;

% The mode coefficients in cell array form
cs_f1 = vect2cell(cs_f1,44100*ones(size(au)));
cs_f2 = vect2cell(cs_f2,44100*ones(size(au)));
cs_f3 = vect2cell(cs_f3,44100*ones(size(au)));

% Compute the filter bank response
Fresp = sum(filterbankfreqz(gu,au,L),2);
Fresp = Fresp + involute(Fresp);

% Synthesize the modes
f1r_SS = ifft(sum(fft(cell2mat(cs_f1.')),2)./Fresp);
f1r_SS = 2*real(f1r_SS);

f2r_SS = ifft(sum(fft(cell2mat(cs_f2.')),2)./Fresp);
f2r_SS = 2*real(f2r_SS);

f3r_SS = ifft(sum(fft(cell2mat(cs_f3.')),2)./Fresp);
f3r_SS = 2*real(f3r_SS);

% Compute and display the SNR rates
SNR_f1_SS = 20*log10(norm(f1)/norm(f1r_SS-f1));
SNR_f2_SS = 20*log10(norm(f2)/norm(f2r_SS-f2));
SNR_f3_SS = 20*log10(norm(f3)/norm(f3r_SS-f3));

disp(['dB-SNR of the first component: ',num2str(SNR_f1_SS)]);
disp(['dB-SNR of the second component: ',num2str(SNR_f2_SS)]);
disp(['dB-SNR of the third component: ',num2str(SNR_f3_SS)]);

% Plot the error around critical points
figure(4);
plot((32500:33000)/44100,f2(32500:33000)-f2r_SS(32500:33000),'--','LineWidth',2,'Color',[.6 .6 .6])
hold on;
plot((32500:33000)/44100,f2(32500:33000)-f2r_RM(32500:33000),'k','LineWidth',2)
hold off;
axis([32500/44100,33000/44100,-.05,.05])
legend('C2 - C2_{REC} (synchrosqueezing)','C2 - C2_{REC} (reassignment)','Location','NorthWest')
xlabel('Time (seconds)','FontSize',14);

figure(5);
plot((36000:39000)/44100,f3(36000:39000)-f3r_SS(36000:39000),'--','LineWidth',2,'Color',[.6 .6 .6])
hold on;
plot((36000:39000)/44100,f3(36000:39000)-f3r_RM(36000:39000),'k','LineWidth',2)
hold off;
axis([36000/44100,39000/44100,-.012,.012])
legend('C3 - C3_{REC} (synchrosqueezing)','C3 - C3_{REC} (reassignment)','Location','NorthWest')
xlabel('Time (seconds)','FontSize',14);

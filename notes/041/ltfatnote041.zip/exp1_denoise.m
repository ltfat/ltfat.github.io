% This script file reproduces the results of experiment 1 in 
% N. Holighaus, Z. Prusa and P.Soendergaard, "New ideas in reassignment: 
% General time-frequency filter banks, sampling and processing"
%
% Execution of this script requires LTFAT 2.0.1 or higher, available at 
% ltfat.sourceforge.net. It is recommended to compile the LTFAT C backend.
%
% Feel free to exchange the test signals 'f' with your own test
% signals and experiment with the filter bank parameters.

% Load test signal and add random noise
[f,fs] = wavread('sretil_exc.wav');
noise = rand(numel(f),1)-.5;
noise = noise/norm(noise)*norm(f);
f_org = f;
f = f+noise;

% Create constant-Q dictionary 
[g,a,fc,L]=cqtfilters(44100,300,22050,48,length(f),'Qvar',2,'redmul',2,'complex','fractional');

% Compute the phase gradients
[tgrad,fgrad,c_s,c]=filterbankphasegrad(f,g,a,L); 

% Determine center frequencies and number of channels
cfreq = cent_freqs(fs,fc); 
M = numel(fc);

% Plot positive frequency part of the constant-Q analysis (noisy)
close all
figure(1); 
plotfilterbank(c(1:M/2+1),a(1:M/2+1,:),'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq(1:M/2+1)); 
colormap(flipud(gray));
title('CQT of the noisy test signal');

% Perform reassignment
[sr,repos,Lc]=filterbankreassign(c_s,tgrad,fgrad,a,cfreq);

% Plot positive frequency part of the reassigned analysis (noisy)
figure(2); 
plotfilterbank(sr(1:M/2+1),a(1:M/2+1,:),'fs',fs,'db','dynrange',120,'fc',fs/2*cfreq(1:M/2+1)); 
colormap(flipud(gray));
title('Reassigned CQT of the noisy test signal');

% Create the denoising mask by thresholding (threshold determined manually)
range = 23;
sr_den = cell2mat(sr(:));
sr_den = 10*log10(abs(sr_den));
cmax = max(sr_den(:));
sr_den(:) = max(sr_den(:),cmax-range)-cmax+range;
mask = (sr_den(:) > 0);

% Apply the denoising mask
sr_den = mask.*cell2mat(sr(:));
sr_den = vect2cell(sr_den,a(:,2));

% Plot denoised reassigned representation
figure(3); 
plotfilterbank(sr_den(1:M/2+1),a(1:M/2+1,:),'fs',fs,'db','dynrange',120,'fc',fs/2*cfreq(1:M/2+1)); 
colormap(flipud(gray));
title('Denoised reassigned CQT');

% Apply the denoising to the constant-Q coefficients through the inverse
% reassignment map
c_den =  cell2mat(c(:));
for ii=1:length(repos)
    if ~mask(ii)
        c_den(repos{ii}) = 0;
    end;
end;
c_den = vect2cell(c_den,Lc);

% Plot denoised constant-Q representation
figure(4); 
plotfilterbank(c_den(1:M/2+1),a(1:M/2+1,:),'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq(1:M/2+1)); 
colormap(flipud(gray));
title('Resulting denoised CQT');

% Synthesize the denoised signal
gd = filterbankdual(g,a,L);
f_den = real(ifilterbank(c_den,gd,a,numel(f)));

% Write wav files for noisy and denoised signal 
wavwrite(f,44100,'sretil_noisy.wav');
wavwrite(f_den,44100,'sretil_den.wav');

% Determine SNR before and after denoising
SNR = 20*log10(norm(f_org)/norm(f-f_org))
SNR_after = 20*log10(norm(f_org)/norm(f_den-f_org))
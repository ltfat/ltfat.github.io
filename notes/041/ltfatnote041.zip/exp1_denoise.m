% This script file reproduces the results of experiment 1 in 
% N. Holighaus, Z. Prusa and P.Soendergaard, "Reassignment and 
% synchrosqueezing for general time-frequency filter banks, subsampling 
% and processing"
%
% Execution of this script requires LTFAT 2.1.1 or higher, available at 
% ltfat.sourceforge.net. It is recommended to compile the LTFAT C backend.
%
% Feel free to exchange the test signals 'f' with your own test
% signals and experiment with the filter bank parameters

clear all

% Load test signal and add random noise
[f,fs] = wavload('sretil_exc.wav');
f = f(1.5*44100+1:3*44100);
noise = rand(numel(f),1)-.5;
noise = noise/norm(noise)*norm(f);
f_org = f;
f = f+noise;

%% Create downsampled constant-Q dictionary for reassignment
[g,a,fc,L]=cqtfilters(44100,300,22050,48,length(f),'Qvar',2,'redmul',1,'fractional');

% Compute the phase gradients
tic; [tgrad,fgrad,c_s,c]=filterbankphasegrad(f,g,a,L); 
PG_RM_time = toc;
disp(['Phase gradient computation (downsampled): ',num2str(PG_RM_time)]);

% Determine center frequencies and number of channels
cfreq = cent_freqs(fs,fc); 
M = numel(fc);

% Plot positive frequency part of the constant-Q analysis (noisy)
figure(1); 
plotfilterbank(c,a,'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('CQT of the noisy test signal');

% Perform and time reassignment
tic; [sr,repos,Lc]=filterbankreassign(c_s,tgrad,fgrad,a,cfreq);
RM_time = toc;
disp(['Reassignment time: ',num2str(RM_time)]);

clear fgrad;

% Plot positive frequency part of the reassigned analysis (noisy)
figure(2); 
plotfilterbank(sr,a,'fs',fs,'db','dynrange',120,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('Reassigned CQT of the noisy test signal');

% Create the denoising mask by thresholding (threshold determined manually)
range = 23;
sr_den = cell2mat(sr(:));
sr_den = 10*log10(abs(sr_den));
cmax = max(sr_den(:));
sr_den(:) = max(sr_den(:),cmax-range)-cmax+range;
mask = (sr_den(:) > 0);

% Apply the denoising mask
sr_den = mask.*sqrt(cell2mat(sr(:)));
sr_den = vect2cell(sr_den,a(:,2));

% Plot denoised reassigned representation
figure(4); 
plotfilterbank(sr_den,a,'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('Denoised reassigned CQT');

clear sr_den;

% Apply the denoising to the constant-Q coefficients through the inverse
% reassignment map
c_den =  cell2mat(c(:));
for ii=1:length(repos)
    if ~mask(ii)
        c_den(repos{ii}) = 0;
    end;
end;
c_den = vect2cell(c_den,Lc);

% Plot denoised constant-Q representation
figure(5); 
plotfilterbank(c_den,a,'fs',fs,'db','dynrange',60,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('Resulting denoised CQT');

% Synthesize the denoised signal
gd = filterbankrealdual(g,a,L);
f_den_RM = 2*real(ifilterbank(c_den,gd,a,numel(f)));

clear c_den gd;

RM_red = (2*numel(cell2mat(c(:)))+2*nnz(cell2mat(tgrad(:)))+nnz(cell2mat(sr(:))))/L;
disp(['Redundancy of the reassigned processing setup: ',num2str(RM_red)]);

clear c c_s tgrad sr;

%% Create undecimated constant-Q dictionary for synchrosqueezing 
[gu,au]=cqtfilters(44100,300,22050,48,length(f),'Qvar',2,'redmul',1,'uniform');
au = ones(size(au));

% Compute the phase gradients
tic; [tgradu,~,~,cu]=filterbankphasegrad(f,gu,au,L); 
PG_SS_time = toc;
disp(['Phase gradient computation (undecimated): ',num2str(PG_SS_time)]);


% Perform and time synchrosqueezing
tic; [cs]=filterbanksynchrosqueeze(cu,tgradu,cfreq);
SS_time = toc;
disp(['Synchrosqueezing time: ',num2str(SS_time)]);

clear cu tgradu;

% Compute 'synchrosqueezed spactrogram' for later use
cs0 = cell(size(cs));
for kk = 1:size(cs,1)
    cs0{kk} = abs(cs{kk}./norm(gu{kk}.H(L)).*norm(g{kk}.H(L))).^2;
end

% Plot positive frequency part of the synchrosqueezed analysis (noisy)
figure(3); 
plotfilterbank(cs0,au,'fs',fs,'db','dynrange',120,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('Synchroqueezed CQT of the noisy test signal');

% Create the denoising mask by thresholding (threshold determined manually)
range = 26;
mask = cell2mat(cs0(:));
mask = 10*log10(abs(mask));
cmax = max(mask(:));
mask(:) = max(mask(:),cmax-range)-cmax+range;
mask = (mask(:) > 0);

clear cs0;

% Apply the denoising mask
cs_den = mask.*cell2mat(cs(:));
cs_den = vect2cell(cs_den,L./au);

clear mask;

% Plot denoised reassigned representation
figure(6); 
plotfilterbank(cs_den,au,'fs',fs,'db','dynrange',120,'fc',fs/2*cfreq); 
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
title('Denoised synchrosqueezed CQT');

Fresp = sum(filterbankfreqz(gu,au,L),2);
Fresp = Fresp + involute(Fresp);

clear gu;

f_den_SS = ifft(sum(fft(cell2mat(cs_den.')),2)./Fresp);
f_den_SS = 2*real(f_den_SS);

% Reconstruct noisy analysis as sanity check
%  f_SS = ifft(sum(fft(cell2mat(cs.')),2)./Fresp);
%  f_SS = 2*real(f_SS);
%  norm(f-f_SS)/norm(f)

SS_red = 2*nnz(cell2mat(cs(:)))/L;
disp(['Redundancy of the synchrosqueezed representation: ',num2str(SS_red)]);

clear cs_den;

% Write wav files for noisy and denoised signal 
wavsave(f,44100,'sretil_noisy.wav');
wavsave(f_den_RM,44100,'sretil_den_RM.wav');
wavsave(f_den_SS,44100,'sretil_den_SS.wav');

% Determine SNR before and after denoising
SNR = 20*log10(norm(f_org)/norm(f-f_org));
SNR_den_RM = 20*log10(norm(f_org)/norm(f_den_RM-f_org));
SNR_den_SS = 20*log10(norm(f_org)/norm(f_den_SS-f_org));

disp(['dB-SNR of the noisy test signal: ',num2str(SNR)]);
disp(['dB-SNR of the reassignment denoised test signal: ',num2str(SNR_den_RM)]);
disp(['dB-SNR of the synchrosqueezing denoised test signal: ',num2str(SNR_den_SS)]);

% This script file reproduces Figure 1 in 
% N. Holighaus, Z. Prusa and P.Soendergaard, "New ideas in reassignment: 
% General time-frequency filter banks, sampling and processing"
%
% Execution of this script requires LTFAT 2.0.1 or higher, available at 
% ltfat.sourceforge.net. It is recommended to compile the LTFAT C backend.
%
% Feel free to exchange the test signals 'f', 'f2' with your own test
% signals and experiment with the filter bank parameters.

%% Definition of test signals

% 3 chirp test signal 
L = 44100;

f = sin(2*pi*((0:44099)/35+((0:44099)/600).^2)) + ...
     sin(2*pi*((0:44099)/10+((0:44099)/600).^2)) + ...
    sin(2*pi*((0:44099)/5-((0:44099)/700).^2));
f = 0.7*f';

% Violin and piano test signal
f2 = wavread('sretil_exc.wav');
L2 = length(f2);

% Set sampling rate to 44.1 kHz
fs = 44100;

%% Analyze signal 1
% Create ERBlet dictionary for signal 1
[g,a,fc,L]=erbfilters(fs,L,'fractional','spacing',1/12,'warped');
if length(a) < length(g)
    a = [a;a(end-1:-1:2,:)];
end

% Perform the reassignment steps
% 1 - Compute phase gradients
[tgrad,fgrad,cs0,c]=filterbankphasegrad(f,g,a,L);

% 2 - Determine filter center frequencies
fc = cent_freqs(fs,fc);

% 3 - The actual reassignment
[sr0]=filterbankreassign(cs0,tgrad,fgrad,a,fc);

% Plot representations for signal 1
figure(1); 
plotfilterbank(cs0,a,'fs',fs,'fc',fs/2*fc,'db','dynrange',60);
title('ERBlet spectrogram of 3 chirps');
% Uncomment the next line for gray colormap
% colormap(flipud(gray));
figure(2); 
plotfilterbank(sr0,a,'fs',fs,'fc',fs/2*fc,'db','dynrange',60);
title('Reassigned ERBlet spectrogram of 3 chirps');
% Uncomment the next line for gray colormap
% colormap(flipud(gray));

%% Analyze signal 2
% Create ERBlet dictionary for signal 2
[g,a,fc,L2]=erbfilters(fs,L2,'fractional','spacing',1/12,'bwmul',1/2,'warped');
if length(a) < length(g)
    a = [a;a(end-1:-1:2,:)];
end

% Perform the reassignment steps
% 1 - Compute phase gradients
[tgrad,fgrad,cs0,c]=filterbankphasegrad(f2,g,a,L2);

% 2 - Determine filter center frequencies
fc = cent_freqs(fs,fc);

% 3 - The actual reassignment
[sr0]=filterbankreassign(cs0,tgrad,fgrad,a,fc);

% Plot representations for signal 2
figure(3); 
plotfilterbank(cs0,a,'fs',fs,'fc',fs/2*fc,'db','dynrange',60);
title('ERBlet spectrogram of test signal');
% Uncomment the next line for gray colormap
% colormap(flipud(gray)); 
figure(4); 
plotfilterbank(sr0,a,'fs',fs,'fc',fs/2*fc,'db','dynrange',60);
title('Reassigned ERBlet spectrogram of test signal');
% Uncomment the next line for gray colormap
% colormap(flipud(gray));
% This script file reproduces the results of experiment 2 in 
% N. Holighaus, Z. Prusa and P.Soendergaard, "New ideas in reassignment: 
% General time-frequency filter banks, sampling and processing"
%
% Execution of this script requires LTFAT 2.0.1 or higher, available at 
% ltfat.sourceforge.net. It is recommended to compile the LTFAT C backend.
%
% Feel free to exchange the test signals 'f' with your own test
% signals and experiment with the filter bank parameters.

% Load test signal
[f,fs] = wavread('glock_exc.wav');

% Create constant-Q dictionary 
[g,a,fc,L]=cqtfilters(fs,50,floor(fs/2),48,length(f),'fractional','Qvar',6,'redmul',3,'complex');

% Perform the reassignment steps
% 1 - Compute phase gradients
[tgrad,fgrad,cs0,c]=filterbankphasegrad(f,g,a,L);

% 2 - Determine filter center frequencies
fc = cent_freqs(fs,fc);

% 3 - The actual reassignment
[sr0,repos,Lc]=filterbankreassign(cs0,tgrad,fgrad,a,fc);

% Load and apply manually created masks
[c2,mask2,f_rec,f_rem] = fbreassmask('glo_coeffs_mask.bmp',c,g,a,repos,L,fs);
[cx,maskx,f_recx,f_remx] = fbreassmask('glo_coeffs_harm.bmp',c2,g,a,repos,L,fs);

% Determine remainder signal
f_rem = f_rem+f_remx;

% Perform circular frequency shift on the extracted harmonic component
M = numel(fc);
n = 48;
c3 = cx;
a2 = a;
c3(2:M/2) = circshift(cx(2:M/2),[-n,0]);
c3(end:-1:M/2+2) = circshift(cx(end:-1:M/2+2),[-n,0]);
a2(2:M/2,2) = circshift(a(2:M/2,2),-n);
a2(end:-1:M/2+2,2) = a2(2:M/2,2);
a2(1,2) = max(a(:,2));
a2(M/2-n+1:M/2+1+n,2) = max(a(:,2));

% Compute dual filters
gd2=filterbankdual(g,a2,L);
gd=filterbankdual(g,a,L);

Nn = cellfun(@(x,y) norm(x.H)/norm(y.H),gd,gd2);

% Set overspilled channels to zero
maxabs = max(abs(cell2mat(c(:))));
for kk=1:2*n+1
    c3{M/2-n+kk} = zeros(max(a(:,2)),1);
end
c3{1} = zeros(max(a(:,2)),1);

% Synthesize transposed harmonic component before phase adjustment
f_de_no = ifilterbank(c3,gd2,a2);

% Perform rudimentary phase adjustment
for kk=1:length(c3)
      temp = c3{kk};
      islarge = (abs(temp) >= maxabs*10^-2);
      phas = islarge.*phase(temp);
      beg = [find(diff([0;islarge])==1)];
      fin = [find(diff([0;islarge])==-1);length(temp)];
      phas2 = zeros(length(temp),1);
      for jj = 1:length(beg)
        phas2(beg(jj):fin(jj)-1) = cumsum([phas(beg(jj));...
            2^(-n/48)*diff(phas(beg(jj):fin(jj)-1))]);
      end    
      phas = exp(1i*phas2);
      c3{kk} = Nn(kk)*abs(temp).*phas;
end

% Synthesize transposed harmonic component (with phase adjustment)
f_de = ifilterbank(c3,gd2,a2);

% Write wav files for phase-adjusted and not phase-adjusted
wavwrite(f_rem+f_de,fs,16,['glo_coeffs_full','_-',num2str(n),'.wav']);
wavwrite(f_rem+f_de_no,fs,16,['glo_coeffs_full','_-',num2str(n),'old_phase.wav']);

% Plot everything
close all
figure(1); subplot(211);
c = filterbank(f_rem,g,a);
plotfilterbank(c(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));
title('Glockenspiel remainder');
colormap(flipud(gray));
subplot(212);
c = filterbank(f_recx,g,a);
plotfilterbank(c(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));
title('Glockenspiel 2nd note harmonics');
colormap(flipud(gray));
figure(2); subplot(211);
plotfilterbank(vect2cell(maskx,Lc(1:M/2+1)),a(1:M/2+1,:),'fs',44100,'linabs','fc',fs/2*fc(1:M/2+1));
title('Harmonics mask (reassigned domain)');
colormap(flipud(gray));
subplot(212);
c = filterbank(f_de,g,a);
plotfilterbank(c(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));title('2nd note harmonics after transposition');
colormap(flipud(gray));
figure(3); subplot(211);
c = filterbank(f_rem+f_de,g,a);
plotfilterbank(c(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));title('Synthesized signal');
colormap(flipud(gray));
subplot(212);
plotfilterbank(c3(1:M/2+1),a(1:M/2+1,:),'fs',44100,'db','dynrange',60,'fc',fs/2*fc(1:M/2+1));title('Transposed coefficients before synthesis');
colormap(flipud(gray));
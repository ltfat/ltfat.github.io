function [snrs_sig,snrs_noise] = multidgt_conv_test_w_reset(filename,mpresults)

% This function performs the first experiment in Section 6.1 in the paper: 
%
%       Fast Matching Pursuit with Multi-Gabor Dictionaries
%       by Z. Prusa, N. Holighaus and P. Balazs
%
% For a specified audio signal 'filename.wav' and a Gaussian noise signal 
% of the same length, matching pursuit decompositions are computed using 
% the method proposed therein and stores the obtained approximation error. 
%
% This test uses resets to ensure convergence. 
%
% More specifically, signal approximations are computed for different 
% thresholds on the Gram matrix and different values for the maximum number 
% of iterations. Approximation results will be plotted and can be saved by
% specifying appropriate output arguments.
%
% When running the function with a custom audio file, results for regular
% matching pursuit can be provided as a second input argument. 
%
% Usage: 
% [snrs_sig,snrs_noise] = multidgt_conv_test(filename,mpresults)
%                   ... = multidgt_conv_test(filename)
%                   ... = multidgt_conv_test
%
% Input:
%   filename        - String pointing to a single-channel wav-file for the 
%                     target audio signal.
%   mpresults       - Cell array with 2 elements, each element being a
%                     column vector containing pre-computed approximation
%                     errors achieved by a reference algorithm, e.g, 
%                     standard matching pursuit for the target signal and
%                     Gaussian noise of the same length. 
%    
% The entries of mpresults{1} and mpresults{2} should be related to the
% maximum iteration milestones used below for correct plotting. Appropriate
% values can be obtained, e.g., by using the Matching Pursuit Toolkit
% (MPTK, http://mptk.irisa.fr/).
%
% NOTE: Please uncomment everything after line 112 if you want to run the
% time-consuming noise test.

% Set parameters for multi-Gabor dictionary
g = 'blackman'; % Window given as string will be converted to window of length = number of channels of specified type
g1 = g; g2 = g; g3 = g; % Windows
a1 = 128; a2 = 2*a1; a3 = 4*a1; % Hop sizes
M1 = 512; M2 = 2*M1; M3 = 4*M1; % Number of channels

% Set approximation error, maximum number of iterations, kernel
% thresholds and number of iterations per reset for the audio signal 
errdb = -250; % desired approximation error (set to very low to prevent early stopping)
maxit_sig = [1000000,750000,500000,400000,300000,200000,100000,80000,60000,40000,20000]; % Maximum number of iterations for audio signal
kernthr_sig = [1e-4,1e-3,5e-3]; % Kernel thresholds for audio signal
resetit_sig = [350000,30000,20000]; % Iterations per reset for audio signal 

% Initialize arrays for saving SNR values
snrs_sig = zeros(numel(kernthr_sig)+1,numel(maxit_sig));
snrs_noise = [];

% Load/Generate audio and noise signals and load MP results for comparison
% (if applicable)
if nargin<2
    if nargin<1 % Load standard test signal and precomputed MP results
        sig = wavload('39ch1.wav');
        snrs_sig(1,:) = [67.04,63.97,57.65,52.90,46.78,39.04,28.51,25.75,22.59,18.83,13.68];
    else  % No MP results given
        sig = wavload([filename,'.wav']);
        snrs_sig(1,:) = zeros(1,numel(maxit_sig));
    end
else % MP results supplied
    sig = wavload([filename,'.wav']);
    temp = flipud(mpresults{1});
    snrs_sig(1,end-numel(temp)+1:end) = temp;
end

% Compute matching pursuit decompositions for audio signal
for kk = 1:numel(maxit_sig)
    disp('MAXIT '), disp(maxit_sig(kk))
    for jj = 1:numel(kernthr_sig)
        disp('KERNTHR '), disp(kernthr_sig(jj))
        [c,frec,info] = multidgtrealmp(sig,{g1,a1,M1,g2,a2,M2,g3,a3,M3},errdb,maxit_sig(kk), ...
                                'kernthr',kernthr_sig(jj),'reset','resetit',resetit_sig(jj));
                            
        snrs_sig(jj+1,kk) = 20*log10(1./info.relres(end));
        
        % The next two lines are just for debugging purposes
        exit_code_sig{jj+(kk-1)*numel(kernthr_sig)} = info.message;
        maxiters_sig(jj+(kk-1)*numel(kernthr_sig)) = info.iter;
    end
end   
snrs_sig(1,:) = [67.04,63.97,57.65,52.90,46.78,39.04,28.51,25.75,22.59,18.83,13.68];

% Plot results for audio signal
clf
figure(1);
plot(fliplr(snrs_sig(2,:))','Color',[0, 0.4470, 0.7410],'LineWidth',2)
hold on 
plot(fliplr(snrs_sig(3,:))','--','Color',[0.8500, 0.3250, 0.0980],'LineWidth',1.5)
plot(fliplr(snrs_sig(4,:))','Color',[0.9290, 0.6940, 0.1250],'LineWidth',2)
hold on 
plot(fliplr(snrs_sig(1,:))','Color',[0.4660, 0.6740, 0.1880],'LineWidth',3)
hold off
xticks((1:11));
xticklabels({'20k','40k','60k','80k','100k','200k','300k','400k','500k','750k','1m'})
legend('Proposed (1e-4)','Proposed (1e-3)','Proposed (5e-2)','MPTK','Location','northwest');
set(gca,'FontSize',14);
title('Approximation of audio signal','FontSize',16);
ylabel('Reconstruction error (dB)','FontSize',16);
xlabel('Number of selections','FontSize',16);

%% Comment everything after this point to not consider the time-consuming test for the noise signal
% 
% % Set approximation error, maximum number of iterations, kernel
% % thresholds and number of iterations per reset for the noise signal 
% errdb = -250; % desired approximation error (set to very low to prevent early stopping)
% maxit_noise = [7000000,6000000,5000000,4000000,3000000,2000000,1500000,1000000,750000,500000,400000]; % Maximum number of iterations for noise signal
% kernthr_noise = [1e-4,1e-3,5e-3,1e-2]; % Kernel thresholds for noise signal
% resetit_noise = [0,2000000,1000000,700000]; % Iterations per reset for noise signal
% 
% % Initialize array for saving SNR values
% snrs_noise = zeros(numel(kernthr_noise)+1,numel(maxit_noise));
% 
% % Load/Generate noise signal and load MP results for comparison
% % (if applicable)
% if nargin<2
%     if nargin<1 % Load standard test signal and precomputed MP results
%         noi = wavload('noise.wav');
%         snrs_noise(1,:) = [0,0,0,0,0,0,0,8.53,6.35,4.24,3.42];
%     else  % No MP results given
%         noi = randn(numel(sig),1);
%         snrs_noise(1,:) = zeros(1,numel(maxit_noise));
%     end
% else % MP results supplied
%     noi = randn(numel(sig),1);
%     temp = flipud(mpresults{2});
%     snrs_noise(1,end-numel(temp)+1:end) = temp;
% end
% 
% % Compute matching pursuit decompositions for noise signal
% for kk = 1:numel(maxit_noise)
%     disp('MAXIT '), disp(maxit_noise(kk))   
%     for jj = 1:numel(kernthr_noise)
%         disp('KERNTHR '), disp(kernthr_noise(jj))
%         [c,frec,info] = multidgtrealmp(noi,{g1,a1,M1,g2,a2,M2,g3,a3,M3},errdb,maxit_noise(kk), ...
%                                 'kernthr',kernthr_noise(jj),'reset','resetit',resetit_noise(jj));
%         
%         snrs_noise(jj+1,kk) = 20*log10(1./info.relres(end));
%         
%         % The next two lines are just for debugging purposes                    
%         exit_code_noise{jj+(kk-1)*numel(kernthr_noise)} = info.message;
%         maxiters_noise(jj+(kk-1)*numel(kernthr_noise)) = info.iter;
%     end
% end
% 
% % Plot results for noise signal
% figure(2);
% plot(fliplr(snrs_noise(2,:))','Color',[0, 0.4470, 0.7410],'LineWidth',2)
% hold on 
% plot(fliplr(snrs_noise(3,:))','--','Color',[0.8500, 0.3250, 0.0980],'LineWidth',1.5)
% plot(fliplr(snrs_noise(4,:))','Color',[0.9290, 0.6940, 0.1250],'LineWidth',2)
% plot(fliplr(snrs_noise(5,:))','--','Color',[0.4940, 0.1840, 0.5560],'LineWidth',1.5)
% plot(fliplr(snrs_noise(1,end-3:end))','Color',[0.4660, 0.6740, 0.1880],'LineWidth',3)
% hold off
% xticks((1:11));
% xticklabels({'400k','500k','750k','1m','1.5m','2m','3m','4m','5m','6m','6.5m'})
% legend('Proposed (1e-4)','Proposed (1e-3)','Proposed (5e-2)','Proposed (1e-2)','MPTK','Location','northwest');
% set(gca,'FontSize',14);
% title('Approximation of noise signal','FontSize',16);
% ylabel('Reconstruction error (dB)','FontSize',16);
% xlabel('Number of selections','FontSize',16);

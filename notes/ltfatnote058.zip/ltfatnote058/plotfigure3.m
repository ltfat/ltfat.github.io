function [a, x] = plotfigure3(G, viewx, viewy, dist, dist2)
%PLOTFIGURE3 Fusion Frame in 3D
%
%   plots a fusion frame (synthesis matrix) and its local 
%   frames along with its dual.
%   reproduces in its default configuration Figure 3 from
%   "A Survey of Fusion Frames in Hilbert Spaces"
%
%
%   based on `plot3Dframe` and `plotfuframe3D` by P. Balazs
%   Start: 18.02.2022
%   Last: 11.11.2022

plotlocal = 1; % Also plot the local frames? 
transp = 0.25; % Make the surfaces transparent? 
text_distance = 0.05;
text_distance2 = 0.15;
dist = 0;
dist2 = 0;
borderX = 2;
borderY= 2;

color1 = [0 0.9 0; 0.9290 0.6940 0];
color2 = [0, 0.6, 0.1; 0.8500 0.3250 0.0980];

hold on
[X, Y] = meshgrid(-borderX:0.5:borderX,-borderY:0.5:borderY);
for ii = 1:G.Nframes
    % Z = Ebene 
    if 1 == 1
        normal = cross(G.frames{ii}.g(:,1),G.frames{ii}.g(:,2));
        if normal(3) ~= 0
            Z = (normal(1)* X + normal(2)*Y)/(-normal(3));
            surf(X,Y,Z,'FaceColor',color1(ii,:),'EdgeColor','none','FaceAlpha',transp);
        elseif normal(2) ~= 0
            Z = (normal(1)* X + normal(3)*Y)/(-normal(2));
            surf(X,Z,Y,'FaceColor',color1(ii,:),'EdgeColor','none','FaceAlpha',transp);
        elseif normal(1) ~= 0
           Z = (normal(3)* X + normal(2)*Y)/(-normal(1));
           surf(Z,Y,X,'FaceColor',color1(ii,:),'EdgeColor','none','FaceAlpha',transp);
        else
            error('NO!');
        end
        % Plote the normal vector
        % quiver3(0,0,0,normal(1),normal(2),normal(3));
    end     
    [~, M] = size(G.frames{ii}.g);

    if plotlocal
        for jj = 1:M
            quiver3(0,0,0,G.frames{ii}.g(1,jj),G.frames{ii}.g(2,jj),G.frames{ii}.g(3,jj),...
                'Color',color2(ii,:),'LineWidth',2,'MaxHeadSize',1.5);
            text_text = char(sprintf("\\phi_%i^{(%i)}",jj,ii));

            if jj == 1   
                text(G.frames{ii}.g(1,jj)+dist+0.2,G.frames{ii}.g(2,jj)+dist2+0.1,...
                    G.frames{ii}.g(3,jj)+0, text_text,...
                    'Fontsize', 24,'Color',color2(ii,:), 'FontWeight', 'bold')
            else
                if ii== 1
                text(G.frames{ii}.g(1,jj)+dist2,G.frames{ii}.g(2,jj)+dist2,...
                    G.frames{ii}.g(3,jj)+0,...
                    text_text,'Fontsize', 24,'Color',color2(ii,:), 'FontWeight', 'bold')
                else
                                text(G.frames{ii}.g(1,jj)+dist,G.frames{ii}.g(2,jj)+dist2,...
                    G.frames{ii}.g(3,jj)+0,...
                    text_text,'Fontsize', 24,'Color',color2(ii,:), 'FontWeight', 'bold')
                end

            end
            
        end
    end
    
end
a = gca;
a.View = [viewx viewy];
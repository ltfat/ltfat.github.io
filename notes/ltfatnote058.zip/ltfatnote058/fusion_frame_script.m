%reproduce the Figures from the Chapter 
% "A Survey of Fusion Frames in Hilbert Spaces"
%
% dependencies: LTFAT development branch: fuframes
%               vectarrow function (Fig2)

clear all;
%uncomment Figures to reproduce
reproduce = 'Fig1';
%reproduce = 'Fig2';
%reproduce = 'Fig3';
%reproduce = 'Fig4';
%reproduce = 'Fig5'; %plots the fusiogram


switch reproduce
    case 'Fig1'
        frametypes = {{'Fig1'}};
        plottype = [];
    case 'Fig2'
        frametypes = {{'Fig2'}};
        plottype = '3D';
    case 'Fig3'
        frametypes = {{'Fig3'}};
        plottype = '3D';
    case 'Fig4'
        frametypes = {{'Fig4'}};
        plottype = '2D';
    case 'Fig5'
        frametypes = {{'Fig5'}};
        plottype = [];
    otherwise
        frametypes = 'demo_frames';
        plottype = 'overlap';
end

if strcmp(plottype, 'overlap')
    overlap = [0.25 0.25 0.25 0.25 0.25 0.25 0.25 0.25;...
               0.25 0.25 0.25 0.25 0.25 0.25 0.25 0.25];
    overlap = overlap';
else
    overlap = [];
end

[F, L] = generate_fusionframes(frametypes, overlap);

switch reproduce
    case 'Fig1'
        L = 1024;
    % L = 10;
    P = rand(L,L)-1/2;
    % Perturbation Matrix
    % fprintf("Norm of Perturbation Matrix: %f",norm(SSS));
    PP =  1/2*(P+P');
    PP = PP/(2*norm(PP));
    SSS = eye(L,L) - PP; 
    % Matrix with convergence
    % fprintf("Rank of Matrix: %f\n",rank(SSS));

    fprintf("The convergence rate is %f\n",norm(PP));

    f = rand(L,1);
    % Signal

    tic
    [fout,err,numofit] = richardson(f,SSS,'outputalliter');
    toc

    if 1==1 %'outputalliter'
        lastout = fout{numofit};
    else
        lastout = fout;
    end

    fprintf("Error: %f\n",norm(SSS*lastout - f));

    figure(1);
    subplot(1,2,1);
    plot(err);
    title("Error");
    subplot(1,2,2);
    semilogy(err);
    title("Log Error");

    case 'Fig2'
        %vector to be projected
        f = [-0.1 -0.5 -0.1];
        %view angle [deg]
        view_az = 70;
        view_el = 40;
        plotfigure2(F, f, view_az, view_el);
        
    case 'Fig3'
        FD = fudual(F, L);
        %view angle [deg]
        view_az = 115;
        view_el = 350;
        %figure;
        subplot(1,2,1);
        plotfigure3(FD, view_az, view_el);
        title('The original fusion frame')
        subplot(1,2,2);
        plotfigure3(F, view_az, view_el);  
        title('The dual fusion frame');
        
    case 'Fig4'
        G=checkfudim(F, L);
        t=0:1/(L-1):1; f=4; x=sin(2*pi*f*t);
        
        h = fuana(G, x);
        %arrange the vectors...
        y = [h{1}'; h{2}'; h{3}'; h{4}'; h{5}'; h{6}'; h{7}'; h{8}'];
        z = [norm(h{1})'; norm(h{2})'; norm(h{3})';...
            norm(h{4})'; norm(h{5})'; norm(h{6})';...
            norm(h{7})'; norm(h{8})];
        
        figure;
        imagesc(y);
        set(gca,'xticklabel',{[]})
        set(gca,'yticklabel',{[]})
        xlabel('L', 'FontSize', 80)
        ylabel('Subspace index', 'FontSize', 80)
        figure;
        imagesc(z)
        set(gca,'xticklabel',{[]})
        set(gca,'yticklabel',{[]})
        xlabel('L', 'FontSize', 80)
        ylabel('Subspace index', 'FontSize', 80)
        
    case 'Fig5'
        addpath('./fusiogram_code')
        run_fusiogram;
end
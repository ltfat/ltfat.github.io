%this script reproduces the Figures from the Chapter 
% "A Survey of Fusion Frames in Hilbert Spaces"
%
% dependencies: LTFAT
%               vectarrow function (Fig2)

% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Authors: P. Balazs and C. Hollomey (2023), Acoustics Research Institute
%
%   Start: 18.02.2022
%   Last: 28.02.2023


clear all;

%uncomment to reproduce the desired Figures:
%reproduce = 'Fig1';
%reproduce = 'Fig2';
%reproduce = 'Fig3';
%reproduce = 'Fig4';
reproduce = 'Fig5'; %plots the local fusiogram: Figures 5, 6, and 7 and the raw data

%to generate a demo fusion frame comprising various
%frames available in LTFAT, uncomment the following: 
%(see function generate_fusionframes.m
%for a list of available frames)
%reproduce = 'Demo';


switch reproduce
    case 'Fig1'
        frametypes = {{'Fig1'}};
    case 'Fig2'
        frametypes = {{'Fig2'}};
    case 'Fig3'
        frametypes = {{'Fig3'}};
    case 'Fig4'
        frametypes = {{'Fig4'}};
    case 'Fig5'
        frametypes = {{'Fig5'}};
    otherwise
        frametypes = {{'structured'}};
end

[F, L] = generate_fusionframes(frametypes);

switch reproduce
    case 'Fig1'
        L = 1024;
        P = rand(L,L)-1/2;
        % Perturbation Matrix
        % fprintf("Norm of Perturbation Matrix: %f",norm(SSS));
        PP =  1/2*(P+P');
        PP = PP/(2*norm(PP));
        SSS = eye(L,L) - PP; 
        % Matrix with convergence
        % fprintf("Rank of Matrix: %f\n",rank(SSS));
        fprintf("The convergence rate is %f\n",norm(PP));
        %signal
        f = rand(L,1);
        tic
        [fout,err,numofit] = richardson(f,SSS,'outputalliter');
        toc

        if 1==1 %'outputalliter'
            lastout = fout{numofit};
        else
            lastout = fout;
        end

        fprintf("Error: %f\n",norm(SSS*lastout - f));

        figure(1);
        subplot(1,2,1);
        plot(err);
        title("Error");
        subplot(1,2,2);
        semilogy(err);
        title("Log Error");

    case 'Fig2'
        %vector to be projected
        f = [-0.1 -0.5 -0.1];
        %view angle [deg]
        view_az = 70;
        view_el = 40;
        figure(2)
        plotfigure2(F, f, view_az, view_el);
        
    case 'Fig3'
        FD = fudual(F, L);
        %view angle [deg]
        view_az = 250;
        view_el = 40;
        figure(3)
        plotfigure3(FD, view_az, view_el);  
        title('The dual fusion frame');
        
    case 'Fig4'
        G=checkfudim(F, L);
        t=0:1/(L-1):1; f=4; x=sin(2*pi*f*t);
        
        h = fuana(G, x);
        %arrange the vectors...
        y = [h{1}'; h{2}'; h{3}'; h{4}'; h{5}'; h{6}'; h{7}'; h{8}'];
        z = [norm(h{1})'; norm(h{2})'; norm(h{3})';...
            norm(h{4})'; norm(h{5})'; norm(h{6})';...
            norm(h{7})'; norm(h{8})];
        
        figure;
        imagesc(y);
        set(gca,'xticklabel',{[]})
        set(gca,'yticklabel',{[]})
        xlabel('L', 'FontSize', 80)
        ylabel('Subspace index', 'FontSize', 80)
        figure;
        imagesc(z)
        set(gca,'xticklabel',{[]})
        set(gca,'yticklabel',{[]})
        xlabel('L', 'FontSize', 80)
        ylabel('Subspace index', 'FontSize', 80)
        
    case 'Fig5'
        addpath('./fusiogram_code')
        run_fusiogram;
end
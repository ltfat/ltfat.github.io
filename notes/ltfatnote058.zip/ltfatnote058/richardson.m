% Relaxed Richardson 
function [fout,err,numofit] = richardson(f,S,varargin)
%
% Do a relax Richardson iteration.
% Guaranteed to converge for positive matrices and  relaxation
% parameter < (2/||S||)
%
% extension of frameit4 used in [Double].
%
% f  Signal / function / rhs
%
% F Matrix 
%
% 'relax' Relaxation parameter
%
% 'thresh': Set a certain threshold
%
% 'maxiter' Maximal iteration
%
% 'outputalliter': Put out all iterations
%
% Output
%
% fout Last iterations / all iterations ('outputalliter')
% 
% err error
%
% numofit : number of iterations
% 
%
% This corresponds to the "frame algorithm" (See [Christensen].)
%
% See https://en.wikipedia.org/wiki/Modified_Richardson_iteration
%
% [Christensen] Christensen, O.; An Introduction to Frames and Riesz Bases;
%  Birkhäuser, 2016
%
% [Double] Balazs, P.; Feichtinger, H. G.; Hampejs, M. & Kracher, G.; 
% Double preconditioning for Gabor frames, IEEE Trans. Signal Process., 
% 2006, 54, 4597-4610
%
% [Meister] Andreas Meister: Numerik linearer Gleichungssysteme. 
%  2. Auflage. Vieweg 2005, ISBN 3-528-13135-7
%
% Created: 25.01.2022
% Last:    18.02.2022
%
% Author: Peter Balazs
%
% Copyright : (c) Acoustics Research Institute, Austrian Academy of
%              Science
%              http://www.kfs.oeaw.ac.at
%
%              Permission is granted to modify and re-distribute this
%              code for non-commercial usage in any manner as long as this
%              notice is preserved. For research please cite the paper [1]. 
%              All standard disclaimers apply.
%
% [1] P. Balazs, M. Shamsabadi, A. Arefijamaal, G. Chardon, "Representation
% of Operators Using Fusion Frames", submitted, 2022

% Next Steps:
% % Check if frame, then we could do a fast thingie .... using frameaccel

if nargin< 2
    error("This function needs at least two inputs.");
end

[L,M] = size(S);
if L ~= M
    error("The matrix has to be quadratic.");
end

if length(f) ~= L
    error("The size of the matrix and the function do not match.");
end

go_thresh = 1;
go_iter = 0;
test_rich = 0;
all_iter = 0;

if nargin > 2
    ii = 1;
    while ii+2 <= nargin
        switch(varargin{ii})
            case 'relax' 
                ii = ii+1;
                relax = varargin{ii};
            case 'thresh'
                go_thresh = 1;
                ii = ii +1;
                thresh = varargin{ii};
            case 'maxiter'
                go_iter = 1;
                ii = ii +1;
                maxiter = varargin{ii};
            case 'outputalliter'
                all_iter = 1;
        end
        ii = ii+1;
    end
end

if exist('relax') ~= 1
    [U,D,V] = svd(S);
    B = D(1,1);       
    % upper bound / biggest singular values

    % see RichardsonBlock for ideas ....
    A = D(L,L);      
    % lower bound / lowest singular value
    relax  = 2/(A+B); 
    % optimal relaxation parameter 

    % For Debugging
end

if test_rich == 1
    Id = eye(L);
    MMM = Id-relax*S;
    
    convergence = norm(MMM); 
    
    fprintf("The convergence rate is %f\n",convergence);

end


if exist('thresh') ~= 1
    thresh = 0.00000001; 
    % Default Threshold
end; 

%%% Iteration:
% Initialization
f0 = zeros(L,1); 
er = thresh + 1; 
ii = 1;
jj = 1;

while er >  thresh;
  % for Debgging
  d = S*f0;
  dd = relax*(f-d);
  f1 = f0 +dd;

  er = norm(dd);
  % = norm(f0-f1);
  % absolute error

  if ii > 1
      rrr = er - err(ii-1);
  else
      rrr = er;
  end
  err(ii)=er;

  if rrr >= eps && test_rich == 1 % eror is getting worse
      jj = jj +1 ;
      if jj < 10 
         warning(sprintf("Not converging .... Iteration: %i, Difference: %f",ii,rrr))
      else
         error(sprintf("Not converging .... Iteration: %i, Difference: %f",ii,rrr))
      end
  end

  f0 = f1;
  numofit = ii; 
  
  if all_iter == 1
      fout{ii} = f1;
  else
      fout = f1; 
  end

    ii = ii+1; 

  if go_iter == 1 && ii > maxiter
      break
  end

end






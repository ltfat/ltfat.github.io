function varargout = fusiogram(F, sig, varargin)
%FUSIOGRAM calculates and displays the local fusiogram
%
%   Input parameters:
%     F        fusion frame
%     sig      input signal
%     layout   struct containing the layout
%
%   Output parameters:
%     fusio    the fusiogram data
%     ah       lower bound global frame
%     bh       upper bound global frame
%
%   `fusiogram` displays fusion frames
%
%   Dependencies: LTFAT

% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Authors: P. Balazs and C. Hollomey (2023), Acoustics Research Institute

definput.flags.plottype = {'all', 'fusio', 'raw', 'norm'};
definput.keyvals.ncols = 3;
definput.keyvals.nrows = 2;
definput.keyvals.toverlap = 0.1;
definput.keyvals.foverlap = 0.1;
definput.keyvals.fbounds = 0;
definput.keyvals.layout = [];

[flag,kv]=ltfatarghelper({},definput,varargin);

%check frametype == fusion
if ~strcmp(F.type, 'fusion')
    error('fusiogram works for fusion frames only.')
end
%and check that local frames are suitable
for ii = 1:F.Nframes
    if ~(strcmp(F.frames{ii}.type, 'dgt') || strcmp(F.frames{ii}.type, 'fwt'))
        disp('fusiogram supports dgt and fwt local frames only.')
    end
end

L = length(sig);

%check/correct for the layout
if ~isfield(kv.layout, {'start_idx1', 'start_idx2', 'end_idx1', 'end_idx2'})
    %retrieve the indices
    Lcol = L/kv.ncols; %length of one column
    Lrow = L/(2*kv.nrows)+1;%length of one row (half, to display only positive f)
    toverlap = floor(kv.toverlap*Lcol)*ones(1,nrows*ncols);
    foverlap = floor(kv.foverlap*Lrow)*ones(1,nrows*ncols);


    %get the indices for the display of overlapping frame sequences
    [start_idx1, start_idx2, end_idx1, end_idx2] = ...
        get_indices(Lcol, Lrow, toverlap, foverlap, kv.nrows, kv.ncols);

    start_idx1 = start_idx1(:);
    end_idx1 = end_idx1(:);
else
    start_idx1 = kv.layout.start_idx1;
    end_idx1 = kv.layout.end_idx1;
    start_idx2 = kv.layout.start_idx2;
    end_idx2 = kv.layout.end_idx2;
end

nrows = kv.layout.nrows;
ncols = kv.layout.ncols;

%% get the DGT tiles and frame sequences
%expand the synthesis matrix on the t-f plane for later display
%local_dgt_raw...the raw t-f values
%local_dgt_tiles...t-f values, with interpolated f-values
[local_dgt_raw, local_dgt_tiles, ~] = ...
    mapdgt(sig, F.frames{2}.a, F.frames{2}.M);

%pick the dgt frame sequences from the DGT synthesis matrix
fseq = pick_dgt(start_idx1, end_idx1, start_idx2, end_idx2);

%display only the positive frequencies
local_dgt_tiles = local_dgt_tiles(1:L/2, :);
local_dgt_raw = local_dgt_raw(1:L/2, :);

%get the fwt tiles (frame sequences are extracted later on below, ~l.110 ff)
[local_wl_raw, local_wl_tiles, F_wl] = ...
    mapfwt(sig, F.frames{1}.J);


%% cut out the tiles
ct=1;
for kk = 1:nrows*ncols
    if strcmp(F.frames{kk}.type, 'dgt')
        %we have 3 types of display...
        %...the interpolated one...
        F.tiles{kk} = local_dgt_tiles(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        %...the raw t-f points...
        F.raw{kk} = local_dgt_raw(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        %...the norms per tile...
        z=F.raw{kk};
        z(isnan(z)) = 0;
        F.norms{kk} = norm(z);
        
        if kv.fbounds
            fmat{kk} = fseq{ct};
            %fmat{kk} = F_dgt(:,start_idx1(kk):end_idx1(kk));
            ct = ct+1;
            F_local(kk) = frame('gen', fmat{kk}');
            [A_local(kk), B_local(kk)] = framebounds(F_local(kk));
            %fmat{kk} = fmat{kk}';
        end
                
    elseif strcmp(F.frames{kk}.type, 'fwt')
        %...and the same as above for the wavelets
        F.tiles{kk} = local_wl_tiles(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        F.raw{kk} = local_wl_raw(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        z=F.raw{kk};
        z(isnan(z)) = 0;
        F.norms{kk} = norm(z);
        
        if kv.fbounds
            %frame bounds of the local frames: fwt
            %picking the frame elements for the wavelet basis...
            fmat{kk} = F_wl(:,start_idx1(kk):end_idx1(kk));
            F_local(kk) = frame('gen', fmat{kk});
            [A_local(kk), B_local(kk)] = framebounds(F_local(kk));
            fmat{kk} = fmat{kk}';
        end

    else
        disp('not implemented.')
    end
    
end

%% assemble the representation

representation = nan(max(end_idx2), max(end_idx1));
representation_raw = nan(max(end_idx2), max(end_idx1));
representation_norm = zeros(max(end_idx2), max(end_idx1));
averagetmp = zeros(max(end_idx2), max(end_idx1));
averagenorm = zeros(max(end_idx2), max(end_idx1));


for ii = 1: nrows*ncols
    x = F.tiles{ii};
    z = F.raw{ii};
    y = F.norms{ii}.*ones(size(F.tiles{ii}));
    xf = 1;
    for f_i = start_idx2(ii):1:end_idx2(ii) 
            xt = 1;
        for t_i = start_idx1(ii):1:end_idx1(ii)
            representation_norm(f_i, t_i) = representation_norm(f_i, t_i) + y(xf,xt);
            averagenorm(f_i, t_i) = averagenorm(f_i, t_i) + 1;
             %nan+int = nan; therefore, distinguish here to be able to add up  
            if (~isnan(representation(f_i, t_i)) && ~isnan(x(xf,xt)))
                representation(f_i, t_i) = representation(f_i, t_i) + x(xf,xt);
                representation_raw(f_i, t_i) = representation_raw(f_i, t_i) + z(xf,xt);
                averagetmp(f_i, t_i) = averagetmp(f_i, t_i) + 1;
            elseif (isnan(representation(f_i, t_i)) && ~isnan(x(xf,xt)))
                representation(f_i, t_i) = x(xf, xt);
                representation_raw(f_i, t_i) = z(xf, xt);
                averagetmp(f_i, t_i) = 1;
            elseif (~isnan(representation(f_i, t_i)) && isnan(x(xf,xt)))
                representation(f_i, t_i) = representation(f_i, t_i);
                representation_raw(f_i, t_i) = representation_raw(f_i, t_i);
                averagetmp(f_i, t_i) = averagetmp(f_i, t_i);
            elseif (isnan(representation(f_i, t_i)) && isnan(x(xf,xt)))
                representation(f_i, t_i) = nan;
                representation_raw(f_i, t_i) = nan;
                averagetmp(f_i, t_i) = nan;
            end
            xt = xt+1;
        end
        xf = xf+1;
    end

end

%average over points that contain more than one frame element
averagetmp(averagetmp==0) = 1;
averagetmp(isnan(averagetmp)) = 1;
fusiotmp = representation./averagetmp;
fusioraw = representation_raw./averagetmp;
representation_norm = representation_norm./averagenorm;


%% interpolate the nans
ct = 0;
cmat_interp = fusiotmp(1:end,:);
while sum(sum(isnan(cmat_interp)))
    for ii = 1:size(cmat_interp, 1)
        %interpolate along the second dimension, i.e. per row
        cmat_interp(ii,:) = fillmissing(cmat_interp(ii,:),'spline', 2);
    end
    ct = ct+1;
    if ct > 100
        break;
    end
end

if sum(sum(isnan(cmat_interp)))
    disp('interpolation did not remove all nans')
end


if kv.fbounds

%calculate the frame bounds of the global frame...
        H1 = [fmat{1}; fmat{2}; fmat{3}; fmat{4}; fmat{5}; fmat{6}];
        H = frame('gen', H1');
        [ah, bh] = framebounds(H);
        sprintf('global frame bound ratio: %i', bh/ah)  
%...and the frame bounds of the fusion frame
        for ii=1:nrows*ncols
            %fmat{ii}=fmat{ii}.';
            eval(sprintf('F_%i = frame(''gen'', fmat{ii});', ii));
        end
        fusionframe = frame('fusion', ones(nrows*ncols,1), F_1, F_2, F_3, F_4, F_5, F_6);
        [A0, B0] = framebounds(fusionframe);
        sprintf('fusion frame bound ratio: %i', B0/A0)
end

fusio = cmat_interp;



%% plots

if flag.do_all
    flag.do_fusio = 1;
    flag.do_raw = 1;
    flag.do_norm = 1;
end

if flag.do_fusio

    figure
    %plot the fusiogram
    disp1 = log(fusio(1:end,1:end));
    normc = abs(max(max(disp1(~isinf(disp1)))));
    imagesc((1*abs(log(fusio(1:end,1:end))+normc*ones(size(disp1)))))
    colorbar
    colormap(flipud(hsv))
    set(gca,'YDir','normal')
    xlim([0 max(end_idx1)])

    %the lines to display the local frames
    hold on
    for ll=1:nrows*ncols
    line([start_idx1(ll) end_idx1(ll)],[end_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([start_idx1(ll) end_idx1(ll)],[start_idx2(ll) start_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([start_idx1(ll) start_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([end_idx1(ll) end_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    end

    a = get(gca,'XTickLabel');  
    set(gca,'XTickLabel',a,'fontsize',48)
    set(gca,'XTickLabelMode','auto')
    xlabel('Time [samples]', 'Fontsize', 48)
    ylabel('Frequency [au]', 'Fontsize', 48)

end

if flag.do_raw
    figure
    %plot the raw data
    imagesc((abs((representation_raw./averagetmp))./max(abs(representation_raw./averagetmp))))
    colorbar
    set(gca,'YDir','normal')
    xlim([0 max(end_idx1)])

    %the lines to display the local frames
    hold on
    for ll=1:nrows*ncols
    line([start_idx1(ll) end_idx1(ll)],[end_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([start_idx1(ll) end_idx1(ll)],[start_idx2(ll) start_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([start_idx1(ll) start_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([end_idx1(ll) end_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    end

    a = get(gca,'XTickLabel');  
    set(gca,'XTickLabel',a,'fontsize',48)
    set(gca,'XTickLabelMode','auto')
    xlabel('Time [samples]', 'Fontsize', 48)
    ylabel('Frequency [au]', 'Fontsize', 48)
end

if flag.do_norm
    
    figure;
    %plot the norms
    imagesc(representation_norm)
    colorbar
    set(gca,'YDir','normal')
    xlim([0 max(end_idx1)])

    set(gca,'xticklabel',{[]})
    set(gca,'yticklabel',{[]})

    %the lines to display the local frames
    hold on
    for ll=1:nrows*ncols
    line([start_idx1(ll) end_idx1(ll)],[end_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([start_idx1(ll) end_idx1(ll)],[start_idx2(ll) start_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([start_idx1(ll) start_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    line([end_idx1(ll) end_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
    end
    a = get(gca,'XTickLabel');  
    set(gca,'XTickLabel',a,'fontsize',48)
    set(gca,'XTickLabelMode','auto')
    set(gca,'xticklabel',{[]})
    set(gca,'yticklabel',{[]})

end


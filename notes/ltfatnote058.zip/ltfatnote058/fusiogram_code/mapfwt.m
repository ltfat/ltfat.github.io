function [fmat, framemat, F_wl] = mapfwt(sig, J)
%MAPFWT expands fast wavelet transform coefficients to the time-frequency grid
%
%   Input parameters:
%     sig        input signal
%     J          iteration depth of the wavelet tree
%
%   Output parameters:
%     fmat          the expanded wavelet frame
%     framemat      the interpolated expanded wavelet frame
%     F_wl          the frame synthesis matrix
%
%   `mapfwt` expands the fwt coefficients to the whole time-frequency plane

L = length(sig);

F_2d = frame('fwt', 'db8', J);
F_2b = frameaccel(F_2d, L);
F_wl = frsynmatrix(F_2b, L)';



for ii = 1:J
    %f(ii) = 3*L/2^log2(ii);
        f(ii) = 4/3*floor(L./2.^(ii));
    fi(ii) = L/2^ii;
end
f(J+1)=f(J);
f = flip(f);
fi(J+1)=fi(J);
fi = flip(fi);


for jj = 1:L

    for ii = 1:J+1
        a(ii) = 2^ii;
        %a(ii) = ceil(3*L/2^ii);
    end
    a = flip(a);
    a(1) = ceil(a(1)/2);


for ii = 1:L
    sn(ii) = F_wl(ii,:)*sig;
end
gg = wavpack2cell(sn, fi);


for kk=1:J+1
    g1(kk,:) = upsample(gg{kk}, a(kk));
    g1(g1==0) = nan;
end
g1 = g1 + g1;
end

%map frequencies
fmat = zeros(L,L);
for ii = 1:J+1
    fmat(round(f(ii)/2), :) = g1(ii,:);
end

%interpolate frequencies
framemat = nan(L/2,L);
ct = 1;
for ii = 1:J+1
    while floor(f(ii)/2) > ct
    framemat(ct, :) = g1(ii,:);
    %fmat(ct+1, :) = nan;
    ct = ct + 1;
    end
end

framemat(ct:end,:) = repmat(g1(end,:), ceil(numel(ct:size(framemat,1))), 1);
function [f, f_interp, F_dgt] = mapdgt(sig, a, M)
%MAPDGT expands discrete Gabor coefficients to the time-frequency grid
%
%   Input parameters:
%     sig        input signal
%     a          downsampling factor in time
%     M          number of frequency channels
%
%   Output parameters:
%     f          the expanded Gabor frame
%     f_interp   the interpolated expanded Gabor frame
%     F_dgt      the frame synthesis matrix
%
%   `mapdgt` constructs the t-f plane from the DGT synthesis matrix
%   accounting for unreachable points.

% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% C.Hollomey(2022)

L = length(sig);

F_1d = frame('dgt', 'gauss', a, M);
F_2a = frameaccel(F_1d, L);
F_dgt = frsynmatrix(F_2a, L).';

for ii = 1:M:size(F_dgt,1)+1-M
    
    for jj = ii:M+ii-1
        f(jj) = F_dgt(jj,:)*sig;
    end
end
fi = reshape(f, M, L/a);%here, we have all the reachable points

%now, we expand to the whole t-f plane
ct = 1;
test = zeros(L, L);
for ii = 1:L/M:L+1
    test(ii,:) = upsample(fi(ct,:), a);
    test(test==0) = nan;
end
f = test(1:L, :);

ct = 1;
testin = nan(L, L);
for ii = 1:L/M:L
    testin(ii:ii+L/M,:) = repmat(upsample(fi(ct,:), a),numel([ii:ii+L/M]),1);
    testin(testin==0) = nan;
    ct = ct + 1;
end
f_interp = testin;
      
F_dgt = F_dgt.';
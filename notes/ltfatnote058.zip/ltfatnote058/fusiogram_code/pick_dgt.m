function fseq = pick_dgt(start_idx1, end_idx1, start_idx2, end_idx2)
%this function picks frame sequences from a discrete Gabor synthesis matrix
%
% dependencies: LTFAT

% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% 11.01.2023, C. Hollomey

L = 384;

M = 48;
a = 16;
N = L/a;

F_1d = frame('dgt', 'gauss', a, M);
F_2a = frameaccel(F_1d, L);
F_dgt = frsynmatrix(F_2a, L).';

% frame parameters
M = L/8;
a = 16;
J = 6;
dgtred = M/a;

% layout parameters
nrows = 2; 
ncols = 3;
toverlap = 0.1;
foverlap = 0.1;

Lcol = L/ncols; %length of one column
Lrow = L/(2*nrows);%length of one row (half, to display only positive f)
toverlap = floor(toverlap*Lcol)*ones(1,nrows*ncols);
foverlap = floor(foverlap*Lrow)*ones(1,nrows*ncols);


%get the indices for the display of overlapping frame sequences
% [start_idx1, start_idx2, end_idx1, end_idx2] = ...
%     get_indices(Lcol, Lrow, toverlap, foverlap, nrows, ncols);
% 
% start_idx1 = start_idx1(:);
% end_idx1 = end_idx1(:);

start_idx2 = reshape(start_idx2, nrows, ncols);
end_idx2 = reshape(end_idx2, nrows, ncols);
foverlap = reshape(foverlap, nrows, ncols);

%conjugate complex
s_fourier = [start_idx2; start_idx2 - foverlap + L/nrows]/(L/M);
e_fourier = [end_idx2; end_idx2 - foverlap + L/nrows+1]/(L/M);

s_fourier = floor(s_fourier);
s_fourier(s_fourier==0)=1;
e_fourier = floor(e_fourier);

%pick frame sequences (assuming sequences are aligned in time)
t_start = start_idx1 * M*N/L;
t_start = reshape(t_start, nrows, ncols);
t_start = t_start(1,:); 
t_end = end_idx1 * M*N/L;
t_end = reshape(t_end, nrows, ncols);
t_end = t_end(1,:);


for ii = 1:ncols
    %collect all frame elements per column
    for jj = 1:nrows
        seq{1} = [];
        ct = 2;
        c = 0;
        for kk = t_start(ii):M:t_end(ii)
            %conjugate complex
            seq{ct} = [seq{ct-1}; F_dgt(kk+s_fourier(jj,ii):kk+e_fourier(jj,ii),:)];
            seq{ct} = [seq{ct}; F_dgt(kk+s_fourier(2*nrows-c,ii):min(kk+e_fourier(2*nrows-c,ii), size(F_dgt,2)),:)];
            ct = ct + 1;
        end
        s{jj} = seq{ct-1};
        c = c + 1;
    end
    seq_col{ii} = s;
end

fseq{1} = seq_col{1}{1};
fseq{2} = seq_col{1}{2};
fseq{3} = seq_col{2}{1};
fseq{4} = seq_col{2}{2};
fseq{5} = seq_col{3}{1};
fseq{6} = seq_col{3}{2};
%this script reproduces the local fusiogram from the Chapter 
% "A Survey of Fusion Frames in Hilbert Spaces"
%
% dependencies: LTFAT
%
% Authors: P. Balazs and C. Hollomey (2023), Acoustics Research Institute

clear all
clc
%% input signal
L = 384;
fs = L;                   % samples per second
dt = 1/fs;                % seconds per sample
tstop = 1;
t = (0:dt:tstop-dt)';     % seconds

sig = randn(L,1);    % random signal 
wind = circshift(pgauss(L, 10)./max(pgauss(L,10)), sum(L)/2); 
                     % A Gaussian window 
sign = sig.*wind; % window applied
x = zeros(L,1);
fc = 48;             % Frequency 
sig = sin(2*pi*fc*t)+sign +x; % a sinusoid is added to the signal 
sig(320:325) = 2;    % an impulse


figure;
%plot the input signal
plot(sig, 'LineWidth', 2)
hold on
grid on
plot(wind, 'LineWidth', 2)
xlabel('Time [samples]', 'Fontsize', 48)
xlim([0 L])
vv = max(abs(sig));
ylim([-1.1*vv 1.1*vv])
a = get(gca,'XTickLabel');  
set(gca,'XTickLabel',a,'fontsize',48)
set(gca,'XTickLabelMode','auto')
xlabel('Time [samples]', 'Fontsize', 48)
ylabel('Amplitude [au]', 'Fontsize', 48)


%create fusion frame with tiles in correct order
%(we only use segments of those frames)
% frame parameters
% Gabor:
M = L/8; % Frequency bins
a = 16;  % hop size
dgtred = M/a;
g = 'gauss';

% Wavelet:
w = 'db8';
J = 6;   % wavelet order


F_1 = frame('fwt', w, J);
F_2 = frame('dgt',g,a,M);
F_3 = frame('dgt',g,a,M);
F_4 = frame('fwt', w, J);
F_5 = frame('fwt', w, J);
F_6 = frame('dgt',g,a,M);

weights = ones(6,1);
F = frame('fusion', weights, F_1, F_2, F_3, F_4, F_5, F_6);

%specify the layout
% number of 'super-windows' Q_i
layout.nrows = 2; 
layout.ncols = 3;

layout.toverlap = 0.03;   % overlap in time
layout.foverlap = 0.03;   % overlap in frequency

layout.start_idx1 = [ 1 1 115 115 243 243].';
layout.end_idx1 = [141 141 269 269 384 384].';
layout.start_idx2 = [ 1 86 1 86 1 86].'; 
layout.end_idx2 = [105 192 105 191 105 192].';

fusiogram(F, sig, 'layout', layout, 'fbounds', 1);
function [a, x] = plotfigure2(G, f, viewx, viewy)
%PLOTFIGURE2 Fusion Frame in 3D
%
%   plots the projection of a vector on a fusion frame system
%   reproduces in its default configuration Figure 2 from
%   "A Survey of Fusion Frames in Hilbert Spaces"
%
%   Dependencies: vectarrow from
%                 'Plot 2D/3D Vector with Arrow' by Rentian Xiong 
%                 http://www.mathworks.com/matlabcentral/fileexchange/loadFile.do?objectId=7470&objectType=file

% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

%   this code is based on `plot3Dframe` and `plotfuframe3D` by P. Balazs
%   Start: 18.02.2022
%   Last: 28.02.2023


transp = 0.25; % Make the surfaces transparent? 
text_distance = -0.05;
text_distance2 = -0.1;
plotlocal = 1;

borderX = 2;
borderY= 2;

color1 = [0 0.9 0; 0.9290 0.6940 0; 0.1 0.9 0.1; ];
color2 = [0, 0.6, 0.1; 0.8500 0.3250 0.0980; 1, 0.6, 0.6; 1, 1, 0.6];
color3 = [0.4 0.4 0.4; 0.4 0.4 0.4];


% Do fusion frame analysis
fu_coeff = fuana(G,f);

%TODO: confirm projection directions => check!
hold on
[X, Y] = meshgrid(-borderX:0.5:borderX,-borderY:0.5:borderY);
for ii = 1:G.Nframes

    g1 = G.frames{ii}.g(:,1);
    g2 = G.frames{ii}.g(:,2);

    normal = cross(g1, g2);
    if normal(3) ~= 0
        Z = (normal(1)* X + normal(2)*Y)/(-normal(3));
        surf(X,Y,Z,'FaceColor',color1(ii,:),'EdgeColor','none','FaceAlpha',transp);
    elseif normal(2) ~= 0
        Z = (normal(1)* X + normal(3)*Y)/(-normal(2));
        surf(X,Z,Y,'FaceColor',color1(ii,:),'EdgeColor','none','FaceAlpha',transp);
    elseif normal(1) ~= 0
       Z = (normal(3)* X + normal(2)*Y)/(-normal(1));
       surf(Z,Y,X,'FaceColor',color1(ii,:),'EdgeColor','none','FaceAlpha',transp);
    else
        error('NO!');
    end

   
    v_new = fu_coeff{ii};

    v = v_new;
   
    qH = quiver3(0,0,0,v(1),v(2),v(3),'Color',color3(ii,:),'LineWidth',2,'MaxHeadSize',1.5);
    text_text = char(sprintf('p_%i',ii));
    if ii == 1
    text(v(1)+0.1, v(2)+text_distance, v(3)+text_distance2, text_text,'Fontsize', 24,'Color',color3(ii,:), 'FontWeight', 'bold')
    else
    text(v(1)-0.2, v(2)+text_distance, v(3)+text_distance2, text_text,'Fontsize', 24,'Color',color3(ii,:), 'FontWeight', 'bold')
    end
    
    qH.LineStyle = '-';
    qH.LineWidth = 2;


    %plot the projections
    [~, M] = size(G.frames{ii}.g);
    if plotlocal
        for jj = 1:M
            quiver3(0,0,0,G.frames{ii}.g(1,jj),G.frames{ii}.g(2,jj),G.frames{ii}.g(3,jj),'Color',color2(ii,:),'LineWidth',2,'MaxHeadSize',1.5);
            text_text = char(sprintf("\\phi_%i^{(%i)}",jj,ii));

            text(G.frames{ii}.g(1,jj)+text_distance,G.frames{ii}.g(2,jj)+text_distance,...
                    G.frames{ii}.g(3,jj)+text_distance,...
                text_text,'Fontsize', 24,'Color',color2(ii,:), 'FontWeight', 'bold')
        end
    end
    
end
%plot f
%vectarrow(zeros(3,1),f);
 quiver3(0,0,0,f(1),f(2),f(3),'Color','k','LineWidth',2,'MaxHeadSize',1.5);
     
   text(f(1)+text_distance2, f(2)+text_distance2, f(3)+text_distance2, 'f','Fontsize', 24,'Color','k', 'FontWeight', 'bold')



a = gca;
a.View = [viewx viewy];
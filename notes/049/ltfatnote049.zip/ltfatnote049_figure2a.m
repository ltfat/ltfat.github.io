Ls = 44100;
fs = 44100;
fmax = fs/2;
bins = 1;
bins_hi = 4;

co = bsxfun(@times,ones(5,3),[0,0.2,0.35,0.55,0.7]');
set(groot,'defaultAxesColorOrder',co);

%s = gspi;
%s = wavread('kafziel.wav');
%Ls = length(s);

%% Example 1 (ERBlets):
[g,a,fc]=warpedfilters(@freqtoerb,@erbtofreq,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

figure(1); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs,'opts',{'Linewidth',1.4});
xlim([0,1.2e3]);
ylabel('');set(gca,'YTickLabel',[]);
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
pos =get(gcf,'Position'); pos(3) = 1.2*pos(4); set(gcf,'Position',pos);
export_fig('../pics/erbFilters.pdf','-transparent','-painters','-p15')

%title('ERBlet filter transfer functions');

% %% Example 2 (ERBlets - 4 bins/ERB):
% [g,a,fc]=warpedfilters(@freqtoerb,@erbtofreq,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');
% 
% figure(2); 
% filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
% title('ERBlet filter transfer functions (4 bins/ERB)');

%% Example 3 (Square root warping):
warpfun_sqrt = @(x) sign(x).*((1+abs(x)).^(1/2)-1);
invfun_sqrt = @(x) sign(x).*((1+abs(x)).^2-1);
[g,a,fc]=warpedfilters(warpfun_sqrt,invfun_sqrt,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

figure(3); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs,'opts',{'Linewidth',1.4});
xlim([0,1.2e3]);
ylabel('');set(gca,'YTickLabel',[]);
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
pos =get(gcf,'Position'); pos(3) = 1.2*pos(4); set(gcf,'Position',pos);
export_fig('../pics/sqrtFilters.pdf','-transparent','-painters','-p15')

% [g,a,fc]=warpedfilters(warpfun_sqrt,invfun_sqrt,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');
% 
% figure(4); 
% filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
% title('Square root warped filter transfer functions');

%% Example 4 (linear warping (uniform filter bank):
warpfun = @(x) x/100;
invfun = @(x) 100*x;
[g,a,fc]=warpedfilters(warpfun,invfun,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

figure(5); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs,'opts',{'Linewidth',1.4});
xlim([0,1.2e3]);
ylabel('');set(gca,'YTickLabel',[]);
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
pos =get(gcf,'Position'); pos(3) = 1.2*pos(4); set(gcf,'Position',pos);
export_fig('../pics/uniformFilters.pdf','-transparent','-painters','-p15')


% [g,a,fc]=warpedfilters(warpfun,invfun,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');
% 
% figure(6); 
% filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);
% title('uniform filter transfer functions');

%% Example 4 (logarithmic (constant-Q) warping):
warpfun_log = @(x) 10*log(x);
invfun_log = @(x) exp(x/10);
fmin = 50; % The logarithm's derivative 1/x tends to Inf for x towards 0
[g,a,fc]=warpedfilters(warpfun_log,invfun_log,fs,fmin,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

figure(7); 
filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs,'opts',{'Linewidth',1.4});
xlim([0,1.2e3]);
ylabel('');set(gca,'YTickLabel',[]);
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
pos =get(gcf,'Position'); pos(3) = 1.2*pos(4); set(gcf,'Position',pos);
export_fig('../pics/cqFilters.pdf','-transparent','-painters','-p15')



% %% Example 4 (logarithmic (constant-Q) warping - 4 bins):
% warpfun_log = @(x) 10*log(x);
% invfun_log = @(x) exp(x/10);
% fmin = 50; % The logarithm's derivative 1/x tends to Inf for x towards 0
% [g,a,fc]=warpedfilters(warpfun_log,invfun_log,fs,fmin,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');
% 
% figure(8); 
% filterbankfreqz(g,a,Ls,'plot','linabs','posfreq','fs',fs);

%% Basic functions and quantities (independent of the chosen warping function)

% Stretching factor for prototype (default = 3 )
R = 3;

% Redundancy modifier ( default = 1, setting of Corollary 4.4 )
redMod = 1;

% Values of epsilon to test
epsilonVec = (1:5);

% Prototype function (default = Hann window )
Hann = @(x) 0.5 + 0.5.*cos(2*pi*x./R);
 
%% Warping function dependent quantities 
% (be sure to modify all quantities in this section appropriately if you
% change the warping function)

% Warping function and inverse
warpfun = @(x) 10.*log(x);
iwarpfun = @(x) exp(x./10);

% Derivative and moderating weight
weight = @(x) exp(x./10)./10;
modweight = @(x) exp(x./10);

% Definite integral of the moderating weight (see paragraph before
% Corollary 4.4)
Vint = @(x,y) 10.*(exp(y./10)-exp(x./10));

% For warpfun = 10*log, Av equals max(x,x*exp(x/10)), since exp(x/10) is 
% increasing and <= 1 for negative x.
%
% The following code requires Lambert_W.m to compute the Lambert W
% function, available at 
% https://blogs.mathworks.com/cleve/2013/09/02/the-lambert-w-function/
% or 
% https://www.mathworks.com/matlabcentral/fileexchange/43419-the-lambert-w-function
%
% ( For other warping functions, be sure to modify this line appropriately )
AvInv = @(x) (x<=0).*x + 10.*(x>0).*Lambert_W(abs(x)/10); 

%% Basic functions and quantities (!do not change!)

% Weights (see Theorem 4.6)
W1 = @(x,y) (1+abs(x)).^(-1-y);
W2 = @(x,y) (1+abs(Vint(0,x))).^(-1-y);

% Support bounds of prototype function
thetaSuppMin = -R/2;
thetaSuppMax = R/2;

% Optimal aTilde (see Corollary 4.4)
aTildeMax = 1./Vint(thetaSuppMin,thetaSuppMax);
aTilde = aTildeMax./redMod;

% Probing values for maxima of weight supremum norms of theta
idx = linspace(thetaSuppMin,thetaSuppMax,R*6000).';
HannIdx = Hann(idx);

% Maximum and minimum of periodized squared magnitudes
Fresp = sum(reshape(HannIdx.^2,6000,R),2);

%% Quantities to compute

% Initialize
C1 = zeros(numel(epsilonVec),1);
C2 = zeros(numel(epsilonVec),1);
Term1 = zeros(numel(epsilonVec),1); 
Term2 = zeros(numel(epsilonVec),1); 
Term3 = zeros(numel(epsilonVec),1); 

% Compute intermediate values
for kk = epsilonVec
    C1(kk) = max(HannIdx./W1(idx,kk)); 
    C2(kk) = max(HannIdx./W2(idx,kk));
    
    
    Term1(kk) = 4*(1+1/kk).*(1+(aTilde+0.5)/kk).*(aTilde/(aTilde+0.5)).^(1+kk);
    Term2(kk) = (1+(1/kk).*(1+abs(AvInv(0.5./aTilde))))./(1+abs(AvInv(0.5./aTilde))).^(1+kk);
    Term3(kk) = (1+(1/kk).*(1+abs(AvInv(-0.5./aTilde))))./(1+abs(AvInv(-0.5./aTilde))).^(1+kk);
end

% Compute estimate for P (see Lemma 4.8, end of proof)
Pest = C1.*C2.*(Term1 + Term2 + Term3);

%% Output all computed values
[C1.*C2,Term1,Term2,Term3,Pest]

MaxFR = max(Fresp)
MinFR = min(Fresp)

function ltfatnote049_table1
Ls = 44100;
fs = 44100;
fmax = fs/2;
bins = 1;
%fac = [1,7/8,3/4,2/3,5/8,1/2,5/12,3/8];
fac = [1, 2/3, 1/2, 5/12, 3/8];

eigstol = 1e-4;
eigsmaxit = 100;

pcgmaxit = 150;
pcgtol = 1e-4;

warpfun = cell(4,1);
invfun = cell(4,1);

% ERBlet warping
 warpfun{3} = @freqtoerb;
 invfun{3} = @erbtofreq;
% constant-Q warping
 warpfun{4} = @(x) 10*log(x);
 invfun{4} = @(x) exp(x/10);
% sqrt-warping
 warpfun{2} = @(x) sign(x).*((1+abs(x)).^(1/2)-1);
 invfun{2} = @(x) sign(x).*((1+abs(x)).^2-1);
% Linear warping
 warpfun{1} = @(x) x/100;
 invfun{1} = @(x) 100*x;
 
 fmin = [0,0,0,50];

A = zeros(4,length(fac));
B = ones(4,length(fac));

Aworse = zeros(4,length(fac));
Bworse = ones(4,length(fac));

red = A;

for jj = 1:4
    [gorig,aorig,fc,L] = warpedfilters(warpfun{jj},invfun{jj},fs,fmin(jj),fmax,bins,Ls,'bwmul',1.5,'fractional','complex');
    gf = filterbankresponse(gorig,aorig,Ls); framebound_ratio = max(gf)/min(gf);

    disp(['Painless system frame bound ratio: ', num2str(framebound_ratio)]);
    
    for kk = 1:length(fac)
        a = aorig;
        g = gorig;
        idx = [2:length(fc)/2,length(fc)/2+2:length(fc)];
        a(idx,2) = ceil(a(idx,2).*fac(kk));
        red(jj,kk) = sum(a(:,2)./a(:,1));

        g([1,length(fc)/2+1]) = filterbankscale(g([1,length(fc)/2+1]),sqrt(fac(kk)));
        [g,a]=filterbankwin(g,a,L,'normal');

        [Aworse(jj,kk),Bworse(jj,kk)] = filterbankboundworseest(g,a,L);
        
        F = frame('filterbank',g,a,numel(g));
        [A(jj,kk),B(jj,kk)] = framebounds(F,Ls,'tol',eigstol,'pcgtol',pcgtol,'maxit',eigsmaxit,'pcgmaxit',pcgmaxit);

     end
end

disp('This is a ratio B/A. Rows - warping sunction, Cols - redundancy compared to te minimal painless case')
B./A
disp('Worse estimates of B/A')
Bworse./Aworse
disp('Exact redundancy')
red

assignin('base', 'A', A);
assignin('base', 'B', B);
assignin('base', 'Aworse', Aworse);
assignin('base', 'Bworse', Bworse);





function [A,B] = filterbankboundworseest(g,a,L)
Hresp = filterbankresponse(g,a,L);
H = filterbankfreqz(g,a,L);
N = a(:,2);
a = a(:,1)./a(:,2);

for m=1:size(H,2)
    alias = zeros(L,1);
    for aidx = 1:floor(a(m))/2
        alias = alias + abs(circshift(conj(H(:,m)), aidx*N(m) ));
    end
    for aidx = 1:ceil(a(m))/2-1
        alias = alias + abs(circshift(conj(H(:,m)), -aidx*N(m) ));
    end
    H(:,m) = abs(H(:,m)).*alias*(1/a(m));
end
H = sum(H,2);
A = min(Hresp - H);
B = max(Hresp + H);






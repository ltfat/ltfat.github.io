Ls = 44100;
fs = 44100;
fmax = fs/2;
bins = 1;
bins_hi = 4;

%s = gspi;
s = wavload('kafziel.wav');
Ls = length(s);

%% Example 1 (ERBlets):
% [g,a,fc]=warpedfilters(@freqtoerb,@erbtofreq,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');
% 
% figure(1);
% c=filterbank(s,g,a);
% plotfilterbank(c,a,fc,fs,60);
% %title('ERBlet transform of the test signal','FontSize',14);
% colormap(flipud(gray))

%% Example 2 (ERBlets - 4 bins/ERB):
[g,a,fc]=warpedfilters(@freqtoerb,@erbtofreq,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(2); 
c=filterbank(s,g,a);
plotfilterbank(c,a,fc,fs,60);
%title('ERBlet transform of the test signal (4 bins/ERB)','FontSize',14);
colormap(flipud(gray))
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
set(get(gca,'ylabel'),'FontSize',12);
ylabel('Frequency (kHz)');
set(gca,'YTickLabel',[' 0';'.2';'.4';'.8';' 2';' 3';' 5';' 8';'13';'22']);
%ylim([0,150]);
colorbar off;
pos =get(gcf,'Position'); pos(3) = 1*pos(4); set(gcf,'Position',pos);
export_fig('../pics/erbletFBspec.pdf','-transparent','-painters','-p15')


% %% Example 3 (Square root warping):
 warpfun_sqrt = @(x) sign(x).*((1+abs(x)).^(1/2)-1);
 invfun_sqrt = @(x) sign(x).*((1+abs(x)).^2-1);
 [g,a,fc]=warpedfilters(warpfun_sqrt,invfun_sqrt,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');
% 
% figure(3); 
% c=filterbank(s,g,a);
% plotfilterbank(c,a,fc,fs,60);
% %title('Square root warped transform of the test signal','FontSize',14);
% colormap(flipud(gray))

%[g,a,fc]=warpedfilters(warpfun_sqrt,invfun_sqrt,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(4); 
c=filterbank(s,g,a);
plotfilterbank(c,a,fc,fs,60);
%title('Square root warped transform of the test signal','FontSize',14);
colormap(flipud(gray))
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
set(get(gca,'ylabel'),'FontSize',12);
colorbar off;
ylabel('Frequency (kHz)');
set(gca,'YTickLabel',[' 0';'.3';' 1';' 3';' 4';' 7';'10';'13';'17';'22']);
ylim([0,400]);
pos =get(gcf,'Position'); pos(3) = 1*pos(4); set(gcf,'Position',pos);
export_fig('../pics/sqrtFBspec.pdf','-transparent','-painters','-p15')

% %% Example 4 (linear warping (uniform filter bank):
 warpfun = @(x) x/100;
 invfun = @(x) 100*x;
% [g,a,fc]=warpedfilters(warpfun,invfun,fs,0,fmax,bins,Ls,'bwmul',1.5,'real','fractional');
% 
% figure(5); 
% c=filterbank(s,g,a);
% plotfilterbank(c,a,fc,fs,60);
% %title('uniform filter bank analysis of the test signal','FontSize',14);
% colormap(flipud(gray))

[g,a,fc]=warpedfilters(warpfun,invfun,fs,0,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(6); 
c=filterbank(s,g,a);
plotfilterbank(c,a,fc,fs,60);
%title('uniform filter bank analysis of the test signal','FontSize',14);
colormap(flipud(gray))
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
set(get(gca,'ylabel'),'FontSize',12);
ylabel('Frequency (kHz)');

set(gca,'YTickLabel',[' 0';' 2';' 5';' 7';'10';'12';'15';'17';'20';'22']);
%ylim([0,400]);
ylim([0,(10/22.05)*max(get(gca,'YTick'))]);
pos =get(gcf,'Position'); pos(3) = 1*pos(4); set(gcf,'Position',pos);
export_fig('../pics/uniformFBspec.pdf','-transparent','-painters','-p15')

% %% Example 4 (logarithmic (constant-Q) warping):
% warpfun_log = @(x) 10*log(x);
% invfun_log = @(x) exp(x/10);
% fmin = 50; % The logarithm's derivative 1/x tends to Inf for x towards 0
% [g,a,fc]=warpedfilters(warpfun_log,invfun_log,fs,fmin,fmax,bins,Ls,'bwmul',1.5,'real','fractional');

% figure(7); 
% c=filterbank(s,g,a);
% plotfilterbank(c,a,fc,fs,60);
% %title('constant-Q transform of the test signal','FontSize',14);
% colormap(flipud(gray))
% 
% %% Example 4 (logarithmic (constant-Q) warping - 4 bins):
 warpfun_log = @(x) 10*log(x);
 invfun_log = @(x) exp(x/10);
 fmin = 50; % The logarithm's derivative 1/x tends to Inf for x towards 0
 [g,a,fc]=warpedfilters(warpfun_log,invfun_log,fs,fmin,fmax,bins_hi,Ls,'bwmul',1.5/4,'real','fractional');

figure(8); 
c=filterbank(s,g,a);
plotfilterbank(c,a,fc,fs,60);
%title('constant-Q transform of the test signal (4 bins)','FontSize',14);
colormap(flipud(gray))
set(gca,'FontSize',10);
set(get(gca,'xlabel'),'FontSize',12);
set(get(gca,'ylabel'),'FontSize',12);
colorbar off;
ylabel('Frequency (kHz)');
set(gca,'YTickLabel',[' 0';'.1';'.2';'.3';'.7';' 1';' 3';' 5';'11';'22']);

pos =get(gcf,'Position'); pos(3) = 1*pos(4); set(gcf,'Position',pos);
export_fig('../pics/cqFBspec.pdf','-transparent','-painters','-p15')
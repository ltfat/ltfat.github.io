%RR_SIGNALS Phase recovery problem onto different signals
%
%   Reproducible research addendum for phase recovery problem
%   ---------------------------------------------------------
%   
%   A FAST GRIFFIN LIM ALGORTITHM
%
%   Paper: Perraudin Nathanael, Balazs Peter
%   
%   Demonstration matlab file:  Perraudin Nathanael
%
%   ARI -- April 2013
%   
%   ---------------------------------------------------------
%   
%   FASTER THAN FAST: ACCELERATING THE GRIFFIN-LIM ALGORITHM
%
%   Paper: Rossen Nenov, Dang-Khoa Nguyen, Balazs Peter
%   
%   Modification matlab file:  Rossen Nenov
%
%   ARI -- OCTOBER 2022
%   
%   Dependencies
%   ------------
%
%   In order to use this matlab file you need the LTFAT toolbox. You
%   can download it on https://ltfat.org/
%   
%   The problem
%   -----------
%
%   From a spectrogram S, we would like to recover the signal with the
%   closest spectrogram.
%
%   The problem could be written in the form:
%
%        minimize_x   || |Gx| - S ||_2
%
%   with 
%         - S :  The original spectrogram
%         - G :  A frame
%         - x :  The signal we would like to recover
%
%   Note that for these simulations, we know that it exist one x such that
%   GX=S. 
%
%
%   Algorithms for solving the problem
%   ----------------------------------
%
%   We will compare 5 different algorithms to solve the problem  
%
%    Griffin-Lim : Original algorithm designed by griffin and Lim
%
%    Fast Griffin-Lim : A modification of the Griffin-Lim
%
%    Accelerated Griffin-Lim : Another modification of the Griffin-Lim
%
%    Difference Map 
%
%    Relaxed Averaged Alternating Reflections 
%
%
%   Goal of these simulations
%   -------------------------
%   
%   Test the algorithm on various acoustic signals.
%
%   We use all the test signal from the toolbox LTFAT. For each of them the
%   Foward-PBL is better than the Griffin-Lim.
%
%
%   Results
%   -------
%
%   Figure 1: Phase recovery problem on 'gspi'
%
%       
%
%   Figure 2: Phase recovery problem on 'traindoppler'
%
%       
%
%   Figure 3: Phase recovery problem on 'cocktailparty'
%
%       
%
%   Figure 4: Phase recovery problem on 'linus'
%
%       
%
%   Figure 5: Phase recovery problem on 'bat'
%
%       
%
%   Figure 6: Phase recovery problem on 'greasy'
%
%
%   Url of the original FILE: https://epfl-lts2.github.io/rrp-html/fgla/main_flga.html
%   Url of the modified FILE: http://bitly.ws/vPr6

% Copyright (C) 2012-2013 Nathanael Perraudin.
% Modified by Rossen Nenov (2023)
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Modification:
% 1. Addition of three new implementation methods;
% 2. Adjusted input methods accordingly


% ----------------------------------------------------------------------- %
% Author: Nathanael Perraudin
% April 2013
% FLAME project, ARI (Acoustic research institute), Vienna
% ----------------------------------------------------------------------- %
% Author of the modifications: Rossen Nenov
% March 2023
% NoMASP project, ARI (Acoustic research institute), Vienna
% ----------------------------------------------------------------------- %
%% Initialisation
clear;
close all;

% The LTFAT toolbox is required for this demonstration file
ltfatstart % if this line is a problem, add to path the LTFAT toolbox.
addpath('./commands')
%% General Parameters
                                
% Frame parameter
a=32;                               % Size of the shift in time
M=256;                              % Number of frequencies     
window_type='gauss';

real_signal=1;                      % we work with real signal only
type_multiplier='full';


% algorithm parameter

solving_method={'AGLA','GLA','FGLA','DM','RAAR'};    %Methods: GLA,FLGA,AGLA,DM,RAAR 

param.maxit=10^3;                  % Maximal number of iteration

param.verbose=1;                    % Display parameter
         

% Starting point
param.zero_phase=1;                 % Starting with a zero phase
param.random_phase=0;               % Starting with a random phase
param.PGHI_init=0;                  % Initializing with PGHI 

param.tol=0;                        % Tolerance to stop iterating 


% Input Starting Parameters 
% Input List for running one method with different variations of parameters

alpha=[1];                         % Parameter for FGLA

alpha2=[1.05];                       % Parameters for AGLA
beta=[1.35];
gamma=[1.25];

rho=0.8;                            % Parameter for DM

lambda=0.9;                         % Parameter for RAAR

% Path for saving the figures
paramplot.check = 1; %If you want to see the plots
paramplot.pathfigure='comparaison/';
paramplot.legendlocation='NorthWest';
paramplot.save = 0;
paramplot.position=[100 100 300 225];

%% Lauch different simulations with different signals

param.own_audio = 0; % =1 If you want to input other audio files not included in the LTFAT
sound_names={'bat','greasy','linus','gspi','cocktailparty','traindoppler'}; 

for kk=1:length(sound_names)
    main_flga(a,M,window_type,sound_names{kk},real_signal,type_multiplier,...
             solving_method,param,paramplot,alpha,alpha2,beta,gamma,rho,lambda)
end 



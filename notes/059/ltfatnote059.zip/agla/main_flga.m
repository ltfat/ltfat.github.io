function fsnr=main_flga(a,M,window_type,sound_name,real_signal,type_multiplier,...
                                                solving_method,param,paramplot,alpha,alpha2,beta,gamma,rho,lambda)
%MAIN main function    
%   This function creates and solves the problem.
%
%   See the code for details.
%
%   Url of the original FILE: https://epfl-lts2.github.io/rrp-html/fgla/main_flga.html
%   Url of the modified FILE: http://bitly.ws/vPr6

% Copyright (C) 2012-2013 Nathanael Perraudin.
% Modified by Rossen Nenov (2023)
%
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Modification:
% 1. Addition of three new implementation methods;
% 2. Adjusted input methods accordingly


%% Load the sound

if param.own_audio == 1
    [s,Fs]=audioread(sound_name); 
else 
    [s,Fs]=load_sound(sound_name);
end 

s=check_sound(s);
Ls=length(s);                       % Length of the signal
L=dgtlength(Ls,a,M);                % Length of the transform
N= L/a;                             % Number of time shifts




%% Creation of the frame
fprintf('-- Create the windows and the operators... ');
g = create_window(a,M,L ,window_type );
    
[~,GB]= gabframebounds(g,a,M);
if real_signal
    G = @(x) dgtreal(x,g,a,M);
    Gt= @(x) idgtreal(x,g,a,M)/GB;
else
    G = @(x) dgt(x,g,a,M);
    Gt= @(x) idgt(x,g,a,M)/GB;
end

fprintf(' Done\n');


%% Creation of the Spectrogram Multiplier
fprintf('-- Create the spectrogram muliplier... ');
A=create_spectrogram_multiplier( M,N,type_multiplier,real_signal );
fprintf(' Done\n');

%% Starting point
S=G(s).*A; % Simple application of the spectrogram multiplier

%% Apply the spectrogram muliplier and reconstruction
nsim=0;
% Launch all the simulation with all methods and alpha possible.

for ii=1:length(solving_method)
    if strcmp(solving_method{ii},'FGLA')
        method=solving_method{ii};
        for jj=1:length(alpha)
            fprintf(strcat('-- Reconstruction method: ',solving_method{ii}, ...
             '  with alpha = %g\n',alpha(jj)));
            
            nsim=nsim+1;

            [ap,Ap,info_reconstruct] = spectrogram_reconstruction(sound_name,S,G,Gt,...
                                     method,alpha(jj), param, alpha2, beta, gamma, rho, lambda);          

            fsnr=ssnr(S, Ap);

            
            R(nsim,:)=info_reconstruct.ssnr; %#ok<AGROW>
            fprintf('   * The obtained ssnr is: %g\n', fsnr);
            fprintf('-- Reconstruction done \n');
        end
    elseif strcmp(solving_method{ii},'DM')
        method=solving_method{ii};
        for jj=1:length(rho)
            fprintf(strcat('-- Reconstruction method: ',solving_method{ii}, ...
             '  with rho = %g\n',rho(jj)));

            nsim=nsim+1;

            [ap,Ap,info_reconstruct] = spectrogram_reconstruction(sound_name,S,G,Gt,...
                                     method,alpha, param, alpha2, beta, gamma, rho(jj), lambda);

            fsnr=ssnr(S, Ap);

            R(nsim,:)=info_reconstruct.ssnr; %#ok<AGROW>
            fprintf('   * The obtained ssnr is: %g\n', fsnr);
            fprintf('-- Reconstruction done \n');
        end
    elseif strcmp(solving_method{ii},'RAAR')
        method=solving_method{ii};
        for jj=1:length(lambda)
            fprintf(strcat('-- Reconstruction method: ',solving_method{ii}, ...
             '  with lambda = %g\n',lambda(jj)));

            nsim=nsim+1;

            [ap,Ap,info_reconstruct] = spectrogram_reconstruction(sound_name,S,G,Gt,...
                                     method,alpha, param, alpha2, beta, gamma, rho, lambda(jj));
            
            
            fsnr=ssnr(S, Ap);

            R(nsim,:)=info_reconstruct.ssnr; %#ok<AGROW>
            fprintf('   * The obtained ssnr is: %g\n', fsnr);
            fprintf('-- Reconstruction done \n');
        end
        
    elseif strcmp(solving_method{ii},'AGLA')
        method=solving_method{ii};
        nAGLA=0;
        for jj=1:length(alpha2)
            for kk=1:length(beta)
                for ll=1:length(gamma)
                    fprintf(strcat('-- Reconstruction method: ',solving_method{ii}, ...
                    '  with alpha = %g\n',num2str(alpha2(jj)),' beta = %g\n',num2str(beta(kk)),' gamma = %g\n', num2str(gamma(ll))));

                    nsim=nsim+1;
                    
                 
                    [ap,Ap,info_reconstruct] = spectrogram_reconstruction(sound_name,S,G,Gt,...
                                     method,alpha, param, alpha2(jj), beta(kk), gamma(ll), rho, lambda);                   
                    
                    fsnr=ssnr(S, Ap);
                    
                    
                    
                    R(nsim,:)=info_reconstruct.ssnr; %#ok<AGROW>
                    fprintf('   * The obtained ssnr is: %g\n', fsnr);
                    fprintf('-- Reconstruction done \n');
                end
            end
        end        
        
    else
        fprintf(strcat('-- Reconstruction method: ',solving_method{ii},'\n'));
        [ap,Ap,info_reconstruct] = spectrogram_reconstruction(sound_name, S,G,Gt, ...
                            solving_method(ii),alpha(1),param); %#ok<ASGLU>
        fsnr=ssnr(S, Ap);
        nsim=nsim+1;
        
        
        R(nsim,:)=info_reconstruct.ssnr; %#ok<AGROW>
        fprintf('   * The obtained ssnr is: %g\n', fsnr);
        fprintf('-- Reconstruction done \n');
    end

end


%% Display the result

fprintf('-- Display the results... ');

nsim=0;
% arrange the name
for ii=1:length(solving_method)
    if strcmp(solving_method(ii),'FGLA')
        for jj=1:length(alpha)
            nsim=nsim+1;
            text_fig(nsim)={strcat('FGLA: alpha=',num2str(alpha(jj)))}; 
        end
        
    elseif strcmp(solving_method(ii),'DM')
        for jj=1:length(rho)
            nsim=nsim+1;
            text_fig(nsim)={strcat('DM: rho=',num2str(rho(jj)))}; 
        end
        
    elseif strcmp(solving_method(ii),'RAAR')
        for jj=1:length(lambda)
            nsim=nsim+1;
            text_fig(nsim)={strcat('RAAR: lambda=',num2str(lambda(jj)))}; 
        end
        
    elseif strcmp(solving_method(ii),'AGLA')
        for jj=1:length(alpha2)
            for kk=1:length(beta)
                for ll=1:length(gamma)
                    nsim=nsim+1;
                    text_fig(nsim)={strcat('AGLA: alpha=',num2str(alpha2(jj)),' beta=',num2str(beta(kk)),' gamma=', num2str(gamma(ll)) )}; 
                end
            end
        end
    else
        nsim=nsim+1;
        text_fig(nsim)=solving_method(ii); 
    end
end

if paramplot.check==1
    cfig=figure;

    set(cfig, 'Position', paramplot.position)
    set(gcf,'PaperPositionMode','auto')
    iterations=1:param(1).maxit;
    semilogx(iterations,R);
    title(sound_name,'FontSize',14);
    legend(text_fig,'Location',paramplot.legendlocation);
    xlabel('Iterations ','FontSize',12);
    ylabel('ssnr (dB)','FontSize',12);
    drawnow;
    fprintf(' Done\n');
    if paramplot.save
        filename=strcat(paramplot.pathfigure,num2str(length(alpha)),'_', ...
                    type_multiplier,'_',sound_name,'_',window_type);
        print('-dpng','-zbuffer','-r300',[filename,'.png']);
        hgsave([filename,'.fig'])
    end

end


end


function [ f,Sp,info_reconstruct] = spectrogram_reconstruction(sound_name,S,G,Gt,...
                                     method,alpha, param, alpha2, beta, gamma, rho, lambda)
%SPECTROGRAM_RECONSTRUCTION Reconstruct a signal from a spectrogram
%   Usage: sp = spectrogram_reconstruction(S,A,G,Gt, method, param);
%          [ sp,Sp,info_reconstruct] = spectrogram_reconstruction(S,A,G,... 
%                                       Gt, method, param);
%
%   Input parameters:
%         S     : Spectrogram
%         G     : Analysis operator
%         Gt    : Dual sythesis operator
%         method: Reconstruction method
%         param : Structure of optional parameter
%   
%   Output parameters:
%         f     : reconstructed signal.
%         Sp    : Projected reconstructed signal
%         info_reconstruct: information for the reconstruction
%
%   This function reconstruct a signal f from its spectrogram S. 
%   
%             S = |G f|
%
%      math   S = |G f|    
%
%   If S has a phase, it will be used as starting phase for the
%   algorithm.
%
%   method define the algorithm used to solve the problem. 
%   
%    'GLA'             : Griffin-lim algorithm
%    'FGLA'            : Fast Griffin-Lim algorithm
%    'AGLA'            : Fast Griffin-Lim algorithm
%    'RAAR'            : Relaxed Averaged Alternating Reflections 
%    'DM'              : Difference Map
%
%   param is an optional structure containing optional parameter:
%
%    param.maxit     : Maximum number of iteration (default 100)
%    param.tol       : Tolerance for convergence (default 0.001)
%    param.verbose   : Display parameter (0 no log, 1 main steps, 2
%                         display figure) (default 0)
%    alpha     : Parameter for Forward-PBL and Backwar-PBL.
%                         This must be between 0 and 1 (Default 0.99)
%    param.zero_phase*: Starting the algorithm with a zero phase 
%                         (default 0)
%    param.rand_phase*: Starting the algorithm with a random phase 
%                         (default 0)
%
%   info_reconstruct is a structure containing convergence information.
%
%    info_reconstruct.stopping_criterion : stopping criterion
%    info_reconstruct.n_iter             : final number of iteration
%    info_reconstruct.n_cputime          : cpu time of computation
%                                             This algo should be twice
%                                             faster.
%    info_reconstruct.tol                : final relative difference
%                                             between two iterations
%    info_reconstruct.ssnr               : ssnr each iteration
%
%
%   Url of the original FILE: https://epfl-lts2.github.io/rrp-html/fgla/main_flga.html
%   Url of the modified FILE: http://bitly.ws/vPr6

% Copyright (C) 2012-2013 Nathanael Perraudin.
% Modified by Rossen Nenov (2023)
%
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Modification:
% 1. Addition of three new implementation methods;
% 2. Adjusted input methods accordingly



% Optional input arguments
if nargin<6, param=struct; end
if ~isfield(param, 'maxit'), param.maxit = 100; end
if ~isfield(param, 'tol'), param.tol = 0.001; end
if ~isfield(param, 'verbose'), param.verbose = 0; end
if ~isfield(param, 'zero_phase'), param.zero_phase = 0; end
if ~isfield(param, 'random_phase'), param.random_phase = 0; end
if nargin<5, alpha=0.99; end

if nargin<4
    method = 'FGLA';
end


% the initial phase is not known
if param.zero_phase
   S=abs(S);
end


% the initial phase is random
if param.random_phase
   S=abs(S).*exp(1i*2*pi*rand(size(S))); 
end



% Define the projections
objS=abs(S);    
proj_c1=@(x) G(Gt(x));
proj_c2=@(x) objS.*exp(1i*angle(x));
R_1=@(x) 2*proj_c1(x)-x;
R_2=@(x) 2*proj_c2(x)-x;


% Start the counter. However, the code is not optimized due to the
% computation of the error every iteration. It could be twice faster
tic;

if param.PGHI_init==1
    S=constructphasereal(objS,'gauss',32,256);
end


% Initialisation
Sp=S;

% Structure to store informations    
info_reconstruct=struct;
info_reconstruct.ssnr=zeros(param.maxit,1);

convergence_rate=struct;
convergence_rate.quotients=zeros(param.maxit,1);
convergence_rate.log_fun_it=zeros(param.maxit,1);
ii=0;
% Griffin method
if strcmp(method,'GLA')
    if param.verbose>0
        fprintf('   * Selected method: Griffin-Lim algorithm \n');
    end

    % Loop
    while 1
        % Update rule   
        ii=ii+1;                    % update current iteration number
        Sp_old=Sp;                  % save the previous result
        Sp=proj_c1(proj_c2(Sp));    % perform the algorithm
        Tp=Sp;
        Tp_old=Sp_old;

        % test convergence
        [stop,info_reconstruct]=test_convergence(Sp,Sp_old,Tp,Tp_old,alpha,objS,ii, ...
                        info_reconstruct, proj_c1,param );
        if stop
            break;   
        end  

    end
    


    

    
elseif strcmp(method,'FGLA')
    fprintf('   * Selected method: fast Griffin-Lim algorithm\n');
    
    % Initialisation 
    Tp=proj_c1(proj_c2(Sp));
    
    while 1
        % Update rule
        ii=ii+1;                   % update current iteration number
        
        Tp_old=Tp;                  % save the previous result
        Sp_old=Sp; 
        Sp=proj_c1(proj_c2(Tp));    % perform the algorithm
        Tp=Sp+alpha*(Sp-Sp_old);
      
            
                 
        % test convergence
        [stop,info_reconstruct]=test_convergence(Sp,Sp_old,Tp,Tp_old,alpha,objS,ii, ...
                        info_reconstruct, proj_c1,param );
                    
        if stop
            break;   
        end  
        
        
    end

    

     
 elseif strcmp(method,'AGLA')
     fprintf('   * Selected method: Accelerated Griffin-Lim\n');
     
     % Initialisation 
     Cp=proj_c1(proj_c2(Sp));
     Dp=Cp;
     Tp=Sp;

     while 1
         % Update rule
        ii=ii+1;                    % update current iteration number
        
        Tp_old=Tp;                  % save the previous result
        Sp_old=Sp;
        Sp=proj_c1( proj_c2( Cp ));
        Tp = (1-gamma)*Dp + gamma*Sp; %perform algorithm
        Cp = Tp + alpha2*(Tp - Tp_old);
        Dp = Tp + beta*(Tp - Tp_old);
        

        

        % test convergence
        [stop,info_reconstruct]=test_convergence(Sp,Sp_old,Tp,Tp_old,alpha,objS,ii, ...
                        info_reconstruct, proj_c1,param );
                    
         if stop
             break;   
         end  
 
     end     
     

     
     
     
     elseif strcmp(method,'RAAR')
     fprintf('   * Selected method: Relaxed Averaged Alternating Reflections\n');

      
     while 1
         % Update rule
        ii=ii+1;                    % update current iteration number
        
        Sp_old=Sp;
        Sp=lambda*0.5*(R_2(R_1(Sp))+Sp)+(1-lambda)*proj_c2(Sp);
        
        Tp_old=Sp_old;
        Tp=Sp;
        % test convergence
        [stop,info_reconstruct]=test_convergence(Sp,Sp_old,Tp,Tp_old,alpha,objS,ii, ...
                        info_reconstruct, proj_c1,param );                   
         if stop
             break;   
         end  
 
        
     end 
     
     
  elseif strcmp(method,'DM')
     fprintf('   * Selected method: Difference Map\n');
     

     while 1
         % Update rule
        ii=ii+1;                    % update current iteration number
        
        Sp_old=Sp;
        f_2=proj_c2(Sp)+(proj_c2(Sp)-Sp)/rho;
        f_1=proj_c1(Sp)-(proj_c1(Sp)-Sp)/rho;
        Sp=Sp_old+rho*(proj_c1(f_2)-proj_c2(f_1));
        
        Tp_old=Sp_old;
        Tp=Sp;
        
        % test convergence
        [stop,info_reconstruct]=test_convergence(Sp,Sp_old,Tp,Tp_old,alpha,objS,ii, ...
                        info_reconstruct, proj_c1,param );                  
         if stop
             break;   
         end
     end
 
  
   
    
    else 
   error('Unknown reconstruction method!');
    end


f=Gt(Sp);
Sp=G(f);





end



function  [stop,info_reconstruct]=test_convergence(Sp,Sp_old,Tp,Tp_old,alpha,objS,ii,info_reconstruct,proj_c1,param)   
    
    tol_obs=sum(abs(Sp(:)-Sp_old(:)))/sum(abs(Sp(:)));
    ssnrm=ssnr(objS,proj_c1(Sp));
    info_reconstruct.ssnr(ii)=ssnrm;
    
    % test if the algorithm has converged
    stop=0;
    if tol_obs<param.tol
        if param.verbose>0
            fprintf('   * Stopping criterion: epsilon with: tol_obs = %g \n',tol_obs);
        end
        info_reconstruct.stopping_criterion='epsilon';
        stop=1;
    elseif ii==param.maxit
        if param.verbose>0
            fprintf('   * Stopping criterion: max iteration with: tol_obs = %g \n',tol_obs);
        end
        stop=1;
    end
    
    % if we have converged
    if stop
        info_reconstruct.stopping_criterion='max_it';
        info_reconstruct.n_iter=ii;
        info_reconstruct.cputime=toc;
        info_reconstruct.tol=tol_obs; 
    end
    
    
    % Plot evolution on image
    if param.verbose>1
       figure(25)
       subplot(221)
       imagesc(abs(Sp));
       axis('xy');
       title('Modulus')
       subplot(222)
       imagesc(angle(Sp));
       title('Phase')
       axis('xy');
       subplot(223)
       imagesc(abs(Sp)-abs(Sp_old));
       title('Difference Sp Sp-old');
       axis('xy');
%        colorbar;
       drawnow;
    end
end




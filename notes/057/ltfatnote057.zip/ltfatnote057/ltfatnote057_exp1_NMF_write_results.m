% This file reproduces the plots and audio signals presented with the 
% Itakura-Saito NMF experiment shown in the paper 'Invertible grid-based 
% sampling of wavelet transforms for audio processing' by N. Holighaus, 
% G. Koliander, C. Hollomey, and F. Pillichshammer. 

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the 
% Free Software Foundation, either version 3 of the License, or (at your 
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but 
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
% for more details.
%
% You should have received a copy of the GNU General Public License along 
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

load('./exp1_nmf/long_is-nmf_a450/results.mat');

% experimental parameters
K = 10;
M = 448;
Ls = 1191735;
CauchyAlpha = 450;
chain = 'is-nmf';
%% Display results
figure(345);
for k=1:K
    subplot(K,2,2*k-1);
    tmp = log10(W(:,k)+eps);
    plot(tmp,'k','LineWidth',1);
    %axis([1 M min(tmp(:)) max(tmp(:))])
    axis([1 M max(tmp(:))-5 max(tmp(:))])
    
    subplot(K,2,2*k);
    plot(c(k,:),'k','LineWidth',1);
    up = max(abs(c(:)));
    do = -up;
    axis([1 Ls do up])
end

for k=1:K-1
    subplot(K,2,2*k-1);
    set(gca,'XTickLabel',[]);
    subplot(K,2,2*k);
    set(gca,'XTickLabel',[]);
end

for k=1:K
    subplot(K,2,2*k-1);
    ylabel(['K = ' int2str(k)])
end

subplot(K,2,1); title('W')
subplot(K,2,2); title('Temporal components')

%% Write processed audio signals
% Write denoised signal
audiowrite(['./exp1_nmf/long_is-nmf_a',num2str(CauchyAlpha),'/',chain '-denoised.wav'],sum(c(1:end-2,:)),fs);
% Write lead part
audiowrite(['./exp1_nmf/long_is-nmf_a',num2str(CauchyAlpha),'/',chain '-lead.wav'],sum(c([1:3,5],:)),fs);
% Write accompaniment part
audiowrite(['./exp1_nmf/long_is-nmf_a',num2str(CauchyAlpha),'/',chain '-accompaniment.wav'],sum(c([4,6:8],:)),fs);

% Write upmixed signal
upmix = [.4*sum(c([1:3,5],:))+1.2*sum(c([4,6:8],:));1.2*sum(c([1:3,5],:))+.4*sum(c([4,6:8],:))].';
audiowrite(['./exp1_nmf/long_is-nmf_a',num2str(CauchyAlpha),'/',chain '-upmix.wav'],upmix,fs);


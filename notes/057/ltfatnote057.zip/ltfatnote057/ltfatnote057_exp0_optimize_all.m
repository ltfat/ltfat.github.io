% This file reproduces the numerical frame bound study (Figure 4) in the 
% paper 'Invertible grid-based sampling of wavelet transforms for audio 
% processing' by N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer.

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the 
% Free Software Foundation, either version 3 of the License, or (at your 
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but 
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
% for more details.
%
% You should have received a copy of the GNU General Public License along 
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

%% Perform main frame bound optimization
addpath('./exp0')
% Define conditions
redundancies = [1.2,2,4,8];
wavelets = cell(7,1);
wavelets{1} = {'cauchy',100};
wavelets{2} = {'cauchy',300};
wavelets{3} = {'cauchy',900};
wavelets{4} = {'cauchy',2700};
wavelets{5} = {'cplxsp',4,3};
wavelets{6} = {'cplxsp',4,6};
wavelets{7} = {'cplxsp',4,10};

% Initialize tensors for storing results
results = zeros(numel(wavelets),numel(redundancies),3);
all_results = cell(numel(wavelets),numel(redundancies));
num_lps = zeros(numel(wavelets),numel(redundancies));

% Optimize frame bounds for golden Kronecker sequence
for kk = 1:numel(wavelets)
    for jj = 1:numel(redundancies)
        [results(kk,jj,:),all_results{kk,jj},num_lps(kk,jj)] = ltfatnote057_exp0_optimize_single_condition(wavelets{kk},redundancies(jj),2048,1);
    end
end

% Store results. Make sure this folder exists
save('./exp0/kronecker_results.mat','results','all_results','num_lps');

% Initialize tensors for storing results
results = zeros(numel(wavelets),numel(redundancies),3);
all_results = cell(numel(wavelets),numel(redundancies));
num_lps = zeros(numel(wavelets),numel(redundancies));

% Optimize frame bounds for golden Kronecker sequence
for kk = 1:numel(wavelets)
    for jj = 1:numel(redundancies)
        [results(kk,jj,:),all_results{kk,jj},num_lps(kk,jj)] = ltfatnote057_exp0_optimize_single_condition_diginet(wavelets{kk},redundancies(jj),2048,1);
    end
end

% Store results. Make sure this folder exists
save('./exp0/diginet_results.mat','results','all_results','num_lps');

%% Reproduce pre-test for a single condition for plotting
Ls = 2^14; redundancy = 8;
wvlt = {'cauchy',2700};
% % Type 0, alpha*k sequence
alpha = 1-2/(1+sqrt(5)); % 1-1/(goldenratio)
delays = @(n,a) a*(mod(n*alpha+.5,1)-.5);

%Set maximum center frequency to Nyquist
max_freqDiv10 = 10;  % 10=Nyquist, By default, the reference scale for freqwavelet has center frequency 0.1
M = 1024;
freq_step = max_freqDiv10/M; % Frequency step

% Determine lowest optimal starting index
pretest_results = inf*ones(30-1,1);
for jj = 2:30
    start_index = jj;
    min_freqDiv10 = freq_step*start_index;
    scales = 1./linspace(min_freqDiv10,max_freqDiv10,M-start_index+1);
    [g, a,fc,L,info] = waveletfilters(Ls,scales,wvlt,'uniform','repeat','energy', 'delay',delays, 'redtar', redundancy);
    [A,B] = filterbankrealbounds(g,a,L);
    pretest_results(jj-1) = B/A;
    fprintf('start_index=%d, B/A=%.2f \n', jj, B/A);
end
pretest_results(pretest_results < 0) = Inf; % Correct for possible numerical problems

% Store results. Make sure this folder exists
save('./exp0/Pretest_plot.mat','pretest_results');

% Plot pretest results
figure(1);
subplot(122);
semilogy((5:30),pretest_results(4:end))
title('Dependence of frame bound ratio on M_{lp}')
ylabel('Frame bound ratio (R_{FB})')
xlabel('Number of lowpass filters (M_{lp})')

%% Plot results for optimization on coarse grid of channel numbers
coarse_scales = [2.^(4:8),256+128,512,512+128,512+256,1024,1024+256,1024+512,2048];
load('./exp0/kronecker_results.mat')
scales = cell(7,1);
results = all_results(:,2);
figure(1);
subplot(121);
for kk = 1:7
    num_scales = numel(results{kk});
    scales{kk} = coarse_scales(end-num_scales+1:end);
    plot(scales{kk},results{kk},'LineWidth',2)
    hold on
end
axis([2^7 2048 2.2 4.4]);
xlabel('Number of channels (M)');
ylabel('Frame bound ratio (R_{FB})');
title('Dependence of frame bound ratio on M')
legend('Cauchy \alpha=100','Cauchy \alpha=300','Cauchy \alpha=900','Cauchy \alpha=2700',...
    'B-Spline \xi_{fm}=3','B-Spline \xi_{fm}=6','B-Spline \xi_{fm}=10','Location','southeast')
hold off

% %% Compute Gabor frame bounds for comparison
% % Although the frame bounds obtained above are pretty good, Gabor
% % frame bounds are still notably better. 
% 
% L=2^12*5*3; %Fix some sufficiently long signal length with nice divisors
% 
% % Gabor parameters, the two high redundancies are tight, i.e., B/A = 1
% a12 = 320; M12 = 384; % R=1.2   
% a20 = 256; M20 = 512; % R=2
% a40 = 256; M40 = 1024; % R=4
% a80 = 128; M80 = 1024; % R=8
% 
% [A,B]=gabframebounds({'gauss',a12*M12/L},a12,M12,L);
% disp(['Optimized Gabor frame bound at red=',num2str(M12/a12,'%.1f'),' equals ',num2str(B/A,'%.2f')]);
% 
% [A,B]=gabframebounds({'gauss',a20*M20/L},a20,M20,L);
% disp(['Optimized Gabor frame bound at red=',num2str(M20/a20,'%d'),' equals ',num2str(B/A,'%.2f')]);
% 
% [A,B]=gabframebounds({'gauss',a40*M40/L},a40,M40,L);
% disp(['Optimized Gabor frame bound at red=',num2str(M40/a40,'%d'),' equals ',num2str(B/A,'%.2f')]);
% 
% [A,B]=gabframebounds({'gauss',a80*M80/L},a80,M80,L);
% disp(['Optimized Gabor frame bound at red=',num2str(M80/a80,'%d'),' equals ',num2str(B/A,'%.2f')]);
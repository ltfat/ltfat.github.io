function [final_result,coarse_results,num_lps] = ltfatnote057_exp0_optimize_single_condition(wvlt,redundancy,maxfilts,verbose)
% For a fixed mother wavelet and redundancy, this file reproduces the numerical 
% frame bound optimization procedure used in the paper 'Invertible grid-based 
% sampling of wavelet transforms for audio processing' by N. Holighaus, 
% G. Koliander, C. Hollomey, and F. Pillichshammer. In this file, the golden 
% Kronecker sequence is used.

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the 
% Free Software Foundation, either version 3 of the License, or (at your 
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but 
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
% for more details.
%
% You should have received a copy of the GNU General Public License along 
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

Ls = 2^14;

% Golden Kronecker sequence
alpha = 1-2/(1+sqrt(5)); % 1-1/(goldenratio)
delays = @(n,a) a*(mod(n*alpha+.5,1)-.5);

%Set maximum center frequency to Nyquist
max_freqDiv10 = 10;  % 10=Nyquist, By default, the reference scale for freqwavelet has center frequency 0.1

%% Pretest - Determine appropriate number of lowpass filters
M = 1024;
freq_step = max_freqDiv10/M; % Frequency step
max_lps = floor(M/25); % Highest LP filter centered below fs/100

pretest_results = inf*ones(max_lps-1,1);
for jj = 2:max_lps
    start_index = jj;
    min_freqDiv10 = freq_step*start_index;
    scales = 1./linspace(min_freqDiv10,max_freqDiv10,M-start_index+1);
    [g, a,fc,L,info] = waveletfilters(Ls,scales,wvlt,'uniform','repeat','energy', 'delay',delays, 'redtar', redundancy);
    [A,B] = filterbankrealbounds(g,a,L);
    clear g a fc L info
    pretest_results(jj-1) = B/A;
    fprintf('start_index=%d, B/A=%.2f \n', jj, B/A);
    if jj>2 && B/A < 30 && B/A>0.99*pretest_results(jj-2)
        break
    end
end
pretest_results(pretest_results < 0) = Inf; 
opt = min(pretest_results);
num_lps = find((pretest_results <= 1.02*opt),1,'first')+1;
if verbose
    disp(['Optimal number of lowpass: ',num2str(num_lps)]);
end

%% Full test
start_index = num_lps;
coarse_scales = [2.^(4:8),256+128,512,512+128,512+256,1024,1024+256,1024+512,2048];
coarse_scales = coarse_scales(coarse_scales <= maxfilts);

scales_admissible = [num_lps*50,coarse_scales(coarse_scales > num_lps*50)];

coarse_results = Inf*ones(numel(scales_admissible),1);
for kk = 1:numel(scales_admissible)
    M = scales_admissible(kk);
    freq_step = max_freqDiv10/M;
    if verbose
        disp(['Number of scales: ',num2str(M)]);
    end
    min_freqDiv10 = freq_step*start_index;
    scales = 1./linspace(min_freqDiv10,max_freqDiv10,M-start_index+1);
    
    [g, a,fc,L,info] = waveletfilters(Ls,scales,wvlt,'uniform','repeat','energy', 'delay',delays, 'redtar', redundancy);
    [A,B] = filterbankrealbounds(g,a,L);
    clear g a fc L info
    coarse_results(kk) = B/A;
end

%% Fine tuning
disp('');
disp('Starting fine tuning');
disp('');
coarse_results(coarse_results < 0) = Inf;
[~,min_idx] = min(coarse_results);

curr_min = coarse_results(min_idx);

if min_idx == 1 && numel(coarse_results) > 1
    fine_scales = [num_lps*50,scales_admissible(1:2)];
    curr_results = [Inf;coarse_results(1:2)];
elseif min_idx == 1 && numel(coarse_results) == 1
    fine_scales = [num_lps*50,scales_admissible];
    curr_results = [Inf;coarse_results];
elseif min_idx == numel(coarse_results)
    fine_scales = [scales_admissible(end-1:end),scales_admissible(end)];
    curr_results = [coarse_results(end-1:end),coarse_results(end)];
else
    fine_scales = scales_admissible(min_idx-1:min_idx+1);
    curr_results = coarse_results(min_idx-1:min_idx+1);
end

while max(diff(fine_scales))>1
    new_scales = round([fine_scales(1)+fine_scales(2),fine_scales(2)+fine_scales(3)]/2);
    new_results = Inf*ones(2,1);
    for kk = 1:2
        M = new_scales(kk);
        freq_step = max_freqDiv10/M;
        if verbose
            disp(['Number of scales (fine): ',num2str(M)]);
        end
        min_freqDiv10 = freq_step*start_index;
        scales = 1./linspace(min_freqDiv10,max_freqDiv10,M-start_index+1);
        [g, a,fc,L,info] = waveletfilters(Ls,scales,wvlt,'uniform','repeat','energy', 'delay',delays, 'redtar', redundancy);
        [A,B] = filterbankrealbounds(g,a,L);
        clear g a fc L info
        if verbose > 1
            disp(['Frame bound ratio: ',num2str(B/A)]);
        end
        new_results(kk) = B/A;
    end
    if new_results(1) < curr_min
        fine_scales = [fine_scales(1),new_scales(1),fine_scales(2)];
        curr_min = new_results(1);
        curr_results = [curr_results(1),new_results(1),curr_results(2)];
    elseif new_results(2) < curr_min
        fine_scales = [fine_scales(2),new_scales(2),fine_scales(3)];
        curr_min = new_results(2);
        curr_results = [curr_results(2),new_results(2),curr_results(3)];
    else 
        fine_scales = [new_scales(1),fine_scales(2),new_scales(2)];
        curr_results = [new_results(1),curr_results(2),new_results(2)];
    end    
end
        
final_result = [curr_min;fine_scales(2);num_lps];
if verbose
    fprintf('B/A=%.2f achieved for start_index=%d, M=%d \n', final_result(1), final_result(2), final_result(3));
end
        

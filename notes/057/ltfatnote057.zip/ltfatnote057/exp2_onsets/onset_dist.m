% This file reproduces the numerical frame bound study in the paper 'Invertible
% grid-based sampling of wavelet transforms for audio processing' by
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer.

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible
% grid-based sampling of wavelet transforms for audio processing' by
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the
% Free Software Foundation, either version 3 of the License, or (at your
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
% for more details.
%
% You should have received a copy of the GNU General Public License along
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

function [P,R,F] = onset_dist(est_onset,gt_onset,tol)

if nargin ~= 3
    tol = 0.05;
end

N = length(gt_onset);
Ocd = 0;  %correct detections
Ofp = 0;  %false positives
Ofn = 0;  %false negatives

ii=1;
while ii<N+1
    if length(est_onset)==0
      Ofn = Ofn+N-ii+1;
      break;
    end
    if est_onset(1)<(gt_onset(ii)-tol)
      Ofp = Ofp+1;
      est_onset = est_onset(2:end);
      ii=ii-1;
    elseif est_onset(1)>(gt_onset(ii)+tol)
      Ofn=Ofn+1;
    else
      Ocd=Ocd+1;
      est_onset = est_onset(2:end);
    end
    ii=ii+1;
end;



P = Ocd / (Ocd + Ofp);
R = Ocd / (Ocd + Ofn);
F = 2*P*R/(P+R);

% This file reproduces the numerical frame bound study in the paper 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer.

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the 
% Free Software Foundation, either version 3 of the License, or (at your 
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but 
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
% for more details.
%
% You should have received a copy of the GNU General Public License along 
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

%% Use data from
% https://grfia.dlsi.ua.es/cm/projects/prosemus/database.php



%% Prepare to load test signals

path = 'input_onset/'; % Place your test signal wav files here
listing = dir([path,'*.wav']);
allwavsCell = arrayfun(@(wav) fullfile(path,wav.name),listing,'UniformOutput',0);

path_annot = 'ground-truth_onset/'; % Place your annotations here
listing_annot = dir([path_annot,'*.txt']);
allannotCell = arrayfun(@(txt) fullfile(path_annot,txt.name),listing_annot,'UniformOutput',0);


% Golden Kronecker sequence
alpha = 1-2/(1+sqrt(5)); % 1-1/(goldenratio)
delays = @(n,a) a*(mod(n*alpha+.5,1)-.5);

%Set maximum center frequency to Nyquist
max_freqDiv10 = 10;  % 10=Nyquist, By default, the reference scale for freqwavelet has center frequency 0.1

%Set peak-picking parameters
med_wlen = 21; %moving window length for median calculation
th_fac_min = 1.0; %factor on moving median
th_fac_max = 2.0;

%Specify signal
% Select file1 and load
ii=1;
wavfile1 = allwavsCell{ii};
[~,filename1,ext1] = fileparts(wavfile1);
[f,fs] = audioread(wavfile1);
%[f,fs] = gspi;
Ls = length(f);

%Specify wavelet filterbank
start_index = 20;
M = 1020;
redundancy = 4;
cauch_alpha = 2700;
freq_step = max_freqDiv10/M;
min_freqDiv10 = freq_step*start_index;
scales = 1./linspace(min_freqDiv10,max_freqDiv10,M-start_index+1);
wvlt = {'cauchy',cauch_alpha};
[gs, as,fc,L,info] = waveletfilters(Ls,scales,wvlt,'uniform','repeat','energy', 'delay',delays, 'redtar', redundancy);

c_orig = ufilterbank(f,gs,as);


abss =(abs(c_orig(:,(start_index+1):end)));
[N,Ms] = size(abss);
%medgab = quantile(abss,0.9,2);
%medgab = median(abss,2);
%medgab = medgab(1:(end-1));
%medgab = medgab(2:end);
%sum_up_chng_wvlt = sum(max(abss(2:end,:)-abss(1:(end-1),:)-medgab,0),2);
sum_up_chng_wvlt = sum(max(abss(2:end,:)-abss(1:(end-1),:),0),2);



%% Peak Picking
% We define peaks as local maxima that are larger than twice the local median
movmed_chng_wvlt = movmedian(sum_up_chng_wvlt, med_wlen);
loc_max_pos = zeros(N-1,1);
loc_max_pos(2:(end-1)) = (sum_up_chng_wvlt(2:(end-1))-sum_up_chng_wvlt(1:(end-2))>0)...
              .*(sum_up_chng_wvlt(2:(end-1))-sum_up_chng_wvlt(3:(end))>0);

% Load ground truth positions
txtfile = allannotCell{ii};
onset_times_gt = dlmread(txtfile);
loc_max_gt = (onset_times_gt/as(1)*fs);

% optimize moving threshold
th_fac = th_fac_min;
pass_thresh = (sum_up_chng_wvlt>th_fac*movmed_chng_wvlt);
loc_max_pos2= loc_max_pos.*pass_thresh;
onset_times = find(loc_max_pos2)*as(1)/fs;

[P1,R1,F1]=onset_dist(onset_times,onset_times_gt);


%%DGT for comparison
Mg=4*as(1);
cdgt = dgtreal(f,{'hann',Mg},as(1),Mg);


abss = (abs(cdgt(:,1:floor(Ls/as(1)))'));
[N,Ms] = size(abss);
%medgab = quantile(abss,0.9,2);
%medgab = median(abss,2);
%medgab = medgab(1:(end-1));
%medgab = medgab(2:end);
%sum_up_chng_gab = sum(max(abss(2:end,:)-abss(1:(end-1),:)-medgab,0),2);
sum_up_chng_gab = sum(max(abss(2:end,:)-abss(1:(end-1),:),0),2);


%% Peak Picking
% We define peaks as local maxima that are larger than twice the local median
movmed_chng_gab = movmedian(sum_up_chng_gab, med_wlen);
loc_max_pos_gab = zeros(N-1,1);
loc_max_pos_gab(2:(end-1)) = (sum_up_chng_gab(2:(end-1))-sum_up_chng_gab(1:(end-2))>0)...
              .*(sum_up_chng_gab(2:(end-1))-sum_up_chng_gab(3:(end))>0);
%test moving threshold
pass_thresh = (sum_up_chng_gab>th_fac*movmed_chng_gab);
loc_max_pos2_gab= loc_max_pos_gab.*pass_thresh;
onset_times_gab = find(loc_max_pos2_gab)*as(1)/fs;


[P1_gab,R1_gab,F1_gab]=onset_dist(onset_times_gab,onset_times_gt);



resol = 100;
stepsz = (th_fac_max - th_fac_min)/resol;

th_fac_opt = th_fac;
th_fac_opt_gab = th_fac;

for jj=1:resol
  th_fac = th_fac + stepsz;

  pass_thresh = (sum_up_chng_wvlt>th_fac*movmed_chng_wvlt);
  loc_max_pos2= loc_max_pos.*pass_thresh;
  onset_times = find(loc_max_pos2)*as(1)/fs;

  [P1,R1,F1new]=onset_dist(onset_times,onset_times_gt);
  if F1new > F1
    F1 = F1new;
    th_fac_opt = th_fac;
  end;

  pass_thresh = (sum_up_chng_gab>th_fac*movmed_chng_gab);
  loc_max_pos2_gab = loc_max_pos_gab.*pass_thresh;
  onset_times_gab = find(loc_max_pos2_gab)*as(1)/fs;

  [P1_gab,R1_gab,F1new_gab]=onset_dist(onset_times_gab,onset_times_gt);
  if F1new_gab > F1_gab
    F1_gab = F1new_gab;
    th_fac_opt_gab = th_fac;
  end;

end;




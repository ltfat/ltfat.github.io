% This file reproduces the Itakura-Saito NMF experiment shown in the paper 
% 'Invertible grid-based sampling of wavelet transforms for audio processing' 
% by N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer. 
% 
% This script is based on a demo kindly provided by Cédric Févotte, with
% the express permission to redistribute the adapted code. 
% Copyright (Original code) 2021 Cédric Févotte

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the 
% Free Software Foundation, either version 3 of the License, or (at your 
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but 
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
% for more details.
%
% You should have received a copy of the GNU General Public License along 
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

clearvars

% Specify golden Kronecker sequence delays
alpha = 1-2/(1+sqrt(5)); % 1-1/(goldenratio)
delays = @(n,a) a*(mod(n*alpha+.5,1)-.5);

% Select wavelet hyperparameter (implicitly determines Q-factor)
CauchyAlpha = 450;
redundancy = 2;

% Uncomment this to recompute optimal values for start_index and M
%[result] = ltfatnote057_exp0_optimize_single_condition({'cauchy',CauchyAlpha},redundancy,768,1);
M = 448; %Optimized number of channels (without lowpass DC channel) 
         %Note, M>768 was excluded from the search to prevent memory issues
start_index = 6; % Optimized number of demodulated (lowpass) channels

%% NMF specific parameters
smoothed = 1; %set to zero for default NMF
%smoothness constraint for IS_NMF (adjusted according to paper)
lambda = 25;

%% Prepare the audio files
[x,fs] = audioread('larmstrong.wav');

%x = x(1:round(numel(x)/2)); %this is just so I can handle the computations on my laptop
%(same as for M0 below in line 19)
Ls = length(x);


%% Prepare Wavelets 
max_freqDiv10 = 10;  % 10=Nyquist 
                     % By default, the reference scale for freqwavelet has 
                     % center frequency 0.1, and relative frequency in
                     % LTFAT is standardized to the range [0,2]. Hence
                     % Nyquist frequency is 1 = 0.1*10.

freq_step = max_freqDiv10/M; % The frequency step equals the maximum 
                              % frequency divided by the number of desired
                              % channels. 

min_freqDiv10 = freq_step*start_index; % Center frequency of minimum true 
                                       % wavelet channels 

% Generate wavelet scales from parameters above (lowpass filters are
% generated automatically).
scales = 1./linspace(min_freqDiv10,max_freqDiv10,M-start_index+1); 
 
disp('Computing filters')
[g, a,fc,L,info] = waveletfilters(Ls,scales,{'cauchy',CauchyAlpha},'uniform','repeat','energy', 'delay',delays, 'redtar', redundancy);
g = comp_filterbank_pre(g,a,L);
%disp('Computing Frame bounds (for testing only)')
% [A,B] = filterbankrealbounds(g,a,L);
% frame_bounds = B/A
% disp('Paused: Press any Key');
% pause
disp('Computing dual filters')
gd = filterbankrealdual(g,a,L,'asfreqfilter','batchsize',48);

%% Compute coefficients
disp('Computing coefficients')
X = ufilterbank(x,g,a).';
clear g
% X = cell2mat(coef.').';
% clear coef
V = abs(X).^2;
[M,N] = size(V);

%% Run NMF
disp('Run NMF')
K = 10; % nb of NMF components
tol = 1e-5; % convergence threshold
n_iter_max = 1000; % max nb of iterations
W_ini = (abs(randn(M,K)) + ones(M,K)); % init W
H_ini = (abs(randn(K,N)) + ones(K,N)); % init H

if smoothed
    [W, H, obj] = nmf_is_smooth(V, n_iter_max, W_ini, H_ini, lambda);
else
    [W, H, obj] = nmf_is(V, W_ini, H_ini, tol, n_iter_max);
end
V_ap = W*H; % approximate

%% Reconstruct temporal components
disp(['Reconstructing ',num2str(K),' components'])
c = zeros(K,Ls);
for k=1:K
    disp(['Reconstruct signal ',num2str(k)])
    mask_k = (W(:,k)*H(k,:))./V_ap; % Wiener filter mask
    C_k = mask_k.*X;
    c(k,:) = 2*real(ifilterbank(C_k.', gd, a, Ls));
end
clear X C_k

%% Re-order results by decreasing variance of the temporal components
[~,perm] = sort(var(c,0,2));
perm = perm(end:-1:1);

W = W(:,perm);
H = H(perm,:);
c = c(perm,:);

disp('Writing audio')
%% Write wavs
if ~exist(['./long_is-nmf_a',num2str(CauchyAlpha)], 'dir')
       mkdir(['./long_is-nmf_a',num2str(CauchyAlpha)])
end
chain = 'is-nmf';
for k=1:K
    audiowrite(['./long_is-nmf_a',num2str(CauchyAlpha),'/',chain '-' num2str(k),'_alpha_',num2str(CauchyAlpha),'.wav'],c(k,:),fs);    
end
save(['./long_is-nmf_a',num2str(CauchyAlpha),'/results.mat'],'W','H','c','-v7.3');

disp('Plotting')
%% Display objective function
figure(1)
semilogy(obj)
legend('IS divergence')

%% Display results
figure(2);
for k=1:K
    subplot(K,3,3*k-2);
    tmp = log10(W(:,k)+eps);
    plot(tmp,'k','LineWidth',1);
    %axis([1 M min(tmp(:)) max(tmp(:))])
    axis([1 M max(tmp(:))-5 max(tmp(:))])
        
    subplot(K,3,3*k-1);
    plot(H(k,:),'k','LineWidth',1);
    axis([1 N 0 max(H(k,:))])
    
    subplot(K,3,3*k);
    plot(c(k,:),'k','LineWidth',1);
    up = max(abs(c(:)));
    do = -up;
    axis([1 Ls do up])
end

for k=1:K-1
    subplot(K,3,3*k-2);
    set(gca,'XTickLabel',[]);
    subplot(K,3,3*k-1);
    set(gca,'XTickLabel',[]);
    subplot(K,3,3*k);
    set(gca,'XTickLabel',[]);
end

for k=1:K
    subplot(K,3,3*k-2);
    ylabel(['K = ' int2str(k)])
end

subplot(K,3,1); title('W')
subplot(K,3,2); title('H')
subplot(K,3,3); title('Temporal components')

disp('Done')

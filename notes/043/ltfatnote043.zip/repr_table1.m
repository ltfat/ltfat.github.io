clear all;

windows = {'hann','hamming','blackman'};

Cg = zeros(numel(windows),1);
probelen = 2048;
atheightrange = 0.01:0.0001:0.4;

for ii=1:numel(windows)
       g = firwin(windows{ii},probelen);
       Cg(ii) = findwindowconstant(g,probelen,atheightrange);
       fprintf('%s\t %.5f\n',windows{ii},Cg(ii));
end


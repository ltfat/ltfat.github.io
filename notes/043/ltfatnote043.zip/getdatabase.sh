#!/bin/bash
# The script downloads, extracts converts databases used in the paper
# such that the Matlab scripts can find the files.
if ! type "flac" > /dev/null; then
echo "Install flac decoder"
exit
fi

SQAMARCHIVE=SQAM_FLAC.zip

SQAMLINK=https://tech.ebu.ch/files/live/sites/tech/files/shared/testmaterial/$SQAMARCHIVE

CURRDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

wget -N $SQAMLINK

mkdir -p $CURRDIR/Databases/SQAM
unzip -o $SQAMARCHIVE -d $CURRDIR/Databases/SQAM
cd $CURRDIR/Databases/SQAM
ls *.flac | xargs flac -df
find . -type f -not -name '*.wav' -delete



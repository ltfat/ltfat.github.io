function comparetorealtime(databasePath,subdirs,varargin)

definput.keyvals.a=256;
definput.keyvals.M=2048;
definput.keyvals.maxsamples=[];
definput.keyvals.gl=[];
definput.keyvals.thr=1e-6;
definput.keyvals.perframeit=8;
definput.keyvals.exportdir = [];
definput.keyvals.expname = 'experiment';
definput.flags.winmod = {'truncgauss','hann','hamming','blackman'};
definput.flags.writewavs = {'donotstorewavs','storewavs'};
definput.flags.peaq = {'dontdopeaq','dopeaq'};
[flags,kv,a,M]=ltfatarghelper({'a','M'},definput,varargin);
thr = kv.thr;

if flags.do_dopeaq
    % Try to call PEAQ
    [status, res ] = system('peaq -h');
    if status>0
        error(['peaq not found. Please install GstPEAQ from',...
               'http://ant.hsu-hh.de/gstpeaq']);
    end
end

if isempty(kv.gl)
    kv.gl = kv.M;
end

fprintf(['------------------ %s WINDOW, a=%i, M=%i',...
'-----------------------\n'],flags.winmod,kv.a,kv.M);
outputdir = [kv.exportdir,filesep,mfilename,'_',kv.expname,'_',flags.winmod];
prefix = [databasePath,filesep];

CspsiAll = [];
CrtheapintAll = [];
Crtheapint0All = [];
Crtisila0All = [];
Crtisila1All = [];

ODG_spsiAll = [];
ODG_rtheapintAll = [];
ODG_rtheapint0All = [];
ODG_rtisila0All = [];
ODG_rtisila1All = [];

for jj= 1:numel(subdirs)
    subdir = subdirs{jj};
    
    dirname = [prefix,subdir,filesep];
    allwavs = dir([dirname,'*.wav']);
    
    for ii=1:numel(allwavs)
        wavfile = allwavs(ii).name;
        name = wavfile(1:strfind(wavfile,'.')-1);
        nameoutdir = [outputdir,filesep,name,filesep];
        origwav = [nameoutdir,name,'.wav'];
        
        if ~exist(outputdir, 'dir')
            mkdir(outputdir);
        end
        
        if ~exist(nameoutdir, 'dir')
            mkdir(nameoutdir);
        end
        
        [f,fs] = wavload([dirname,wavfile]);
        f = normalize(f(:,1),'wav');
        if ~isempty(kv.maxsamples)
            f = f(1:min([kv.maxsamples,numel(f)]));
        end
        Ls = numel(f);
        
        if flags.do_storewavs
            wavsave(normalize(f,'wav'),fs,origwav);
        end
        
        L = dgtlength(Ls,a,M);
        f = postpad(f,L);
        
        switch flags.winmod
            case 'truncgauss'
                h = 0.01;
                gnum = gabwin({'gauss','width',kv.gl,'atheight',h},a,M,10*M);
                gnum = normalize(long2fir(gnum,kv.gl),'inf');
                lambda = -pi/4*(kv.gl)^2/log(h);
            case 'hann'
                g = {'hann',kv.gl};
                gnum = gabwin(g,a,M);
                lambda = 0.25645*(kv.gl)^2;
            case 'hamming'
                g = {'hamming',kv.gl};
                gnum = gabwin(g,a,M);
                lambda = 0.29794*(kv.gl)^2;
            case 'blackman'
                g = {'blackman',kv.gl};
                gnum = gabwin(g,a,M);
                lambda = 0.17954*(kv.gl)^2;               
        end
        gdnum = gabdual(gnum,a,M,L);
        
        
        c = comp_sepdgtreal(f,gnum,a,M,1);
        
        s = abs(c);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        tic;
        chatspsi = spsi(s,a,M,'timeinv');
        SPSItime = toc;
        fhatspsi = idgtreal(chatspsi,gdnum,a,M,'timeinv');
        
        nextprojc = dgtreal(fhatspsi,gnum,a,M,'timeinv');
        Cspsi = magnitudeerr(c,nextprojc);
        Cspsidb = 20*log10(Cspsi);
        CspsiAll(end+1) = Cspsi;
        
        if flags.do_storewavs
            writetex(sprintf([nameoutdir,name,'_spsi%s%s.tex'],flags.winmod,kv.expname),Cspsidb);
            testwavfile = [nameoutdir,name,'_spsi.wav'];
            wavsave(normalize(fhatspsi,'wav'),fs,testwavfile);
            if flags.do_dopeaq
                ODG_spsi = callpeaq(origwav,testwavfile);
                ODG_spsiAll(end+1) = ODG_spsi;
            end
        end
          
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        tic;
        chatrtint = rtpghi(s,lambda,a,M,thr,'timeinv');
        HEAPINTRTtime = toc;
        fhatrtint = comp_isepdgtreal(chatrtint,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatrtint,gnum,a,M,'timeinv');
        Crtheapint = magnitudeerr(c,nextprojc);
        Crtheapintdb = 20*log10(Crtheapint);
        CrtheapintAll(end+1) = Crtheapint; 
        
        if flags.do_storewavs
            writetex(sprintf([nameoutdir,name,'_rtheapint1%s%s.tex'],flags.winmod,kv.expname),Crtheapintdb);
            testwavfile = [nameoutdir,name,'_rtheapint1.wav'];
            wavsave(normalize(fhatrtint,'wav'),fs,testwavfile);
            if flags.do_dopeaq
                ODG_rtheapint = callpeaq(origwav,testwavfile);
                ODG_rtheapintAll(end+1) = ODG_rtheapint;
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        tic;
        chatrtint0 = rtpghi(s,lambda,a,M,thr,'timeinv','causal');
        HEAPINTRT0time = toc;
        fhatrtint0 = comp_isepdgtreal(chatrtint0,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatrtint0,gnum,a,M,'timeinv');
        Crtheapint0 = magnitudeerr(c,nextprojc);
        Crtheapint0db = 20*log10(Crtheapint0);
        Crtheapint0All(end+1) = Crtheapint0;
         
        if flags.do_storewavs
            writetex(sprintf([nameoutdir,name,'_rtheapint0%s%s.tex'],flags.winmod,kv.expname),Crtheapint0db);
            testwavfile = [nameoutdir,name,'_rtheapint0.wav'];
            wavsave(normalize(fhatrtint0,'wav'),fs,testwavfile);
            if flags.do_dopeaq
                ODG_rtheapint0 = callpeaq(origwav,testwavfile);
                ODG_rtheapint0All(end+1) = ODG_rtheapint0;
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        tic;
        chatrtisila0 = rtisila(s,gnum,a,M,'maxit',kv.perframeit,'lookahead',0,'timeinv');
        RTISILA0time = toc;
        fhatrtisila0 = comp_isepdgtreal(chatrtisila0,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatrtisila0,gnum,a,M,'timeinv');
        Crtisila0 = magnitudeerr(c,nextprojc);
        Crtisila0db = 20*log10(Crtisila0);
        Crtisila0All(end+1) = Crtisila0;
        
        if flags.do_storewavs
            writetex(sprintf([nameoutdir,name,'_rtisila0%s%s.tex'],flags.winmod,kv.expname),Crtisila0db);
            testwavfile = [nameoutdir,name,'_rtisila0.wav'];
            wavsave(normalize(fhatrtisila0,'wav'),fs,testwavfile);
            if flags.do_dopeaq
                ODG_rtisila0 = callpeaq(origwav,testwavfile);
                ODG_rtisila0All(end+1) = ODG_rtisila0;
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        tic;
        chatrtisila1 = rtisila(s,gnum,a,M,'maxit',floor(kv.perframeit/2),'lookahead',1,'timeinv');
        RTISILA1time = toc;
        fhatrtisila1 = comp_isepdgtreal(chatrtisila1,gdnum,L,a,M,1);
        
        nextprojc = dgtreal(fhatrtisila1,gnum,a,M,'timeinv');
        Crtisila1 = magnitudeerr(c,nextprojc);
        Crtisila1db = 20*log10(Crtisila1);
        Crtisila1All(end+1) = Crtisila1;
        
        if flags.do_storewavs
            writetex(sprintf([nameoutdir,name,'_rtisila1%s%s.tex'],flags.winmod,kv.expname),Crtisila1db);
            testwavfile = [nameoutdir,name,'_rtisila1.wav'];
            wavsave(normalize(fhatrtisila1,'wav'),fs,testwavfile);
            if flags.do_dopeaq
                ODG_rtisila1 = callpeaq(origwav,testwavfile);
                ODG_rtisila1All(end+1) = ODG_rtisila1;
            end
        end
        
        fprintf(['SPSI: %.2f dB, ',...
                 'RTheapint1: %.2f dB, RTISI1 %.2f dB, ',...
                 'RTheapint0: %.2f dB, RTISI0 %.2f dB',...
                 ' %s, window: %s \n'],...
                 Cspsidb,...
                 Crtheapintdb,Crtisila1db,...
                 Crtheapint0db,Crtisila0db,...
                 wavfile,flags.winmod);
             
         if flags.do_dopeaq
            fprintf(['SPSI: %.2f, ',...
                 'RTheapint1: %.2f, RTISI1 %.2f, ',...
                 'RTheapint0: %.2f, RTISI0 %.2f',...
                 ' %s, window: %s \n'],...
                 ODG_spsi,...
                 ODG_rtheapint,ODG_rtisila1,...
                 ODG_rtheapint0,ODG_rtisila0,...
                 wavfile,flags.winmod);
         end
        
    end
    
end


CspsiAllMeanDB = 20*log10(mean(CspsiAll));
CrtheapintAllMeanDB = 20*log10(mean(CrtheapintAll));
Crtheapint0AllMeanDB = 20*log10(mean(Crtheapint0All));
Crtisila0AllMeanDB = 20*log10(mean(Crtisila0All));
Crtisila1AllMeanDB = 20*log10(mean(Crtisila1All));

disp('--------------------------MEAN------------------------------------------');
        fprintf(['SPSI: %.2f dB, ',...
                 'RTheapint1: %.2f dB, RTISI1 %.2f dB, ',...
                 'RTheapint0: %.2f dB, RTISI0 %.2f dB',...
                 ' window: %s \n'],...
                 CspsiAllMeanDB,...
                 CrtheapintAllMeanDB,Crtisila1AllMeanDB,...
                 Crtheapint0AllMeanDB,Crtisila0AllMeanDB,...
                 flags.winmod);


if flags.do_dopeaq
    ODG_spsiAllMean = mean(ODG_spsiAll);
    ODG_rtheapintAllMean = mean(ODG_rtheapintAll);
    ODG_rtheapint0AllMean = mean(ODG_rtheapint0All);
    ODG_rtisila0AllMean = mean(ODG_rtisila0All);
    ODG_rtisila1AllMean = mean(ODG_rtisila1All);
    
    fprintf(['SPSI: %.2f, ',...
         'RTheapint1: %.2f, RTISI1 %.2f, ',...
         'RTheapint0: %.2f, RTISI0 %.2f',...
         ' window: %s \n'],...
         ODG_spsiAllMean,...
         ODG_rtheapintAllMean,ODG_rtisila1AllMean,...
         ODG_rtheapint0AllMean,ODG_rtisila0AllMean,...
         flags.winmod);
    
end
disp('------------------------------------------------------------------------');

if flags.do_storewavs
    writetex(sprintf([outputdir,filesep,'avg_spsi%s%s.tex'],flags.winmod,kv.expname),CspsiAllMeanDB);
    writetex(sprintf([outputdir,filesep,'avg_rtheapint1%s%s.tex'],flags.winmod,kv.expname),CrtheapintAllMeanDB);
    writetex(sprintf([outputdir,filesep,'avg_rtheapint0%s%s.tex'],flags.winmod,kv.expname),Crtheapint0AllMeanDB);
    writetex(sprintf([outputdir,filesep,'avg_rtisila0%s%s.tex'],flags.winmod,kv.expname),Crtisila0AllMeanDB);
    writetex(sprintf([outputdir,filesep,'avg_rtisila1%s%s.tex'],flags.winmod,kv.expname),Crtisila1AllMeanDB);
end


function writetex(s,val)
fileID = fopen(s,'w');
fprintf(fileID,'%.2f\n',val);
fclose(fileID);

function odg = callpeaq(refwav,testwav)
[status, message] = system(sprintf('peaq --advanced %s %s',refwav,testwav));
if status>0
    error('Error calling peaq:\n %s',message);
end
messLines = strread(message, '%s', 'delimiter', sprintf('\n'));
tocompare = 'Objective Difference Grade:';
hitlineIdx = cellfun(@(mEl) ~isempty(strfind(mEl,tocompare)),messLines);
line = messLines{hitlineIdx};
parts = strsplit(line,':');
odg = str2double(strtrim(parts{end}));









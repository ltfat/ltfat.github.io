#include <stdlib.h>
#include <stdio.h>
#include <matio.h>
#include "timing.h"
#include "phaseret.h"
#include "ltfat.h"

#define len(array) (sizeof(array)/sizeof(array[0]))

double varReadScalarDouble(mat_t* file, char* varname)
{
    matvar_t* tmpvar = Mat_VarRead(file, varname);
    double retval = *((double*)tmpvar->data);
    Mat_VarFree(tmpvar);
    return retval;
}

double findMax(double* in, size_t L)
{
    double maxval = in[0];

    for (size_t ii = 1; ii < L; ++ii)
        if (in[ii] > maxval) maxval = in[ii];

    return maxval;
}


void time_rtpghi(const double* s, double gamma, double tol, int a, int M, int N,
                 double* times, size_t* timepos)
{
    int M2 = M / 2 + 1 ;
    // Output
    complex double* c = malloc(N * M2 * sizeof * c);

    int do_causal = 1;
    rtpghi_plan* p = rtpghi_init(gamma, a, M, tol, do_causal);
    // Warmup
    rtpghi_execute(p, s, c);

    for (int n = 0; n < N; ++n)
    {
        double tt = tic();
        const double* sncol = s + n * M2;
        complex double* cncol = c + n * M2;

        rtpghi_execute(p, sncol, cncol);

        times[(*timepos)] = toc(tt);
        (*timepos)++;
    }

    rtpghi_done(p);
    free(c);
}


void time_spsi(const double* s, int a, int M, int N, double* times,
               size_t* timepos)
{
    int M2 = M / 2 + 1;
    complex double* c = malloc( N * M2 * sizeof * c);
    double* spsiInitPhase = calloc( M2, sizeof * spsiInitPhase);

    // Warmup
    spsi(s, a, M, 1, spsiInitPhase, c);

    for (int n = 0; n < N; ++n)
    {
        double tt = tic();

        const double* sncol = s + n * M2;
        complex double* cncol = c + n * M2;
        spsi(sncol, a, M, 1, spsiInitPhase, cncol);

        times[(*timepos)] = toc(tt);
        (*timepos)++;
    }

    free(spsiInitPhase);
    free(c);
}

void time_rtisila(const double* s, const double* g, const double* gd,
                  const double* specg1, const double* specg2,
                  int a, int M, int N, int lookahead, int maxit, double* times, size_t* timepos)
{
    int M2 = M / 2 + 1;
    // Prealocate output
    complex double* c = malloc( N * M2 * sizeof * c);

    rtisila_plan* plan = rtisila_init(g, specg1, specg2, gd, a, M, lookahead,
                                      lookahead, maxit);
    //warmup
    rtisila_execute(plan, s, c);

    for (int n = 0; n < N; ++n)
    {
        double tt = tic();
        const double* sncol = s + n * M2;
        complex double* cncol = c + n * M2;

        rtisila_execute(plan, sncol, cncol);

        times[(*timepos)] = toc(tt);
        (*timepos)++;
    }

    rtisila_done(plan);
    free(c);
}

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        fprintf(stderr,
                "No mat file provided. Call the program as:\n %s testsuite1.mat ...\n ",
                argv[0]);
        exit(EXIT_FAILURE);
    }

    char* varnames[] = {"s", "a", "M", "g", "gd", "specg1", "specg2"};
    /* char* varnames[] = {"s", "a", "M", "g"}; */
    // Just check the input files
    int error_occured = 0;

    for (int ii = 1; ii < argc; ++ii)
    {
        mat_t* matfile;

        if (!(matfile = Mat_Open(argv[ii], MAT_ACC_RDONLY)))
        {
            fprintf(stderr, "Cannot open file %s\n", argv[ii]);
            error_occured = 1;
        }
        else
        {
            matvar_t* var;

            for (size_t jj = 0; jj < len(varnames); ++jj)
            {
                if (!(var = Mat_VarReadInfo(matfile, varnames[jj])))
                {
                    fprintf(stderr, "No variable %s found in file %s\n", varnames[jj], argv[ii]);
                    error_occured = 1;
                }
                else
                {
                    Mat_VarFree(var);
                }
            }

            Mat_Close(matfile);
        }
    }

    if (error_occured) exit(EXIT_FAILURE);

    size_t totalcols = 0;

    for (int ii = 1; ii < argc; ++ii)
    {
        mat_t* testset =  Mat_Open(argv[ii], MAT_ACC_RDONLY);
        matvar_t* svar = Mat_VarRead(testset, "s");
        totalcols += svar->dims[1];
        Mat_VarFree(svar);
        Mat_Close(testset);
    }

    printf("Total number of frames: %zu\n",totalcols);
    double spsiTiming[totalcols];
    double rtisilaTiming1it[totalcols];
    double rtisilaTiming4it[totalcols];
    double rtisilaTiming8it[totalcols];
    double rtisilaTiming16it[totalcols];
    double rtpghiTiming [totalcols];
    size_t spsiTimingPos = 0;
    size_t rtisila1itTimingPos = 0;
    size_t rtisila4itTimingPos = 0;
    size_t rtisila8itTimingPos = 0;
    size_t rtisila16itTimingPos = 0;
    size_t rtpghiTimingPos = 0;
    /* int lookahead = 0; */
    /* int maxit = 1; */

    for (int ii = 1; ii < argc; ++ii)
    {
        mat_t* testset =  Mat_Open(argv[ii], MAT_ACC_RDONLY);

        matvar_t* svar = Mat_VarRead(testset, "s");
        matvar_t* gvar = Mat_VarRead(testset, "g");
        matvar_t* gdvar = Mat_VarRead(testset, "gd");
        matvar_t* specg1var = Mat_VarRead(testset, "specg1");
        matvar_t* specg2var = Mat_VarRead(testset, "specg2");

        double* s = svar->data;
        int N = svar->dims[1];
        int a = varReadScalarDouble(testset, "a");
        int M = varReadScalarDouble(testset, "M");

        double* g = gvar->data;
        double* gd = gdvar->data;
        double* specg1 = specg1var->data;
        double* specg2 = specg2var->data;
        time_spsi(s, a, M, N, spsiTiming, &spsiTimingPos);
        time_rtisila(s, g, gd, specg1, specg2, a, M, N, 0, 1, rtisilaTiming1it, &rtisila1itTimingPos);
        time_rtisila(s, g, gd, specg1, specg2, a, M, N, 0, 4, rtisilaTiming4it, &rtisila4itTimingPos);
        time_rtisila(s, g, gd, specg1, specg2, a, M, N, 0, 8, rtisilaTiming8it, &rtisila8itTimingPos);
        time_rtisila(s, g, gd, specg1, specg2, a, M, N, 0, 16, rtisilaTiming16it, &rtisila16itTimingPos);
        time_rtpghi(s, 2048 * 0.17937, 1e-6, a, M, N, rtpghiTiming, &rtpghiTimingPos);

        Mat_VarFree(svar);
        Mat_VarFree(gvar);
        Mat_VarFree(gdvar);
        Mat_VarFree(specg1var);
        Mat_VarFree(specg2var);
        Mat_Close(testset);
    }


    printf("SPSI max. elapsed time: %f ms\n", findMax(spsiTiming, totalcols) );
    printf("RTISILA 1it. max. elapsed time: %f ms\n", findMax(rtisilaTiming1it, totalcols) );
    printf("RTISILA 4it. max. elapsed time: %f ms\n", findMax(rtisilaTiming4it, totalcols) );
    printf("RTISILA 8it. max. elapsed time: %f ms\n", findMax(rtisilaTiming8it, totalcols) );
    printf("RTISILA 16it. max. elapsed time: %f ms\n", findMax(rtisilaTiming16it, totalcols) );
    printf("RTPGHI max. elapsed time: %f ms\n", findMax(rtpghiTiming, totalcols) );


    return 0;
}

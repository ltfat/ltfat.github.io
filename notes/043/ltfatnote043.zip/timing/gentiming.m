function gentiming()

relDatabasepath = ['..',filesep,'Databases',filesep,'SQAM',filesep];

basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];
allwavs = dir([databasePath,'*.wav']);

for ii=1:numel(allwavs)
    
    wavfile = allwavs(ii).name;
    name = wavfile(1:strfind(wavfile,'.')-1);
    outfile = ['testfor',name,'.mat'];
    
    [f,fs] = wavload([relDatabasepath,wavfile]);
    f = f(1:10*fs,1);
    a = 256;
    M = 2048;
    g = firwin('blackman',M,'inf');
    
    
    gd = gabdual(g,a,M);
    
    lookback = ceil(M/a) - 1;
    wins = repmat(gd,1,2*lookback+1);
    specg1 = overlayframes(wins,a,M);
    specg1 = (specg1(1:M));
    wins(:,1) = 0;
    specg2 = overlayframes(wins,a,M);
    specg2 = (specg2(1:M));
    g = fftshift(g);
    g = fftshift(gd);
    
    s = abs(dgtreal(f,g,a,M));
    
    save('-v7',outfile, 's', 'a', 'M','g','gd','specg1','specg2');
end


function partrec = overlayframes(cframes,a,M)

N = size(cframes,2);
bufLen = N*a - (a-1) + M-1;
partrec = zeros(bufLen,1);

startidx = ceil(M/2)-1;
idxrange = startidx + [0:floor(M/2),-ceil(M/2)+1:-1];
for n=0:N-1
    idx = n*a + idxrange + 1;
    partrec(idx) = partrec(idx) + cframes(:,n+1);
end

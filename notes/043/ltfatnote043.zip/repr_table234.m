function dafx_repr_table234
% The EBU SQAM database is available freely from 
% https://tech.ebu.ch/publications/sqamcd
% Just download and unpack the archive in the following directory 
relDatabasepath = 'Databases';
% such that all the files reside in the following subdirectory
subdirs = {'SQAM'};
% The resulting files are flac files.
% The following Bash command converts all flac files in the
% current directory to wav files provided "flac - Command-line FLAC
% encoder/decoder" is installed
% ls *.flac | xargs flac -df


basepath = fileparts(which(mfilename));
databasePath = [basepath,filesep,relDatabasepath];


exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

maxsamples = 10*44100;
rtisiperframeit = 16;


callcompare = @(gname,a,M,varargin) comparetorealtime(databasePath,...
    subdirs,'exportdir',exportdir,gname,'expname',sprintf('sqam_%i',a),...
    'M',M,'a',a,'storewavs','maxsamples',maxsamples,...
    'perframeit',rtisiperframeit,varargin{:});

M = 2048;
a = 512;
callcompare('truncgauss',a,M);
callcompare('hann',a,M);
callcompare('hamming',a,M);
callcompare('blackman',a,M); 
 
a = 256;
callcompare('truncgauss',a,M);
callcompare('hann',a,M);
callcompare('hamming',a,M);
callcompare('blackman',a,M);
 
a = 128;
callcompare('truncgauss',a,M);
callcompare('hann',a,M);
callcompare('hamming',a,M);
callcompare('blackman',a,M);

% a = 64;
% callcompare('truncgauss',a,M);
% callcompare('hann',a,M);
% callcompare('hamming',a,M);
% callcompare('blackman',a,M);
% comparetorealtime(databasePath,subdirs,'exportdir',exportdir,'truncgauss','expname','sqam_512','M',M,'a',a,'storewavs','maxsamples',maxsamples,'perframeit',rtisiperframeit);
% comparetorealtime(databasePath,subdirs,'exportdir',exportdir,'hann','expname','sqam_512','M',M,'a',a,'storewavs','maxsamples',maxsamples,'perframeit',rtisiperframeit);
% comparetorealtime(databasePath,subdirs,'exportdir',exportdir,'hamming','expname','sqam_512','M',M,'a',a,'storewavs','maxsamples',maxsamples,'perframeit',rtisiperframeit);
% comparetorealtime(databasePath,subdirs,'exportdir',exportdir,'blackman','expname','sqam_512','M',M,'a',a,'storewavs','maxsamples',maxsamples,'perframeit',rtisiperframeit);

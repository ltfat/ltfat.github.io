clear all;

basepath = fileparts(which(mfilename));
exportdir = [basepath,filesep,'texexport'];

if ~exist(exportdir,'dir')
    mkdir(exportdir);
end

[f,fs] = gspi;
f = f(1:fs,1);

Ls = numel(f);

a = 128;
M = 2048;
gl = M;
thr = 1e-6;

h = 0.01;
gnum = gabwin({'gauss','width',gl,'atheight',h},a,M,10*M);
g = normalize(long2fir(gnum,gl),'inf');
lambda = -pi/4*(gl)^2/log(h);

c = dgtreal(f,g,a,M,'timeinv');

chat = rtpghi(abs(c),lambda,a,M,thr,'timeinv');

thrdisp = 7e-4;
figure(1);
plotdgtrealphasediff(angle(c),angle(chat),abs(c),thrdisp,a,M,'fs',fs);
%colormap(flipud(gray));
ylim([0,12e3]);
shg
saveas(gcf,[exportdir,filesep,'dafx_repr_fig1.png']);

% figure(2);
% plotdgtreal(s,a,M,'dynrange',-20*log10(thrdisp),'fs',fs);
% ylim([0,e3]);



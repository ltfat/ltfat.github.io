function [F,L] = generate_fusionframes(frametypes, varargin)
%GENERATE_FUSIONFRAMES demo function to initialize fusion frames
%
%   Usage: G = generate_fusionframes(frametypes, L)
%          G = generate_fusionframeC('paper', L,num_local,red,varargin)
%
%   Input parameters:
%     frametypes     array comprising the frame types
%     L              desired frame length
%
%   Output parameters:
%     G          the fully initialized fusion frame
%     L          length of the fusion frame
%     fs         sampling frequency
%
%   Optional parameters:
%     fs         sampling frequency; default: 44100 Hz
%     weights    default: uniform
%     init       initialisation type
%     L          frame length
%     red        redundancy, K/L per default
%
%   generate_fusionframes can be used to quickly initialize a range of
%   fusion frames. To reproduce the frames used in the review chapter
%   "A Survey of Fusion Frames in Hilbert Spaces", {'Fig2'}, {'Fig3'},
%   {'Fig4'} can be passed as input parameters.
%
%   Moreover, the following frames can be generated:
%     DGT
%     WMDCT
%     FWT
%     DST I
%     RANDOM, RANDOM_U
%     MIN, MIN_U
%     ONB
%     basis
%     FF_EX13_1, FF_EX13_1_u, FF_EX13_1_un
%     big
%     Mitra
%     another_R_three_u, another_R_three
%     structured



num_local = numel(frametypes);

definput.keyvals.fs = 44100;
definput.keyvals.weights = ones(num_local-1,1);
definput.flags.init = {'init', 'full'};
definput.keyvals.L = 10;
definput.keyvals.red = num_local/definput.keyvals.L;
%[flags,kv]=ltfatarghelper({},definput,varargin);

frame_args = frametypes(2:end);
framestring = [];
fixedlength = 0; %some frames -the generic ones- have fixed length in this
                 %case, LTFAT can not easily be accessed
outstring = [];
F = [];
kv.weights = [];

for ii = 1:num_local
    ftype = frametypes{ii};
    if ~iscell(ftype)
        ftype = {ftype};
    end 
    frame_args = ftype(2:end);
    switch ftype{1}
        case 'dgt'
            if size(frame_args,2) > 0
                definput.keyvals.M = frame_args{1};
            else
                definput.keyvals.M = 20;
            end
            
            if size(frame_args,2) > 1
                definput.keyvals.a = frame_args{2};
            else
                definput.keyvals.a = 10;
            end
            
            if size(frame_args,2) > 2
                definput.keyvals.win = frame_args{3};
            else
                definput.keyvals.win = 'gauss';
            end
            [~,kv]=ltfatarghelper({},definput,varargin);
            outstring = sprintf('''%s'', %i, %i', kv.win, kv.a, kv.M);
        case 'wmdct'
            if size(frame_args,2) > 0
                definput.keyvals.M = frame_args{1};
            else
                definput.keyvals.M = 80;
            end
            [~,kv]=ltfatarghelper({},definput,varargin);
            outstring = sprintf('''%s'', %i', 'gauss', kv.M);
        case 'fwt'
            if size(frame_args,2) > 0
                definput.keyvals.wl = frame_args{2};
            else
                definput.keyvals.wl = 'db8';
            end
            if size(frame_args,2) > 1
                definput.keyvals.J = frame_args{2};
            else
                definput.keyvals.J = 8;
            end
            [~,kv]=ltfatarghelper({},definput,varargin);
            outstring = sprintf('''%s'', %i',  kv.wl, kv.J);
        case 'dsti'
            if size(frame_args,2) > 0
                definput.keyvals.L = frame_args{1};
            else
                definput.keyvals.L = 20;
            end
            [~,kv]=ltfatarghelper({},definput,varargin);
            outstring = sprintf('%i', eye(kv.L));
        case {'random','random_u'}

            if size(frame_args,2) > 0
                definput.keyvals.Lr = frame_args{1};% length
            else
                definput.keyvals.Lr = 3;
            end
            
            if size(frame_args,2) > 1
                definput.keyvals.M = frame_args{2};% how many local frames
            else
                definput.keyvals.M = 3;
            end
            
            if size(frame_args,2) > 2
                definput.keyvals.red = frame_args{3};% red = varargin{3};% {min, max}
            else
                definput.keyvals.red = {0.25 0.75};
            end

            [~,kv]=ltfatarghelper({},definput,varargin);
            
            if numel(kv.red) == 1
                mmm = kv.red{1};
                MMM = mmm{1};
            elseif numel(kv.red) == 2
                mmm = kv.red{1};
                MMM = kv.red{2};
            end

            outstring = [];
            for ll = 1:kv.M
                rrr = rand(1,1)*(MMM - mmm) + mmm;
                g = rand(kv.Lr,floor(rrr*kv.Lr))'-1/2;
                
                eval(sprintf("F_%i = frame('gen', g');",ll));

                if ll == 1
                   fusionstring = "F_1";
                else
                    fusionstring = strcat(fusionstring, sprintf(", F_%i",ll));
                end
                
            end
            if strcmp(ftype{1}, 'random')
                kv.weights = rand(1,1);
            end
            ftype{1} = 'gen';
            %outstring = 'g';
            F = eval(sprintf("frame('fusion',kv.weights,%s);",fusionstring));
            fixedlength(ii) = 1;
            
         case {'min','min_u'}
            F_1 = frame('gen',[0 1]');
            F_2 = frame('gen',[1 0]');
            if strcmp(ftype{1}, 'min_u')
                % uniform
                weights = ones(2,1);
                F = frame('fusion',weights,F_1,F_2);
            else
                weights = rand(2,1);
                F = frame('fusion',weights,F_1,F_2);
            end
            fixedlength(ii) = 1;
            
        case 'ONB'

            F_1 = frame('gen', [1 0 0 0 0 0; 0 1 0 0 0 0]');
            F_2 = frame('gen', [0 0 1 0 0 0; 0 0 0 1 0 0]');
            F_3 = frame('gen', [0 0 0 0 1 0; 0 0 0 0 0 1]');
            
            weights = ones(1, 3);
        
            F = frame('fusion', weights, F_1,F_2,F_3);
            fixedlength(ii) = 1;
        
        case 'basis'
            L = 5;
            SR = 1;
    
            FFF = [ 1 0 1 0 0; 0 0 0 1 1];
    
            F_11 = frame('gen', FFF');
            F_11.descr = '2-dimensional basis';
            fusionstring = 'F_11';
    
            FFF = [ 0 0 1 1 1; 1 0 0 0 1; 0 1 0 0 1];
    
            F_12 = frame('gen', FFF');
            F_12.futype = '3-dimensional basis';
            fusionstring = strcat(fusionstring, ", F_12");
    
            FFF = [ 1 0 0 0 0; 0 0 1 0 0];
    
            F_21 = frame('gen', FFF');
            F_21.descr = '2-dimensional ONB';
            fusionstring = strcat(fusionstring, ", F_21");
    
            FFF = [1 1 1 1 1; 1 0 1 0 1; 0 1 1 1 0];
    
            F_22 = frame('gen', FFF');
            F_22.descr = '3-dimensional basis';
            fusionstring = strcat(fusionstring, ", F_22");
        
            F = eval(sprintf('frame(''fusion'',1,%s)',fusionstring));
            fixedlength(ii) = 1;
            
        case {'FF_EX13_1','FF_EX13_1_u','FF_EX13_1_un'}
        % Example 13.1 from Finite Frames Book 
            L = 3;
            SR = 1;
    
            F_1 = frame('gen', [1 0 0; 0 1 0]');
            F_2 = frame('gen', [0 1 0; 0 0 1]');

            if ftype == 'FF_EX13_1_n' || ftype == 'FF_EX13_1_un' 
            % just put a negative sign 
                F_2 = frame('gen', [0 -1 0; 0 0 1]');
            end

            if ftype == 'FF_EX13_1' || ftype == 'FF_EX13_1_n' 
                weights = rand(2,1);
                F = frame('fusion',weights,F_1,F_2);
            else
                F = frame('fusion',1,F_1,F_2);
            end
            fixedlength(ii) = 1;
            
        case 'big'
            disp('calculations with the ''big'' frame may take a while...')
            L = 4*1024;% overall length    
            SR = 44100;% assumed sampling rate
       
            a = 64;
            M = 1024;
            F = frame('dgt',{'hann',512}, a, M);
            % DGTREAL does not work as this is non-linear
            FFF = frsynmatrix(F,L);
            size(FFF);
    
            F_11 = frame('gen', FFF);
            F_11.futype = 'Gabor Sub-System with Hanning window, a = 64, M = 1024';
            fusionstring = 'F_11';
            % -----------------
            F = frame('fwt','db8',10);
            FFF = frsynmatrix(F,L);
            F_12 = frame('gen', FFF);
            F_12.futype = 'Wavelet system with Daubechies wavelet of order 8; 10 iterations';
        
            fusionstring = strcat(fusionstring, ', F_12');
       
            % ----------------------------------
            F = frame('dft');
            FFF = frsynmatrix(F,L);
            F_13 = frame('gen', FFF);
            F_13.futype = 'Pure frequencies';
    
            fusionstring = strcat(fusionstring, ', F_13');
            % ------------------------------------
            FFF = rand(L,L);
            F_21 = frame('gen',FFF);
            F_21.futype = 'Random frame UNIFORM (0,1)';
    
            fusionstring = strcat(fusionstring, ', F_21');
            % ---------------------------------------
            F = frame('dgt','gauss',128,512);
    
            FFF = frsynmatrix(F,L); 
            F_22 = frame('gen',FFF);
            F_22.futype = 'Gabor Frame with Gaussian window, a = 128 and M = 512';
    
            fusionstring = strcat(fusionstring, ', F_22');
    
            % ------------------------------------------   
            F = frame('dctii');
            FFF = frsynmatrix(F,L); 
       
            F_23 = frame('gen',FFF);
            F_23.futype = 'Discrete Cosinus Transform';
    
            fusionstring = strcat(fusionstring, ', F_23');
            % --------------------------------------------
         
            FFF = randn(L,L);
            F_31 = frame('gen',FFF);
            F_31.futype = 'Random frame, normal distributed';
            fusionstring = strcat(fusionstring, ', F_31');
            % ------------------------------------------
        
            F = frame('dgt','gauss',32,1);
            FFF = frsynmatrix(F,L); 
            F_32 = frame('gen',FFF);
            F_32.futype = 'Frames of translates with Gaussian';
    
            fusionstring = strcat(fusionstring, ', F_32');
            % ------------------------------------------
    
            F = frame('identity');
            FFF = frsynmatrix(F,L); 
            rrr = rand(L);
            FFF = FFF*diag(rrr);
    
            F_33 = frame('gen',FFF);
            F_33.futype = 'Standard Basis with random weights';
    
            fusionstring = strcat(fusionstring, ', F_33');
            % ------------------------------------------
       
            F = eval(sprintf("frame('fusion',1,%s)",fusionstring));
            
        case 'Mitra'
            L = 6;
            SR = 1;
    
            F_1=frame('gen',[1 1 0; 1 -1 0; 0 0 1; 0 0 0; 0 0 0; 0 0 0]);
            F_2=frame('gen', [0 0 0; 0 0 0; 1 1 0; 1 -1 0; 0 0 1; 0 0 0]);
            F_3=frame('gen', [0 0; 0 0; 0 0; 0 0; 0 0; 0 1]);
    
            F = frame('fusion',1,F_1,F_2,F_3);
            fixedlength(ii) = 1;
            
        case {'another_R_three_u','another_R_three'}
            L = 3;
            SR = 1;
    
            F_1 = frame('gen', [1 -1 2; -1 2 1]');
            F_2 = frame('gen', [2 1 -2; -1 0 1]');

            if ftype == 'another_R_three' 
                weights = rand(2,1);
                F = frame('fusion',weights,F_1,F_2);
            else
                F = frame('fusion',1,F_1,F_2);
            end
            fixedlength(ii) = 1;
            
        case {'Fig2', 'Fig3'}
            F_1 = frame('gen', [1 0 0; 0 1 0.5]');
            F_2 = frame('gen', [1 1 0; 0 0 1]');
            L = 3;
            kv.weights = ones(2,1);
            F = frame('fusion',kv.weights,F_1,F_2);
            fixedlength(ii) = 1;
            
        case 'Fig4'
            L = 105;
            F = generate_fusionframes({'random'}, 'Lr', L, 'M', 8);
            
        case 'structured'
            frametypes = {'dgt', 'wmdct', 'dwilt', 'fwt'};
            %frametypes = {'dwilt', 'dsti', 'fwt'};
            %, 'gen'};
            framenumber = 6;
            L = 128;
            fusionstring = cell(framenumber, 1);
            framestring = [];
            weights = ones(framenumber,1);
            for ii = 1:framenumber
                %generate single frames
                rand_idx = [4 1 1 4 4 1];
                %rand_idx = [3 1 2 1 2 3];
                g=randn(L, L);
                g=0.25*g./max(g);
                fusionstring{ii} = [frametypes{rand_idx(ii)},',', rand_pars(frametypes{rand_idx(ii)})];
                eval(sprintf('F_%i = frame(''%s'', %s);',ii, frametypes{rand_idx(ii)},...
                rand_pars(frametypes{rand_idx(ii)})));
                framestring = strcat(framestring, sprintf(", F_%i",ii));
            end

            fstring = framestring{1};
            F = eval(sprintf("frame('fusion',weights,%s);",fstring(2:end)));
        
        otherwise
            %disp('unrecognized frame type - not yet implemented');
            %outstring = [];
            F = [];
            L = [];
            return;
    end
    if ~isempty(outstring)
        eval(sprintf('F_%i = frame(''%s'', %s);',ii, ftype{1}, outstring));
    end
    localframe_name{ii} = ftype{1};
    if ii == 1
        framestring = strcat(framestring, sprintf("F_%i",ii));
    else
        framestring = strcat(framestring, sprintf(", F_%i",ii));  
    end
end

if isempty(F)
    F = eval(sprintf("frame('fusion',kv.weights,%s);",framestring));
end

for kk = 1:num_local
    if fixedlength(kk)
        F.frames{kk}.fixedlength = 1;
    end
end
F.futype = localframe_name;

%if flags.do_full
 %   if any(fixedlength) == 1
 %       disp('fixed length local frame. full init not yet possible in this config.');
 %       return;
 %   end
    %F = checkfudimC(F, kv.L);
%    F = frameaccel(F, kv.L);
end

function outstring = rand_pars(instring)

switch instring
    case 'dgt'
        outstring = sprintf('''%s'', %i, %i', 'gauss', 10, 40);
    case 'dwilt'
        outstring = sprintf('''%s'', %i', 'gauss', 20);
    case 'wmdct'
        outstring = sprintf('''%s'', %i', 'gauss', 20);
    case 'fwt'
        outstring = sprintf('''%s'', %i',  'db8', 8);
    case 'cqtfb'
        outstring = sprintf('%i,%i,%i, %i, %i', 44100,40, 10000, 8, 160);
        %('cqtfb',fs,fmin,fmax,bins,Ls,...)
    case 'dsti'
        outstring = sprintf('%i', eye(10));
    case 'gen'
        outstring = sprintf('%s', 'g');
    otherwise
        disp('unrecognized frame type - pars not yet implemented');
        outstring = [];
end

end

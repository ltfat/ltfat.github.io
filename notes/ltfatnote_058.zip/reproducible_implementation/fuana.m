function [proj,F] = fuana(F,f,varargin)
%FUANA fusion frame analysis operator
%
%   Input parameters:
%     F        fusion frame
%     f        input signal
%
%   Output parameters:
%     proj   projection
%     F      loop back of fusion frames
%
%
%   `fuana` does the fusion frame analysis, i.e 
%   $ p_j = (w_j \pi_{W_j} f )_j.$, where $(f)$ 
%   is the signal/ function, $w_j$ teh weights, 
%   $W_j$ the subspaces (spanned by the local frames).
%
%
%   Optional parameters:
%     'single',s   only calculate one coefficient, i.e. the projection on $W_j$
%
% Started: 23.12.2021
% Last: 8.11.2022
%
% Author: P. Balazs
% adapted for LTFAT: C.Hollomey
%
% Dependencies: LTFAT http://ltfat.org
 
complainif_notvalidframeobj(F,'Fuana');

if ~strcmp(F.type, 'fusion')
    error('fuana only works for fusion frames');
end


definput.keyvals.single = [];
[~,kv]=ltfatarghelper({},definput,varargin);

if isfield(F, 'localdual')
    FD = F.localdual;
%    FD = framedual(F);
else    
    FD = framedual(F);
%    FD = fudualC(F);
end
L = length(f);
F = checkfudim(F, L);

if isnan(F.cdim)
    error('Local frames have to have the same dimension (for now).');
elseif F.cdim ~= length(f)
    error('Local frames and signal do not fit.')
end

if ~isempty(kv.single)
    start_idx = kv.single;
    end_idx = kv.single;
    proj = cell(1, 1);
else
    start_idx = 1;
    end_idx = F.Nframes;
    proj = cell(F.Nframes, 1);
end

cnt = 1;
for ii=start_idx:end_idx
    c = frana(F.frames{ii},f);
    c= flip(F.w(ii))*c;
    proj{cnt} = frsyn(FD.frames{ii}, c);    
    cnt = ii+1;
end

clear all

fbounds = 1;%calculate frame bounds 1...yes/0...no


%% input signal
L = 384;
fs = L;                   % samples per second
dt = 1/fs;                % seconds per sample
tstop = 1;
t = (0:dt:tstop-dt)';     % seconds

fc = 48;    
wind = circshift(pgauss(L, 10)./max(pgauss(L,10)), sum(L)/2);
sig = randn(L,1);
sign = sig.*1.*wind;
x = zeros(L,1);
sig = sin(2*pi*fc*t)+sign +x;
sig(320:325) = 2;

%% frames and their layout
% frame parameters
M = L/8;
a = 16;
J = 6;
dgtred = M/a;
% frame layout
nrows = 2; 
ncols = 3;
toverlap = 0.1;
foverlap = 0.1;

Lcol = L/ncols; %length of one column
Lrow = Lcol/nrows; %length of one row
Lrow = L/(2*nrows);
toverlap = floor(toverlap*Lcol)*ones(1,nrows*ncols);
foverlap = floor(foverlap*Lrow)*ones(1,nrows*ncols);


%get the indices for overlapping frame sequences
[start_idx1, start_idx2, end_idx1, end_idx2] = ...
    get_indices(Lcol, Lrow, toverlap, foverlap, nrows, ncols);

start_idx1 = start_idx1(:);
end_idx1 = end_idx1(:);


%derive the local frames and expand them on the t-f plane
[local_dgt_raw, local_dgt_tiles, F_dgt] = ...
    mapdgt(sig, a, M);

if fbounds
    %of the whole synthesis matrix
    F=frame('gen', F_dgt);
    [Adgt,Bdgt] = framebounds(F);
    %Bdgt/Adgt
end
%display only positive frequencies
local_dgt_tiles = local_dgt_tiles(1:L/2, :);
local_dgt_raw = local_dgt_raw(1:L/2, :);

[local_wl_raw, local_wl_tiles, F_wl] = ...
    mapfwt(sig, J);

if fbounds
    %of the whole synthesis matrix
    F=frame('gen', F_wl);
    [Awl,Bwl] = framebounds(F);
    %Bwl/Awl
    clear F
end


%% derive the tiles from the local frames

F.type{1} = 'wl';
F.type{4} = 'wl';
F.type{5} = 'wl';
F.type{2} = 'dgt';
F.type{3} = 'dgt';
F.type{6} = 'dgt';

for kk = 1:nrows*ncols
    if strcmp(F.type{kk}, 'dgt')
        F.tiles{kk} = local_dgt_tiles(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        F.raw{kk} = local_dgt_raw(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        z=F.tiles{kk};
        z(isnan(z)) = 0;
        F.norms{kk} = norm(z);
        
        if fbounds
            %frame bounds of the local frames: dgt
            ldgt = F_dgt;
            ldgt(isnan(ldgt)) = 0;
            fmat{kk} = ldgt(:,start_idx1(kk):end_idx1(kk));
            F_local(kk) = frame('gen', fmat{kk});
            [A_local(kk), B_local(kk)] = framebounds(F_local(kk));
        end
        
    elseif strcmp(F.type{kk}, 'wl')
        F.tiles{kk} = local_wl_tiles(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        F.raw{kk} = local_wl_raw(start_idx2(kk):end_idx2(kk), ...
            start_idx1(kk):end_idx1(kk));
        z=F.tiles{kk};
        z(isnan(z)) = 0;
        F.norms{kk} = norm(z);
        
        if fbounds
            %frame bounds of the local frames: fwt
            lwlf = F_wl;
            lwlf(isnan(lwlf)) = 0;
            fmat{kk} = lwlf(:,start_idx1(kk):end_idx1(kk));
            F_local(kk) = frame('gen', fmat{kk});
            [A_local(kk), B_local(kk)] = framebounds(F_local(kk));
        end

    else
        disp('not implemented.')
    end
    
end

%% assemble the representation

representation = nan(max(end_idx2), max(end_idx1));
representation_raw = nan(max(end_idx2), max(end_idx1));
representation_norm = zeros(max(end_idx2), max(end_idx1));
averagetmp = zeros(max(end_idx2), max(end_idx1));
averagenorm = zeros(max(end_idx2), max(end_idx1));


for ii = 1: nrows*ncols
    x = F.tiles{ii};
    z = F.raw{ii};
    y = F.norms{ii}.*ones(size(F.tiles{ii}));
    xf = 1;
    for f_i = start_idx2(ii):1:end_idx2(ii) 
            xt = 1;
        for t_i = start_idx1(ii):1:end_idx1(ii)
            representation_norm(f_i, t_i) = representation_norm(f_i, t_i) + y(xf,xt);
            averagenorm(f_i, t_i) = averagenorm(f_i, t_i) + 1;
             %nan+int = nan; therefore, distinguish here to be able to add up  
            if (~isnan(representation(f_i, t_i)) && ~isnan(x(xf,xt)))
                representation(f_i, t_i) = representation(f_i, t_i) + x(xf,xt);
                representation_raw(f_i, t_i) = representation_raw(f_i, t_i) + z(xf,xt);
                averagetmp(f_i, t_i) = averagetmp(f_i, t_i) + 1;
            elseif (isnan(representation(f_i, t_i)) && ~isnan(x(xf,xt)))
                representation(f_i, t_i) = x(xf, xt);
                representation_raw(f_i, t_i) = z(xf, xt);
                averagetmp(f_i, t_i) = 1;
            elseif (~isnan(representation(f_i, t_i)) && isnan(x(xf,xt)))
                representation(f_i, t_i) = representation(f_i, t_i);
                representation_raw(f_i, t_i) = representation_raw(f_i, t_i);
                averagetmp(f_i, t_i) = averagetmp(f_i, t_i);
            elseif (isnan(representation(f_i, t_i)) && isnan(x(xf,xt)))
                representation(f_i, t_i) = nan;
                representation_raw(f_i, t_i) = nan;
                averagetmp(f_i, t_i) = nan;
            end
            xt = xt+1;
        end
        xf = xf+1;
    end

end

%average points with more than one frame element
averagetmp(averagetmp==0) = 1;
averagetmp(isnan(averagetmp)) = 1;
fusiotmp = representation./averagetmp;
fusioraw = representation_raw./averagetmp;
representation_norm = representation_norm./averagenorm;

%% interpolate nans
ct = 0;
cmat_interp = fusiotmp(1:end,:);
while sum(sum(isnan(cmat_interp)))
    for ii = 1:size(cmat_interp, 1)
        %interpolate along the second dimension, i.e. per row
        cmat_interp(ii,:) = fillmissing(cmat_interp(ii,:),'spline', 2);
    end
    ct = ct+1;
    if ct > 100
        break;
    end
end

if sum(sum(isnan(cmat_interp)))
    disp('interpolation did not remove all nans')
end


if fbounds
%calculate the frame bounds of the global frame
        H1 = [fmat{1}; fmat{2}; fmat{3}; fmat{4}; fmat{5}; fmat{6}];
        H = frame('gen', H1);
        [ah, bh] = framebounds(H);
        sprintf('global frame bound ratio: %i', round(bh/ah))  
%calculate the frame bounds of the fusion frame (weights = 1) 
        Id = eye(Lcol);
        Sf = zeros(Lcol,Lcol);
        for ii=1:nrows*ncols
            c = fmat{ii}*Id;
            %c= flip(F.w(ii))*c;
            proj{ii} = c'*pinv(fmat{ii})';
            Sf = Sf + proj{ii};
        end
     
        Gl = frame('gen', Sf);
        [A0, B0] = framebounds(Gl);
        sprintf('fusion frame bound ratio: %i', round(B0/A0))
end

fusio = cmat_interp;


%% plots

figure
%plot the fusiogram
disp1 = log(fusio(1:end,1:end));
normc = abs(max(max(disp1(~isinf(disp1)))));
imagesc((1*abs(log(fusio(1:end,1:end))+normc*ones(size(disp1)))))
colorbar
colormap(flipud(hsv))
set(gca,'YDir','normal')
xlim([0 max(end_idx1)])

%the lines to display the local frames
hold on
for ll=1:nrows*ncols
line([start_idx1(ll) end_idx1(ll)],[end_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([start_idx1(ll) end_idx1(ll)],[start_idx2(ll) start_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([start_idx1(ll) start_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([end_idx1(ll) end_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
end

a = get(gca,'XTickLabel');  
set(gca,'XTickLabel',a,'fontsize',48)
set(gca,'XTickLabelMode','auto')
xlabel('Time [samples]', 'Fontsize', 48)
ylabel('Frequency [au]', 'Fontsize', 48)

figure
%plot the raw data
imagesc((abs((representation_raw./averagetmp))./max(abs(representation_raw./averagetmp))))
colorbar
set(gca,'YDir','normal')
xlim([0 max(end_idx1)])

%the lines to display the local frames
hold on
for ll=1:nrows*ncols
line([start_idx1(ll) end_idx1(ll)],[end_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([start_idx1(ll) end_idx1(ll)],[start_idx2(ll) start_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([start_idx1(ll) start_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([end_idx1(ll) end_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
end

a = get(gca,'XTickLabel');  
set(gca,'XTickLabel',a,'fontsize',48)
set(gca,'XTickLabelMode','auto')
xlabel('Time [samples]', 'Fontsize', 48)
ylabel('Frequency [au]', 'Fontsize', 48)


figure;
%plot the input signal
plot(sig, 'LineWidth', 2)
hold on
grid on
plot(wind, 'LineWidth', 2)
xlabel('Time [samples]', 'Fontsize', 48)
xlim([0 3*Lcol])
vv = max(abs(sig));
ylim([-1.1*vv 1.1*vv])
a = get(gca,'XTickLabel');  
set(gca,'XTickLabel',a,'fontsize',48)
set(gca,'XTickLabelMode','auto')
xlabel('Time [samples]', 'Fontsize', 48)
ylabel('Amplitude [au]', 'Fontsize', 48)
    
figure;
%plot the norms
imagesc(representation_norm)
colorbar
set(gca,'YDir','normal')
xlim([0 max(end_idx1)])

set(gca,'xticklabel',{[]})
set(gca,'yticklabel',{[]})

%the lines to display the local frames
hold on
for ll=1:nrows*ncols
line([start_idx1(ll) end_idx1(ll)],[end_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([start_idx1(ll) end_idx1(ll)],[start_idx2(ll) start_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([start_idx1(ll) start_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
line([end_idx1(ll) end_idx1(ll)],[start_idx2(ll) end_idx2(ll)], 'LineWidth', 2, 'Color', 'white')
end
a = get(gca,'XTickLabel');  
set(gca,'XTickLabel',a,'fontsize',48)
set(gca,'XTickLabelMode','auto')
set(gca,'xticklabel',{[]})
set(gca,'yticklabel',{[]})

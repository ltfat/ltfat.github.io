function [f, f_interp, F_dgt] = mapdgt(sig, a, M)
%MAPDGT expands discrete Gabor coefficients to the time-frequency grid
%
%   Input parameters:
%     sig        input signal
%     a          downsampling factor in time
%     M          number of frequency channels
%
%   Output parameters:
%     f          the expanded Gabor frame
%     f_interp   the interpolated expanded Gabor frame
%     F_dgt      the frame synthesis matrix

L = length(sig);

F_1d = frame('dgt', 'hann', a, M);
F_2a = frameaccel(F_1d, L);
F_dgt = frsynmatrix(F_2a, L).';

for ii = 1:M:size(F_dgt,1)+1-M
    
    for jj = ii:M+ii-1
        f(jj) = F_dgt(jj,:)*sig;
    end
end
fi = reshape(f, M, L/a);

ct = 1;
test = zeros(L, L);
for ii = 1:L/M:L+1
%for ii = 1:2*L/M:2*L+1
    test(ii,:) = upsample(fi(ct,:), a);
    test(test==0) = nan;
end
f = test(1:L, :);
%f = test(1:ceil(size(test,1)/2),:);

ct = 1;
testin = zeros(L, L);
%testin = zeros(2*L, L);
for ii = 1:L/M:L
%for ii = 1:2*L/M:2*L
    testin(ii:ii+L/M,:) = repmat(upsample(fi(ct,:), a),numel([ii:ii+L/M]),1);
    %testin(ii:ii+2*L/M,:) = repmat(upsample(fi(ct,:), a),numel([ii:ii+2*L/M]),1);
    testin(testin==0) = nan;
    ct = ct + 1;
end
f_interp = testin;
%f_interp = testin(1:ceil(size(test,1)/2),:);
      

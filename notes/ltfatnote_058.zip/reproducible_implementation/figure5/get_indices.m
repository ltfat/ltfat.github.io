function [start_idx1, start_idx2, end_idx1, end_idx2] = get_indices(Lcol, Lrow, toverlap, foverlap, nrows, ncols)
%this is a preliminary script for assembling matrices of arbitrary
%size on a time-frequency plane. it includes a few unnecessary assumptions,
%e.g. the matrix used needs to be frsyn at the moment, the dimensions of
%the global fusion frame are determined from the dimensions of the
%assembled tf-jigsaw.

%assumptions:
% the number of local frames per row and column is the same
% frames are never split
% starting point (1,1) is the starting point of the first frame (i.e. top
% left corner)
%
% The function is not guaranteed to yield a fully overlapping fusion frame,
% particularly if L, toverlap and foverlap strongly differ between the 
% local frame.
% Thus, we recommend to confirm its output visually and via the
% |framebounds| function.

% 11.11.2022, C. Hollomey


%% get the start and end indices
end_idx1 = zeros(nrows, ncols);
start_idx2 = zeros(nrows*ncols, 1);
end_idx2 = zeros(nrows*ncols, 1);
row_idx = zeros(nrows, ncols);

start_idx1 = ones(nrows,1);

if numel(Lrow) == 1
    Lrow = Lrow*ones(nrows*ncols, 1);
end

if numel(Lcol) == 1
    Lcol = Lcol*ones(nrows*ncols, 1);
end

s_idx1 = abs(mod([1:nrows*ncols], nrows)-nrows);%get the row indices per local frame

pick_vector = [1:nrows*ncols];

for jj = 1:nrows
    row_idx(jj,:) = pick_vector(s_idx1==jj);
end


toverlap = reshape(toverlap, nrows, ncols); 
Lcol = reshape(Lcol, nrows, ncols);
for ii = 1:nrows*ncols
   if ~mod(ii-1, nrows)
       start_idx2(ii) = 1;
   else
       start_idx2(ii) = start_idx2(ii-1) + Lrow(ii) -foverlap(ii-1);
   end
   end_idx2(ii) = start_idx2(ii)-1 + Lrow(ii);    

   if ii==1
       start_idx1 = ones(nrows,1);
       for jj = 1:nrows
           end_idx1(jj, ii) = start_idx1(jj,ii)-1 + Lcol(jj,ii);
       end
   else
        for jj = 1:nrows
            if ii <= ncols
                start_idx1(jj, ii) = start_idx1(jj,ii-1) + ...
                    Lcol(jj,ii)-toverlap(jj,row_idx(ii-1));
                
                end_idx1(jj, ii) = start_idx1(jj,ii)-1 + ...
                    Lcol(jj,ii);
            end
        end
   end

end

